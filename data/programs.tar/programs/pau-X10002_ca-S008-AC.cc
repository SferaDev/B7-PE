
/* Pre: parametre implicit = P */
/* Post: s'han eliminat del parametre implicit totes les aparicions d'x (la
resta d'elements queda en el mateix ordre que a P); si el punt d'interes de P
referenciava a una aparicio d'x, passa a referenciar al primer element
diferent d'x posterior a aquesta (si no hi ha cap element diferent d'x, passa
a la dreta el tot); en cas contrari, el punt d'interes no canvia */        
void esborrar_tots(const T& x)
{
  node_llista* rec = primer_node;
  while (rec != NULL) {
    if (rec->info == x) {
      --longitud;
      if (rec == primer_node) primer_node = primer_node->seg;
      if (rec == act) act = rec->seg;
      if (rec->ant != NULL and rec->seg != NULL) {
        rec->ant->seg = rec->seg;
        rec->seg->ant = rec->ant;
        node_llista* aux = rec->seg;
        delete rec;
        rec = aux;   
      }
      else if (rec->seg == NULL and rec->ant != NULL) {
        ultim_node = rec->ant;
        rec->ant->seg = NULL;
        delete rec;
        rec = NULL;
      }
      else if (rec->seg != NULL and rec->ant == NULL) {
        rec->seg->ant = NULL;
        node_llista* aux = rec->seg;
        delete rec;
        rec = aux; 
      }
      else {
        primer_node=ultim_node=act=NULL;
        delete rec;
        rec = NULL;
      }  
    }
    else rec = rec->seg;
  }    
}
