#include <iostream>

using namespace std;

int main ()
{
  int f,c;
  bool primer=true;
  while (cin>>f>>c){
    if (not primer) cout<<endl;
    primer = false;
    int cont=9;
    for (int i=0;i<f;++i){
      for (int j=0;j<c;++j){
	if (cont<0){
	  cont=9;
	  cout<<cont;
	  --cont;
	} else {
	  cout<<cont;
	  --cont;
	}
      }
      cout<<endl;
    }
  }
}