#include <iostream>
#include <vector>
using namespace std;

int main() {
  int a1, b1, a2, b2, i1, f1;
  int n1, n2, cont = 0, cont2 = 0;      
  cin >> a1 >> b1;
  cin >> a2 >> b2;
  n1 = b1 - a1 + 1;
  n2 = b2 - a2 + 1;      
  if (a1 == a2 && b1 == b2) {cout << "= , [" << a1 << ',' << b1 << ']' << endl; // Dos iguals
    ++cont;      
  }     
  if (a1 >= a2 && b1 <= b2) {
   if (a1 != a2 || b1 != b2) {
      cout << "1 , [" << a1 << ',' << b1 << ']' << endl; // 1 Dintre de 2                
      ++cont;         
   }
  }      
  if (a2 >= a1 && b2 <= b1) {
   if (a1 != a2 || b1 != b2) {cout << "2 , [" << a2 << ',' << b2 << ']' << endl; // 2 Dintre de 1
   ++cont;
   }
  }      
  int r1[n1];
  int r2[n2];      
  if (cont == 0) {
     for (int i=0; i < n1; ++i) {
     r1[i] = a1;
     a1++;                 
     }
     for (int i=0; i < n2; ++i) {
     r2[i] = a2;
     a2++;                 
     }
     for (int i = 0; i < n1; ++i) {
       for (int j = 0; j < n2; ++j) {
        if (r1[i] == r2[j]) {
           if (cont2 == 0) {i1 = r2[j];}
           cont2++;
           f1 = r2[j];               
        }
       }           
     }
     if (cont2 > 0) cout << "? , [" << i1 << ',' << f1 << ']' << endl;
     if (cont2 == 0) cout << "? , []" << endl;               
  } 
}          
