#include <iostream>

using namespace std;

int main (){
  int ant, mig, sig;
  bool encontrado = false;
  cin >> ant >> mig >> sig;
  while (not encontrado and sig != 0) {
    if ( mig > 3143 and ant < mig and mig>sig) encontrado = true;
    ant= mig;
    mig=sig;
    cin >> sig;
  }
  if (encontrado) cout << "SI" << endl;
  else cout << "NO" << endl;
}
  
  