#include <iostream>
#include <vector>
#include <list>
using namespace std;

typedef vector < list <string> > subc;
typedef vector <string> VS;

void print (subc &c)
{
  int n = c.size();
  for (int i = 0; i < n ; ++i){
    bool first = true;
    cout << "subconjunt " << i + 1 << ": {" ;
    for (auto it = c[i].begin(); it != c[i].end(); ++it)
    {
      if (first) first = false;
      else cout << ',';
      cout << (*it);
    }
    cout << '}' << endl;
  }
  cout << endl;
}

void Backtrack (int i, const VS &con, subc &c)
{
  int n = con.size();
  if (i == n) print(c);
  else{
    for (int j = 0; j < c.size(); ++j){
    c[j].push_back(con[i]);
    Backtrack(i+1,con,c);
    c[j].pop_back();
    }
  }
}

void llegir(VS &v)
{
  int n = v.size();
  for (int i = 0; i < n; ++i) cin >> v[i];
}

int main ()
{
  int n; cin >> n;
  VS con(n);
  llegir(con);
  int p; cin >> p;
  subc c(p);
  Backtrack(0, con, c);
}
