#include <iostream>
#include <vector>
using namespace std;

struct M {
    int max, min;
};

void leerVector_int(vector<int>& v) // version accion
{
 
  int numEst;
  cin >> numEst;
  v = vector<int> (numEst);
  
  for (int i=0; i<numEst;++i)
    {
       cin >> v[i];
    }
}
 


M maximminim (const vector<int> &v) {
  M m;
  m.max = m.min = v[0];
  for(int i = 1; i < v.size(); ++i) {
    if ( v[i] > m.max ) m.max = v[i];
    else if (v[i] < m.min) m.min = v[i];
  }
  return m;
}
  

int main ()
{
  vector<int> v;
  M b;
  leerVector_int(v);
  b = maximminim (v);
  cout << b.max << " " << b.min << endl;
}
