#include <iostream>
using namespace std;

/* SPEC
 * 
 * in: Input begins with the number of rows r and the number of
 * columns c. Follow r lines, each one with c characters between
 * ‘0’ and ‘9’.
 * 
 * out: Print the total number of coins on the white squares of
 * the board.
 * 
 */

int main() {
    // Read and store rows and columns
    int r, c;
    cin >> r >> c;
    
    // Init the counter
    int count = 0;
    
    // Init the isWhite boolean
    bool white = true;
    
    // Loop through the rows and columns
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            char input;
            cin >> input;
            if (white) count += input - '0';
            if (c > 1) white = !white;
        }
        white = !white;
    }
    
    // Print the results
    cout << count << endl;
}