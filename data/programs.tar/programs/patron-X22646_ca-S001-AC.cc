void trenat(Cua &c){
  /* Pre: p.i. = C1, c = C2 */
  /* Post: el p.i. passa a ser el resultat de trenar C1 i C2; c passa a ser buida */
 
  node_cua *c1 = this->primer_node;
  node_cua *pr_node = this->primer_node;
  node_cua *c2 = c.primer_node;
  this->longitud += c.longitud;
 
  if(c1 == NULL and c2 != NULL) this->primer_node = c.primer_node;
  else{
    while(c1 != NULL and c2 != NULL){
      node_cua *aux = c1->seguent;
      c1->seguent = c2;
      c1 = aux;
      aux = c2->seguent;
      if(c1 != NULL) c2->seguent = c1;
      c2 = aux;
    }
  }
  //Que apunti de nou al primer node de tots.
  c1 = pr_node;
}