#include "Arbre.hh"
#include <stack>
using namespace std;

void cami_preferent(Arbre<int> &a, stack<int> &c, int& n){
    if (a.es_buit()) n = 0;
    else {
        Arbre <int> a1,a2;
        int node = a.arrel();
        a.fills(a1,a2);
        stack<int> b;
        int aux;
        cami_preferent(a1, c, aux);
        int aux2;
        cami_preferent(a2, b, aux2);
        n = aux + aux2 + 1;
        if (aux2 > aux) c = b;
        c.push(node);
    }
}

 void cami_preferent(Arbre<int> &a, stack<int> &c) {
 /* Pre: a=A, c es buida */ 
 /* Post: c conte el cami preferent d'A; si no es buit, el primer element
    del cami es al cim de c */
    int n = 0;
    cami_preferent(a, c, n);
 }

