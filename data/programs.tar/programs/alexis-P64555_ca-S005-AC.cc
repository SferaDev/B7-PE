#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

struct Coordenate {
    int x;
    int y;
    int distance;
};

int abs(int i) {
    if (i < 0) return i * -1;
    return i;
}

bool comp(const Coordenate& c1, const Coordenate& c2) {
    if (c1.distance == c2.distance) {
        if (c1.x == c2.x) {
            return c1.y < c2.y;
        } else return c1.x < c2.x;
    } else return c1.distance < c2.distance;
}

int main() {
    Coordenate base;
    int n;
    cin >> base.x >> base.y;
    cin >> n;
    vector<Coordenate> coordenates(n);
    for (int i = 0; i < n; ++i) {
        cin >> coordenates[i].x >> coordenates[i].y;
        coordenates[i].distance = abs(coordenates[i].x - base.x) + abs(coordenates[i].y - base.y);
    }
    sort(coordenates.begin(), coordenates.end(), comp);
    int pos = -1;
    for (int i = 0; i < n; ++i) {
        if (pos < coordenates[i].distance) {
            pos = coordenates[i].distance;
            cout << "punts a distancia " << coordenates[i].distance << endl;
        }
        cout << coordenates[i].x << ' ' << coordenates[i].y << endl;
    }
}

