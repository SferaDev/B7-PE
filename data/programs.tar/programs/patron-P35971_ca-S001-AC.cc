#include <iostream>
#include <vector>
using namespace std;
 
typedef vector<vector<int> > Matriu;
 
//PRE: Entrem la matriu, i les dues posicions a partir de les quals opera
//POS: Retorna el valor de la suma de tots els elements de la l�nia entre els
//     que hem definit (ox, dx), sense incloure la primera
int suma_linia(const Matriu& mat, int of, int oc, int df, int dc) {
  int suma = 0;
  if (oc == dc) { //o estem en la mateixa columna....
     if (of < df) { // sumem descendint per la columna.
      for (int i = 1; i <= (df - of); ++i) {
       suma = suma + mat[of + i][oc];
      }
    }
     else if (of > df) {// sumem ascendint per la columna.
       for (int i = 1; i <= (of - df); ++i) {
       suma = suma + mat[of - i][oc];
      }
     } //les difercncies en quant a fila ja queden cobertes, falten les columnes
    }
   else { // o en la mateixa fila...
    if (oc > dc) {// sumem en sentit "<-"
      for (int i = 1; i <= (oc - dc); ++i) {
      suma = suma + mat[of][oc - i];
     }
     }
    else if (df == of) {// sumem en sentit "->"
     for (int i = 1; i <= (dc - oc); ++i) {
       suma = suma + mat[of][oc + i];
      }
    }
    }
    return suma;
}
 
int main() {
 int n, m, of, oc, df, dc;
 cin >> n >> m;
 Matriu mat (n, vector<int> (m));
 for (int i = 0; i < n; ++i){
    for (int j = 0; j < m; ++j) cin >> mat[i][j];
  }
 cin >> of >> oc;
 int suma = mat[of][oc]; // la funci� no pot incloure el primer element x def.
 while (cin >> df >> dc) {
 suma += suma_linia (mat, of, oc, df, dc);
 of = df;
 oc = dc;
 }
 cout << "suma = " << suma << endl;
}
