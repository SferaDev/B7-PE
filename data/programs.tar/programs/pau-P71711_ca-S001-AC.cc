#include <iostream>
#include <vector>
using namespace std;

typedef vector <int> Fila;
typedef vector <Fila> Matriu;

bool creixent (Matriu& M) {
  int n = M.size();
  int m = M[0].size();
  bool parell = true;
  bool primer = true;
  int ant = M[0][0];
  for (int i = 0; i < m; ++i) {
    if (parell) {
      if (primer) {
        for (int j = 1; j < n; ++j) {
          if (M[j][i] <= ant) return false;
          ant = M[j][i];
        }
        primer = false;
      } else {
        for (int j = 0; j < n; ++j) {
          if (M[j][i] <= ant) return false;
          ant = M[j][i];
        }
      }
      parell = false;
    } else {
      for (int j = n - 1; j >= 0; --j) {
        if (M[j][i] <= ant) return false;
        ant = M[j][i];
      }
      parell = true;
    }
  }
  return true;
}

void llegix_matriu (Matriu& M) {
  int n = M.size();
  int m = M[0].size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      cin >> M[i][j];
    }
  }
}

int main () {
  int cont = 0;
  int n,m;
  while (cin >> n >> m) {
    ++cont;
    Matriu M(n, Fila(m));
    llegix_matriu(M);
    cout << "matriu " << cont << ": ";  
    if (creixent(M)) cout << "si" << endl;
    else cout << "no" << endl;   
  }
}
