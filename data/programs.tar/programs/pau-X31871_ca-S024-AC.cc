#include <iostream>
#include <vector>
using namespace std;

struct Cell {
  int contingut;        // nombre de chips
  string veins;         // descripci贸 de les posicions veines accessibles
};
 
typedef  vector< vector<Cell> >  Joc;

void llegeix_xips (Joc& J) {
  int n = J.size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      cin >> J[i][j].contingut;
    }
  }
}

void llegeix_accesible (Joc& J) {
  int n = J.size() - 1;
  for (int i = 1 ; i < n; ++i) {
    for (int j = 1; j < n; ++j) {
      cin >> J[i][j].veins;
    }
  }
}

void calcula_posicio (Joc& J,int i, int j, int& cont) {
  Cell act = J[i][j];
  int x = act.veins.size();
  int n = J.size() - 1;
  for (int k = 0; k < x; k += 2) {
    if (act.veins[k] == 'N' and act.veins[k+1] == 'W') {
      ++J[i-1][j-1].contingut;
      if (i - 1 == 0 or j - 1 == 0) ++cont;
    }
    if (act.veins[k] == 'N' and act.veins[k+1] == 'N') {
      ++J[i-1][j].contingut;
      if (i - 1 == 0) ++cont;
    }
    if (act.veins[k] == 'N' and act.veins[k+1] == 'E') {
      ++J[i-1][j+1].contingut;
      if (i - 1 == 0 or j + 1 == n) ++cont;
    }
    if (act.veins[k] == 'W') {
      ++J[i][j-1].contingut;
      if (j - 1 == 0) ++cont;
    }
    if (act.veins[k] == 'E') {
      ++J[i][j+1].contingut;
      if (j + 1 == n) ++cont;
    }
    if (act.veins[k] == 'S' and act.veins[k+1] == 'W') {
      ++J[i+1][j-1].contingut;
      if (i + 1 == n or j - 1 == 0) ++cont;
    }
    if (act.veins[k] == 'S' and act.veins[k+1] == 'S') {
      ++J[i+1][j].contingut;
      if (i + 1 == n) ++cont;
    }
    if (act.veins[k] == 'S' and act.veins[k+1] == 'E') {
      ++J[i+1][j+1].contingut;
      if (i + 1 == n or j + 1 == n) ++cont;
    }
  }
}       

bool calcula_canvis (Joc& J, int& cont) {
  int n = J.size() - 1;
  bool canvis = false;
  for (int i = 1; i < n; ++i) {
    for (int j = 1; j < n; ++j) {
      if (J[j][i].contingut >= J[j][i].veins.size()/2) {
        calcula_posicio (J,j,i,cont);
        canvis = true;
        J[j][i].contingut -= (J[j][i].veins.size()/2); 
      }
    }
  }
  return canvis;
}

void imprimeix_Matriu (Joc& J) {
  int n = J.size();
  for (int i = 0; i < n; ++i) {
    cout << J[i][0].contingut;
    for (int j = 1; j < n; ++j) {
      cout << ' ' << J[i][j].contingut;
    }
    cout << endl;
  }
}

int main () {
  int n; cin >> n;
  Joc J(n, vector<Cell> (n));
  llegeix_xips(J);
  llegeix_accesible(J);
  int cont = 0;
  bool canvis = calcula_canvis (J,cont);
  imprimeix_Matriu(J); 
  cout << "canvis: ";
  if (canvis) cout << "si" << endl;
  else cout << "no" << endl;
  cout << "chips nous fora: " << cont << endl; 
}
