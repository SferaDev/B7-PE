#include <iostream>
#include <vector>

using namespace std;

bool resistant_search(double x, const vector<double>& v, int esquerra, int dreta)
{
  if(esquerra > dreta) return false;
  int meitat = (esquerra + dreta)/2;
  if(v[meitat] > x) return ((meitat+1 <= dreta and v[meitat+1] == x) or resistant_search(x,v,esquerra,meitat-1));
  else if(v[meitat] < x) return ((meitat-1 >= esquerra and v[meitat-1] == x) or resistant_search(x,v,meitat+1,dreta));
  else return true;
}

bool resistant_search(double x, const vector<double>& v)
{
  return resistant_search(x,v,0,v.size()-1);
}

int main()
{
  vector<double> v(10);
  for(int i = 0; i < v.size(); ++i){
    cin >> v[i];
  }
  int x;
  cin >> x;
  if(resistant_search(x,v)) cout << "Hi es" << endl;
  else cout << "No hi es" << endl;
}