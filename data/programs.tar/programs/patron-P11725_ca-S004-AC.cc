#include <iostream>
#include <vector>

using namespace std;

bool hi_es(int x, const vector <int>& v)
{
  int cont=0;
  int k=v.size();
  while (cont<k){
    if (x==v[cont]) return true;
    ++cont;
  }
  return false;
}