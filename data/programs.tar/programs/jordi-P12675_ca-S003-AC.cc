#include <iostream>
#include <vector>

using namespace std;

int elements_comuns (const vector<int>& X, const vector<int>& Y){
  int j=0;
  int i=0;
  int cont=0;
  while (j<X.size() and i<Y.size()){
    if (X[j]>Y[i]) ++i;
    else if (X[j]<Y[i]) ++j;
    else if (X[j]==Y[i]){
      ++j;
      ++i;
      ++cont;
    }
  }
  return cont;
}
   
int main (){
  int n;
  cin >> n;
  vector<int> X(n);
  vector<int> Y(n);
  for (int i=0; i<n; ++i){
    int y;
    cin >> y;
    X[i]=y;
  }
  for (int i=0; i<n; ++i){
    int y;
    cin >> y;
    Y[i]=y;
  }
  cout << elements_comuns (X,Y)<< endl;
}