#include <iostream>

using namespace std;

int main ()
{
  int a,b;
  cin>>a>>b;
  int i=a;
  if (a==b) cout<<a<<endl;
  else if (a>b) cout<<endl;
  else if (a<b) {
    while (i<b){
      cout<<a<<",";
      ++i;
      ++a;
    }
    cout<<b<<endl;
  }
}