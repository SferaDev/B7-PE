#include <iostream>
using namespace std;

int main() {
   int n, x, r;
   bool primer = true;
   while (cin >> n) {
    if (primer) primer = false;
    else cout << endl;
    for (int j = 1; j<=n; ++j) {
        for (int i = 1; i<=n; ++i) {
            if (j>i) x = j - i;
            else x = i - j;
            if (x > i-1) x = i-1;
            if (x > j-1) x = j-1;
            if (x > n-i) x = n-i;
            if (x > n-j) x = n-j;
            r = i+j-n-1;
            if (r<0) r = -r;
            if (x > r) x = r;
            cout << x%10;
        }
        cout << endl;
    }
   }
}
