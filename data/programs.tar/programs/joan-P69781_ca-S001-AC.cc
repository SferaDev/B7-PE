#include <iostream>
#include <map>
using namespace std;


int main(){
	int x, y, n;
	while(cin >> x >> y >> n){
	int cont = 1;
	int act = n;
	map<int,int> mv;
	map<int,int> :: iterator it;
	mv[n] = 0;
	bool cicle = false;
	while (not cicle and act <= 100000000){
		if (act%2 == 0){
			act = (act/2) + x;
			//cout << act << endl; //chivato
			it = mv.find(act);
			if (it == mv.end()){
				//cout << "entra" <<endl; // chivato
				mv[act] = cont;
				++ cont;
			}
			else {
				cicle = true;
				cout << cont - it->second << endl;
			}
		}
		else {
			act = 3*act+ y;
			//cout << act << endl; //chivato
			it = mv.find(act);
			if (it == mv.end()){
				mv[act] = cont;
				++ cont;
			}
			else {
				cicle = true;
				cout << cont - it->second << endl;
			}
		}
		//cout << act <<' ' << cont << endl; //chivato

	}
	if (act > 10000000) cout << act << endl; 
	}

}