#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<string> read_vector(int size){
    vector <string> v(size);
    for (int i = 0; i < size; ++i){
        cin >> v[i];
    }
    return v;
}

int main(){
    int n,p,k;
    cin >> n >> p >> k;
    char b;
    cin >> b;
    vector <string> v=read_vector (n);
    for (int i = 1; i <= k; ++i) {
        int position;
        if (b == 'd') position = p + i;
        else position = p - i;
        while (position < 0) position += n;
        while (position >= n) position -= n;
        cout << v[position];
        if (i != k) cout << " ";
    }
    cout << endl;
}