#include <iostream>

using namespace std;

int main ()
{
  int n;
  cin >> n;
  int sumab=0;
  int suman=0;
  for (int i=0; i<n; ++i){
    for (int j=0; j<n; j++){
      char c;
      cin >> c;
      int d=c-'0';
      if ((i+j)%2==0)
	sumab+=d;
      else suman+=d;
    }
  }
  cout << sumab << "-" << suman << " = " << sumab-suman <<endl;
}