#include <iostream>
#include <vector>
#include <map>

using namespace std;

typedef vector < vector <int> > graph;
typedef vector < vector <bool> > vis;

int sum (const graph &g, map <int, pair <pair <int, int> ,bool> > &M, vis &visit, int i, int j, int &cont){
	visit[i][j] = true;
	if (g[i][j] == -1) return 0;
	int suma = g[i][j];
	int n = g.size();
	int m = g[0].size();
	M[i*m + j].second = true;
	++cont;
	if (j > 0 and i > 0 and !visit[i-1][j-1]) suma += sum(g,M,visit,i-1,j-1,cont);
	if (j > 0 and i < n - 1 and !visit[i+1][j-1]) suma += sum(g,M,visit,i+1,j-1,cont);
	if (j < m-1 and i > 0 and !visit[i-1][j+1]) suma += sum(g,M,visit,i-1,j+1,cont);
	if (j < m-1 and i < n-1 and !visit[i+1][j+1]) suma += sum(g,M,visit,i+1,j+1,cont);
	return suma;
}

void read (graph &g, map <int, pair <pair <int, int> ,bool> > &M)
{
	int n = g.size();
	int m = g[0].size();
	for (int i = 0; i < n; ++i){
		for (int j = 0; j < m; ++j){
			int x;
			string s; cin >> s;
			if(s == "X") x = -1;
			else x = atoi(s.c_str());
			g[i][j] = x;
			if (x != -1) M[i*m + j] = make_pair(make_pair(i,j),false);
		}
	}
}

int main(){
	int cas; 
	cin >> cas;
	for (int i = 0; i < cas; ++i){
		
		int n, m; 
		cin >> n >> m;

		graph g(n, vector<int>(m));
		map <int, pair <pair <int, int> ,bool> > M;
		
		vis visit(n, vector<bool>(m,false));
		
		read(g,M);
		
		bool bi = true;
		bool first = true;
		int ant;
		
		for(auto it = M.begin(); it != M.end() and bi; ++it){
			if (not it->second.second){

				int cont = 0;
				int suma = sum(g,M,visit,it->second.first.first,it->second.first.second,cont);
		
				if (not first) 
					bi = ((suma % cont == 0) and (suma/cont == ant));
				else{
					first = false;
					ant = suma/cont;
					bi = (suma % cont == 0);
				}
			}
		}
		
		cout << "Case " << i + 1;
		if (bi) cout << ": yes" << endl;
		else cout << ": no" << endl;
	}
}
