#include <iostream>
#include <vector>
 
using namespace std;
 
void ordena_per_bombolla(vector<double>& v) {
    int i = 1;
    int n = v.size();
    bool ordenado = false;
    while (i < n and not ordenado) {
        ++i;
        ordenado = true;
        for (int j = 0; j <= n - i; ++j) {
            if (v[j] > v[j+1]) {
                ordenado = false;
                int aux = v[j];
                v[j] = v[j + 1];
                v[j + 1] = aux;
            }
        }
    }
}
 
int main() {
    vector<double> v(5);
    for (int i = 0; i < 5; ++i) {
        cin >> v[i];
    }
    ordena_per_bombolla(v);
    for (int i = 0; i < 5; ++i) {
        cout << v[i] << endl;
    }
}