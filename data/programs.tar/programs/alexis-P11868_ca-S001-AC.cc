#include <iostream>
#include <vector>
using namespace std;

vector<int> readInput(int size) {
    vector<int> result(size);
    for (int i = 0; i < size; ++i) {
        int n;
        cin >> n;
        result[i] = n;
    }
    return result;
}

void printVector(vector<int>& vector) {
    bool first = true;
    for (int i = 0; i < vector.size(); ++i) {
        if (!first) cout << ' ';
        cout << vector[i];
        first = false;
    }
    cout << endl;
}

int main() {
    int size;
    cin >> size;
    vector<int> input = readInput(size);
    vector<int> sortedInput(size);
    for (int i = 0; i < size; ++i) {
        int n;
        cin >> n;
        sortedInput[n] = input[i];
    }
    printVector(sortedInput);
}