#include <iostream>
#include <vector>

using namespace std;

int posicio(double x, const vector<double>& v, int esq, int dre)
{
  if(esq>dre) return -1;
  int meitat= (esq+dre)/2;
  if(v[meitat] == x) return meitat;
  if(v[meitat] < x) return posicio(x,v,meitat+1,dre);
  return posicio(x,v,esq,meitat-1);
}