#include <iostream>
#include <vector>
using namespace std;

typedef vector<string> Fila;
typedef vector<Fila> Matriu;
    
int nombre_de_paraules(const Matriu& m, char c, int k){
    int cont = 0;
    int n = m.size();
    for (int i=0;i < n; ++i){
        for (int j=0;j < m[i].size();++j){
            if (k < m[i][j].size() and m[i][j][k] == c) ++cont;
        } 
    }
    return cont;
}
