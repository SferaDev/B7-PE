#include <iostream>
#include <cmath>
#include <math.h>

using namespace std;

int logaritmo(int b, int n)
{
  int e=0;
  int p=1;
  while (p*b<=n){
    e++;
    p*=b;
  }
  
  return e;
}

int main()
{
  int b, n;
  while (cin>>b>>n)
    cout<<logaritmo(b,n)<<endl;
}
