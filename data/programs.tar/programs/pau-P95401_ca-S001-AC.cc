#include <iostream>
using namespace std;
// any bis :dib per 4, si no es dibisible per 100, si es dibisible per 100 i 400 


bool es_any_de_traspas (int any) {
  bool trespas;
  if (any%4 == 0) {
    if (any%100 == 0) {
      if (any%400 == 0) trespas = true;
      else trespas = false;
    }
    else trespas = true; 
  }
  else trespas = false;
  return trespas;
}


int main() {
  int any;
  while (cin >> any) es_any_de_traspas(any);
}
