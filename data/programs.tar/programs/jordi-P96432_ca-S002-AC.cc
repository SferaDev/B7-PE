#include <iostream>
#include <vector>
#include <algorithm>
   
using namespace std;
//ordenar = n.logn 
// busq dicotomica = log n
struct Amics {
  string nom;
  string rebre;
  int gasto;
  int diferencia;
};

typedef vector <Amics> Amic;


void llegeix_vector (Amic& p) {
  for ( int i = 0; i < p.size(); ++i) {
    cin >> p[i].nom >> p[i].rebre >> p[i].gasto;
  }
}


bool nom ( Amics a, Amics b) {
  return a.nom < b.nom;
}

bool rebre ( Amics a, Amics b) {
  return a.rebre < b.rebre;
}

bool fi (Amics a, Amics b) {
  if ( a.diferencia == b.diferencia) return a.nom < b.nom;
  return a.diferencia < b.diferencia;
}

int posicio(string x, const Amic& p, int esq, int dre) {
  if ( esq > dre) return -1;
  int pos = (esq+dre)/2;
  if ( x < p[pos].rebre) return posicio (x,p,esq,pos - 1);
  if ( x > p[pos].rebre) return posicio (x,p,pos + 1,dre);
  return pos;
}


void saldo (Amic& p) {
  int n = p.size();
  for ( int i = 0; i < n ; ++i) {
    int pos = posicio (p[i].nom, p, 0, n - 1);
    p[i].diferencia = p[pos].gasto - p[i].gasto;
  }
}

void imprimeix (const Amic& p) {
  int n = p.size();
  for ( int i = 0; i < n ; ++i) {
    cout << p[i].nom << " " << p[i].diferencia << endl;
  }
}
  
  
int main () {
  int n;
  cin >> n;
  for ( int i = 0; i < n; ++i) {
    int m;
    cin >> m;
    Amic p(m);
    llegeix_vector(p);    
    sort (p.begin(),p.end(), nom);
    sort (p.begin(),p.end(), rebre);
    saldo (p);    
    sort (p.begin(),p.end(), fi);
    imprimeix (p);
    cout << endl;
  }
}


//cerr (para que vuelque toda la informacion que tiene en los bapers)
	 
