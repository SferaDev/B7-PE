#include <vector>
#include <iostream>
using namespace std;

typedef vector< vector<char> > Mapa;
typedef vector< vector<bool> > Visita;
int n, m;

void imprimir(const vector<char> &res, int j) {
	for (int i = 0; i <= j; ++i) {
		cout << res[i];
	}
	cout << endl;
}

void dfs(const Mapa &mapa, Visita &vis, vector<char> &res, int fila, int col, int f, int c, int i) {
	res[i] = mapa[f][c];
	if (fila == f and col == c) {
		imprimir(res, i);
	}
	else {
		if (f > 0 and not vis[f-1][c]) {
			//cout << f << " " << c << " -> " << f-1 << c << endl;
			//imprimir(res, i-1);
			vis[f-1][c] = true;
			dfs(mapa, vis, res, fila, col, f-1, c, i+1);
			vis[f-1][c] = false;
		}
		if (f < n-1 and not vis[f+1][c]) {
			//cout << f << " " << c << " -> " << f+1 << c << endl;
			//imprimir(res, i-1);
			vis[f+1][c] = true;
			dfs(mapa, vis, res, fila, col, f+1, c, i+1);
			vis[f+1][c] = false;
		}
		if (c > 0 and not vis[f][c-1]) {
			//cout << f << " " << c << " -> " << f << c-1 << endl;
			//imprimir(res, i-1);
			vis[f][c-1] = true;
			dfs(mapa, vis, res, fila, col, f, c-1, i+1);
			vis[f][c-1] = false;
		}
		if (c < m-1 and not vis[f][c+1]) {
			//cout << f << " " << c << " -> " << f << c+1 << endl;
			//imprimir(res, i-1);
			vis[f][c+1] = true;
			dfs(mapa, vis, res, fila, col, f, c+1, i+1);
			vis[f][c+1] = false;
		}
	}
}

int main() {
	cin >> n >> m;
	Mapa mapa = vector<vector<char> >(n, vector<char>(m));
	Visita vis = vector<vector<bool> >(n, vector<bool>(m, false));
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j)
			cin >> mapa[i][j];
	}
	int fila, col, f, c;
	cin >> f >> c >> fila >> col;
	vector<char> res(n*m);
	vis[f][c] = true;
	dfs(mapa, vis, res, fila, col, f, c, 0);
}
