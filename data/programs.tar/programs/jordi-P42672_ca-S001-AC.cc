#include <iostream>

using namespace std;

void barrejant(int x, int y){
  if ( x==1 and y==1 ) {
    cout << x << y;
  }else if (x>0 and y>0){
    barrejant (x/2,y/2);
    cout << x%2 << y%2;
  }
}
 
int main(){
  int x,y;
  while( cin >> x >> y){
    barrejant(x,y);
    cout << endl;
  }
}