#include <iostream>
#include <vector>
using namespace std;

int posicio(double x, const vector<double>& v, int esq, int dre);

int first_occurrence(double x, const vector<double>& v){
  int ini = 0;
  int fin = v.size()-1;
  int k = posicio(x, v, ini, fin);
  return k;
}

int posicio(double x, const vector<double>& v, int esq, int dre) {
    if (esq > dre) return -1;
    if (esq == dre){
      if (v[esq] == x) return esq;
      else return -1;
    }
    else {
      int pos = (esq + dre)/2;        // posicio central de v[esq..dre
      if (x > v[pos]) return posicio(x, v, pos + 1, dre);
      else return posicio(x, v, esq, pos);
    }
}

