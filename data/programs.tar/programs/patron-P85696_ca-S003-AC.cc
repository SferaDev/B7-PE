#include <iostream>


using namespace std;

struct Racional{
  int num, den;
};

int mcd(int a, int b)
{
  while(b!=0){
    int r=a%b;
    a = b;
    b = r;
  }
  return a;
}


Racional racional(int n, int d)
{
  Racional racional_normalitzat;
  
  if (n==0){ //Numerador = 0
    racional_normalitzat.den = 1;
    racional_normalitzat.num = 0;
    return racional_normalitzat;
  }
  else {
    
    int maxmcd=mcd(n,d);
    
    racional_normalitzat.num = n/maxmcd;
    racional_normalitzat.den = d/maxmcd;
    
    if (racional_normalitzat.den<0){
      racional_normalitzat.den*=-1;
      if (racional_normalitzat.num>0)
	racional_normalitzat.num*=-1;
    }
  }
  return racional_normalitzat;
}
