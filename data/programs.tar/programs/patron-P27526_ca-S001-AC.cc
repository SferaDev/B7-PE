#include <iostream>
#include <vector>
using namespace std;
 
typedef vector< vector<int> > Matrix;
 
void swap(Matrix& mat, int j, int k) {
    for (int i = 0; i < mat.size(); ++i) {
      int value = mat[i][j];
      mat[i][j] = mat[i][k];
      mat[i][k] = value;
    }
}
 
void dashes() {
  cout << "-----" << endl;
}
 
void print_mat(Matrix& mat, int n, int m) {
  for (int i = 0; i < n; ++i) {
    cout << mat[i][0];
    for (int j = 1; j < m; ++j) {
      cout << " " << mat[i][j];
    }
    cout << endl;
  }  
}
 
int main() {
  int n, m;
  cin >> n >> m;
  Matrix mat(n,vector<int>(m));
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) cin >> mat[i][j];
  }
 
  dashes();
  print_mat(mat,n,m);
  dashes();
 
  int j,k;
  while (cin >> j >> k) {
    swap(mat,j,k);
    print_mat(mat,n,m);
    dashes();    
  }
}
