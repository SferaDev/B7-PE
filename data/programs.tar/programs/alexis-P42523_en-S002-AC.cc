#include <iostream>
using namespace std;

int gcd(int a, int b) {
    if (a != 0 && b != 0) return gcd(b, a%b);
    else if (a == 0) return b;
    return a;
}