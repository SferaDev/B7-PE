#include <iostream>
#include <vector>

using namespace std;

typedef vector<vector<int> > Matriu;

int min(int a, int b)
{
  if(a<b) return a;
  return b;
}

int max(int a,int b)
{
  if (a>b) return a;
  return b;
}

int main()
{
  int n,m;
  int cebollas=0;
  while (cin>>n>>m){
    ++cebollas;
    Matriu v(n,vector<int> (m));
    int mesgran,mespetit;
    for (int i=0;i<n;i++) {
      for (int j=0;j<m;j++) {
	cin>>v[i][j];
	if (i==0 and j==0) mesgran=mespetit=v[i][j];
	else {
	  mesgran=max(mesgran,v[i][j]);
	  mespetit=min(mespetit,v[i][j]);
	}
      }
    }
    int numcapes=(min(n,m)+1)/2;
    vector<int>maxim(numcapes,mespetit);
    vector<int>minim(numcapes,mesgran);
    for (int i=0;i<n;i++){
      for (int j=0;j<m;j++){
	int capa=min(min(j,m-1-j),min(i,n-1-i));
	maxim[capa]=max(maxim[capa],v[i][j]);
	minim[capa]=min(minim[capa],v[i][j]);
      }
    }
    cout<<"matriu "<<cebollas<<":";
    for (int k=0; k<numcapes;++k)
      cout<<" "<<minim[k]<<","<<maxim[k];
    cout<<endl;
  }
}