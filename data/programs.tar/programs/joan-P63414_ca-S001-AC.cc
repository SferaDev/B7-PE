/*#include <iostream>
#include <vector>
using namespace std;
typedef vector <int> vec;

int main() {
    int n;
    cin>>n;
    vec v1 (n);
    for (int i=0;i<n;++i)cin>>v1[i];
    for (int i=0; i<n; ++i){
        int valor=v1[i];
        int cont=0;
        for (int l=0; l<n; ++l){
            if (v1[l]==valor)++cont;
        }cout<<valor<<" : "<<cont<<endl;
    }
}*/
#include <iostream>
#include <vector>
using namespace std;
 
 
int main () {
        int n;
        cin >> n;
        vector <int> A(1001);
               
        int a;
        for (int i = 0; i < n; ++i) {   //IMPUT VECTOR
                cin >> a;
                a = a - 1000000000;
                ++A[a];
        }
       
        for (int i = 0; i < A.size(); ++i) {    //IMPUT VECTOR
                if (A[i] != 0) {
                        cout << 1000000000 + i << " : " << A[i] << endl;
                }
        }
}