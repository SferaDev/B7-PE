#include <iostream>

using namespace std;

bool es_guai(int n, int b) {
  bool guai;
  if ((n%b)%2!=0){
    return guai=false;
  }
  else if (n/b==0) return guai=true;
  else{
    n=n/b;
    return guai=es_guai(n,b);
  }
}
int main(){
  int n,b;
  cin >> n >> b;
  bool guai;
  guai=es_guai(n,b);
  if (guai) cout << "ok" << endl;
  else cout << "mierda " << endl;
}
