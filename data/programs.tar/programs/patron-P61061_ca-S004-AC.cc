#include <iostream>

using namespace std;

int producto(int n)
{
    int sum=1, r=0;
    while (n>0){
        r=n%10;
        sum=sum*r;
        n=n/10;
    }
    return sum;
}

int main()
{
    int n;
    while (cin>>n){
        if (n<10)
            cout<<"El producte dels digits de "<<n<<" es "<<n<<"."<<endl;
        while (n>=10){
            cout<<"El producte dels digits de "<<n<<" es "<<producto(n)<<"."<<endl;
            int z=producto(n);
            n=z;
        }
        cout<<"----------"<<endl;
    }
}

