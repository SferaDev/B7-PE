#include <iostream>
#include <vector>
using namespace std;

struct Parell {
  int valor;                           
  int pos;
};

typedef vector<Parell> Vec_Com;

void imprimeix (const Vec_Com& v) {
  cout << v.size();
  for (int i = 0; i < v.size(); ++i) {
    cout << ' ' << v[i].valor << ';' << v[i].pos;
  }
  cout << endl;
}

Vec_Com suma(const Vec_Com& v1, const Vec_Com& v2){
  int n1 = v1.size();
  int n2 = v2.size();
  Vec_Com v3(n1 + n2);
  int i,j,k;
  i=j=k=0;
  while (i < n1 and j < n2) {
    if (v1[i].pos < v2[j].pos) {
      v3[k] = v1[i];
      ++i;
      ++k;
    } else if (v2[j].pos < v1[i].pos) {
      v3[k] = v2[j];
      ++j;
      ++k;
    } else if (v1[i].valor + v2[j].valor != 0) {
      v3[k].pos = v1[i].pos;
      v3[k].valor = v1[i].valor + v2[j].valor;
      ++j;
      ++k;
      ++i;
    } else {
      ++j;
      ++i;
    }
  } 
  while (i < n1) {
    v3[k]=v1[i];
    ++k;
    ++i;
  }
  while (j < n2) {
    v3[k]=v2[j];
    ++k;
    ++j;
  }
  Vec_Com resultat(k);
  for (int l = 0; l < k; ++l) {
    resultat[l] = v3[l];
  }
  return resultat;
}

void llegeix(Vec_Com& v) {
  char c;
  for (int i = 0; i < v.size(); ++i) {
    cin >> v[i].valor >> c >> v[i].pos;
  }
}

int main () {
  int n;
  cin >> n;
  for (int i = 0; i < n; ++i) {
    int a;
    cin >> a;
    Vec_Com v1(a);
    llegeix(v1);
    int b;
    cin >> b;
    Vec_Com v2(b);
    llegeix(v2);
    Vec_Com res;
    res = suma(v1,v2);
    imprimeix(res);  
  }
}
