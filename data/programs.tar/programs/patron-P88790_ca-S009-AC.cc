#include <iostream>

using namespace std;

int mcd(int a, int b)
{
  //int aux;
  
  if (a==0) return b;
  if (b==0) return a;
  
  /*if (a < b) {
    aux=a;
    a=b;
    b=aux;
  }*/
  if (a<b) swap (a,b);
  
  int residuo;
  
  while (b !=0 ){
    
    residuo = a % b;
    a=b;
    b=residuo;
  }
  return a;
}


int main ()
{
  int a,b;
  cin >> a >> b;
  cout << mcd(a,b) << endl;
}