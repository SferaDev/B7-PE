#include <iostream>

using namespace std;

int main ()
{
  int primer;
  cin>>primer;
  cout<<"nombres que acaben igual que "<<primer<<":"<<endl;
  int x;
  int total=0;
  while (cin>>x) {
    if (x%1000 == primer%1000){
      cout<<x<<endl;
      total++;
    }
  }
  cout<<"total: "<<total<<endl;
 }
