#include <iostream>
using namespace std;

char complement (char c){
    if (c=='A') return 'T';
    if (c=='T') return 'A';
    if (c=='C') return 'G';
    else return 'C';
}
int main (){
    char w1,w2,w3;
    cin>>w1>>w2;
    bool write=false;
    while (cin>>w3){
        if (not write and w1=='T' and w2=='A' and w3=='G') write=true;
        else if (write) cout<<complement(w3);
        w1=w2;
        w2=w3;
    }cout<<endl;
}