#include <iostream>
#include <vector>
#include <string>

using namespace std;

typedef vector<vector<char> > Sopa;

const int canvi_min_mayus = 'a'-'A';

void marcar_palabra(int y,int x,Sopa& s, int media, int dir)
{
  if (dir == 1){
    //Horitzontal
    for(int i = 0; i < media; ++i){
      if(s[y][x] >= 'a' and s[y][x] <= 'z')
	s[y][x] = s[y][x] - canvi_min_mayus;
      ++x;
    }
  }
  
  else if(dir == 2){
    //Vertical
    for(int i = 0;i < media; ++i){
      if(s[y][x]>='a' and s[y][x]<='z')
	s[y][x] = s[y][x] - canvi_min_mayus;
      ++y;
    }
  }

  else{
    //Diagonal
    for(int i = 0; i < media; ++i){
      if(s[y][x] >= 'a' and s[y][x]<='z')
	s[y][x] = s[y][x] - canvi_min_mayus;
      ++y;
      ++x;
    }
  }
}

void find_word(int y, int x,Sopa& s, string p)
{
  int nfil=s.size(),ncol=s[0].size();
  
  if(s[y][x] == p[0] or s[y][x] + canvi_min_mayus == p[0]){
    int medida_p = p.size();
    
    //Horitzontal
    if( ncol-x >= medida_p){
      int i = x+1;
      int j = 1;
      while(j < medida_p and (s[y][i] == p[j] or 
	s[y][i] + canvi_min_mayus == p[j])){
	++i;
	++j;
      }
      if(j==medida_p)
	marcar_palabra(y,x,s,medida_p,1);
    }
    
    //Vertical
    if(nfil-y >=medida_p){
      int i = y+1;
      int j = 1;
      while(j < medida_p and (s[i][x] == p[j] or 
	s[i][x] + canvi_min_mayus == p[j])){
	++i;
	++j;
      }
      if(j==medida_p)
	marcar_palabra(y,x,s,medida_p,2);
    }
    
    //Diagonal
    if(ncol-x >= medida_p and nfil-y >= medida_p){
      int i = x+1;
      int j = y+1;
      int l = 1;
      while(l<medida_p and (s[j][i] == p[l] or 
	s[j][i] + canvi_min_mayus == p[l])){
	++i;
	++j;
	++l;
      }
      if (l == medida_p)
	marcar_palabra(y,x,s,medida_p,3);
    }
  }
}

int main()
{
  int x,m,n;
  bool primer=true;
  while(cin >> x >> m >> n){
    
    vector<string> palabra(x);
    for(int i = 0; i < x; ++i){
      cin >> palabra[i];
    }
    
    Sopa s(m,vector<char>(n));
    for(int i = 0; i < m; ++i){
      for(int j = 0;j < n; ++j){
	cin >> s[i][j];
      }
    }
    
    for(int i = 0; i < m; ++i){
      for(int j = 0; j < n; ++j){
	if(s[i][j] >= 'a' and s[i][j] <= 'z'){
	  for(int p = 0;p < x; ++p){
	    find_word(i,j,s,palabra[p]);
	  }
	}
      }
    }
    
    if(primer) primer=false;
    else cout << endl;
    for(int i=0;i<m;++i){
      cout << s[i][0];
      for(int j = 1; j < n; ++j){
	cout << ' ' << s[i][j];
      }
      cout << endl;
    }
  }
}