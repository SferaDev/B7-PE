#include <iostream>
#include <math.h>
using namespace std;

int main() {
  cout.setf(ios::fixed);
  cout.precision(2);
  int n;
  cin >> n;
  double nombres[n];
  for (int i = 0; i < n; ++i) {
      cin >> nombres[i];        
  }
  double sumat1 = 0;
  double sumat2 = 0;
  for (int i = 0; i < n; ++i) {
      sumat1 += pow(nombres[i],2);  
  }     
  for (int i = 0; i < n; ++i) {
      sumat2 += nombres[i];  
  }
  sumat2 = pow(sumat2,2);
  double A;
  double B;
  double r = n;      
  A = 1/(r-1);
  B = 1/(r*(r-1));      
  cout << A*sumat1 - B*sumat2 << endl;                                                                  
} 
