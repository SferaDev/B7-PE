#include <iostream>
#include <string>
#include <vector>
using namespace std;
 
struct persona{
       string nom;
       int edat;
};
 
void ordena_per_bombolla(vector<persona>&v){
     int n = v.size();
     for( int i = 0; i < n-1; ++i){
          for(int j = n-1; j > i; --j){
                 if(v[j-1].edat == v[j].edat){
                         if(v[j-1].nom > v[j].nom){
                                       swap(v[j-1],v[j]);
                                       }
                         }
                         if(v[j-1].edat < v[j].edat){
                                        swap(v[j-1],v[j]);
                                        }
                         }
}
}
 
 
 
int main() {
        int x;
        while (cin >> x) {
                vector<persona> v(x);
                for (int i = 0; i < x; ++i) {
                        cin >> v[i].nom >> v[i].edat;
                }
                ordena_per_bombolla(v);
                for (int j = 0; j < x; ++j) {
                        cout << v[j].nom << " " << v[j].edat << endl;
                }
        }
}
