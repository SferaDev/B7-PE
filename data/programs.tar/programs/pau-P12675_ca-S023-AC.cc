#include <iostream>
#include <vector>
using namespace std;

int elements_comuns (const vector<int>& X, const vector<int>& Y){
  int i = 0;
  int j = 0;
  int cont = 0;
  while (i < X.size() and j < Y.size ()) {
    if (X[i] < Y[j]) ++i;
    else if (Y[j] < X[i]) ++j;
    else {
      ++cont;
      ++i;
      ++j; 
    }
  }
  return cont;
}

int main () {
  int na;
  int nb;
  cin >> na >> nb;
  vector<int> A(na);
  vector<int> B(nb);
  for (int i = 0; i < na; ++i) {
    cin >> A[i];
  }
  for (int i = 0; i < nb; ++i) {
    cin >> B[i];
  }
  cout << elements_comuns(A,B) << endl;
}
