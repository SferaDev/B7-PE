#include <iostream>
using namespace std;

/* SPEC
 * 
 * in: The input is a non-negative integer n with 0 ≤ n < 231.
 * 
 * out: The sum of the digits of the first half and the sum of the digits of the
 * second half together with their relationship, provided that the number of 
 * digits is even.
 * 
 */

 int main() {     
    // Init cin value
    string input;
    cin >> input;
    int lenght = input.size();
    
    // Init the counters
    int x, y;
    x = y = 0;
    
    // Check if cin is valid
    if (lenght%2 != 0) {
        cout << "nothing";
    } else {
        for (int i = 0; i < lenght/2; ++i) {
            x += (input[i] - '0');
        }
        for (int i = lenght/2; i < lenght; ++i) {
            y += (input[i] - '0');
        }
        
        // Print the results
        cout << x << ' ';
        if (x > y) {
            cout << '>';
        } else if (x < y) {
            cout << '<';
        } else {
            cout << '=';
        }
        cout << ' ' << y;
    }
    cout << endl;
}