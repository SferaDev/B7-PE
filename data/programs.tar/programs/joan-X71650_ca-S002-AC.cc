#include <iostream>
using namespace std;

int main(){

	int x, p = 0, n =0;

	while ( cin >> x){

		if ( x < 0){

			n = n + x;

		} else {

			p = p + x;

		}
	}

	cout << "Sum Pos: " << p << endl;
	cout << "Sum Neg: " << n << endl;
}