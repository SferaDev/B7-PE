#include <iostream>
#include <vector>
using namespace std;

void intercambia (double& a, double& b) {
  double aux = a;
  a = b;
  b = aux;
}

void ordena_per_bombolla(vector<double>& v) {
  bool ordenat = false;
  int n = v.size() - 1;
  while (not ordenat) {
    ordenat = true;
    for (int i = 0; i < n; ++i) {
      if (v[i] > v[i + 1]) {
        intercambia(v[i],v[i+1]);
        ordenat = false;
      }
    }
    --n;
  }
}

int main () {

}
