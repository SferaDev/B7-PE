#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
 
  // entrada: els diners que s'ha gastat cada persona en una altra
  // sortida: els diners que han rebut menys els q s'han gastat
 
struct Info {
  string nom;
  int diners;
};
 
  // ordenem el vector per nom
bool com1(const Info& a, const Info& b) {
  if (a.nom != b.nom) return a.nom < b.nom;
  return a.diners < b.diners; // si mateix nom, ordenem per �
}
  // ordenem el vector per diners
bool com2(const Info& a, const Info& b) {
  if (a.diners != b.diners) return a.diners < b.diners;
  return a.nom < b.nom; // si mateix �, ordenem per nom
}
 
 
int main () {
  int n;
  cin >> n;
  while (n > 0) {
    int m;
    cin >> m;
    vector<Info> v (2*m);
   
  // creem una vector tamany 2m per guardar totes les dades
    for(int i = 0; i < 2*m; i += 2) {
      cin >> v[i].nom >> v[i+1].nom;
      cin >> v[i+1].diners;
      v[i].diners = -v[i+1].diners;
    }
   
  // ordenem les dades per nom  
    sort (v.begin(),v.end(), com1);
   
  // recorrem la taula i ho guardem en una altra de tamany m
    vector<Info> T(m);
    for (int i = 0; i < m; ++i) {
      T[i].nom = v[2*i].nom;
      T[i].diners = v[2*i].diners + v[2*i + 1].diners;
    }
   
  // ordenem les dades per diners    
    sort (T.begin(), T.end(), com2);
   
    for (int i = 0; i < m; ++i) {
      cout << T[i].nom << " " << T[i].diners << endl;
    }
   
    --n;
    cout << endl;
  }
}
