#include <iostream>
using namespace std;

int factorial_doble(int n)
{
	int fact = 1;
	if(n==0 or n==1) return 1;
	while(n >= 0){
		if(n == 0 or n==1) fact *= 1;
		else fact *= n;
		n -=2;
	}
	return fact;
}

int main()
{
	int n;
	while(cin >> n)
		cout << factorial_doble(n) << endl;
}
