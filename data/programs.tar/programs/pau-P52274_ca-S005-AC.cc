#include <iostream>
#include <math.h>
using namespace std;

struct Punt {
  double x, y;
};

struct Cercle {
  Punt centre;
  double radi;
};

double distancia(const Punt& a, const Punt& b) {
  return sqrt(pow(a.x-b.x,2) + pow(a.y-b.y,2));
}

void escala(Cercle& c, double esc) {
  c.radi *= esc;
}

void desplaca(Cercle& c, const Punt& p) {
  c.centre.x += p.x;
  c.centre.y += p.y;
}

void desplaca(Punt& p1, const Punt& p2) {
  p1.x += p2.x;
  p1.y += p2.y;
}

void llegeix(Punt& p) {
  cin >> p.x >> p.y;
}

void llegeix(Cercle& c) {
  llegeix(c.centre);
  cin >> c.radi;
}

bool es_interior(const Punt& p, const Cercle& c) {
  if (pow(p.x - c.centre.x,2) + pow(p.y-c.centre.y,2) < pow(c.radi,2))
  return true;
  return false;
}

int relacio(const Cercle& c1, const Cercle& c2) {
  double d = distancia(c1.centre,c2.centre);
  if (d > c1.radi + c2.radi) return 0;
  if (d == 0 and c1.radi < c2.radi) return 1;
  if (d == 0 and c1.radi > c2.radi) return 2;
  if (d < fabs(c1.radi - c2.radi)) {
    if (c1.radi < c2.radi) return 1;
    if (c2.radi < c1.radi) return 2;
  }
  return 3;
}

void imprimeix (int a) {
  if (a == 1) cout << "el primer cercle es interior al segon" << endl;
  if (a == 2) cout << "el segon cercle es interior al primer" << endl;
  if (a == 0) cout << "els cercles no intersecten" << endl;
  if (a == 3) cout << "els cercles intersecten" << endl;
}

int main () {
  Cercle c1,c2;
  llegeix (c1);
  llegeix (c2);
  imprimeix(relacio(c1,c2));
  int a;
  while (cin >> a) {
    string s; cin >> s;
    if (a == 1) {
      if (s == "escala") {
        double b; cin >> b;
        escala(c1,b); 
      } else {
        Punt p; llegeix(p);
        desplaca(c1,p);
      } 
    }
    if (a == 2) {
      if (s == "escala") {
        double b; cin >> b;
        escala(c2,b); 
      } else {
        Punt p; llegeix(p);
        desplaca(c2,p);
      } 
    }
    imprimeix(relacio(c1,c2));
  }  
}
