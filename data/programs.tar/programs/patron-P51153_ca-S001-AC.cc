#include <iostream>
#include <vector>

using namespace std;

void leer_vector(vector<int>& v)
{
  int n;
  n=v.size();
  for (int i=0;i<n;++i){
      cin >> v[i];
    }
}

bool suma_senar(const vector<int>& v)
{
  int n=v.size();
  for (int i=1;i<n;++i){
      if ( (v[i-1]+v[i])%2!=0 ) return true;
  }
  return false;
}


int main()
{
  int n;
  while (cin >> n){
    
    vector <int> v(n);
    
    leer_vector(v);
    
    if (suma_senar(v)) cout << "si" << endl;
    else cout << "no" << endl;
  }
}