#include <iostream>
#include <string>
using namespace std;

void girar_nombres (string x){
   if(cin>>x and x!="fi"){
       girar_nombres(x);
       cout<<x<<endl;
}
}
   
    

int main (){
    string x;
    girar_nombres(x);
    
}