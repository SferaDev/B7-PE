#include <iostream>
#include <math.h>
using namespace std;
int main() {
   int n;
   cin >> n;
   int cont = 0;
   int na = n;                  
   while (na != 0) {
      na /= 10;
      ++cont;    
   }
   if (n <= 0) cont = 1;     
   if ((cont % 2) == 0) {
      int nb = n;
      int Meit1 = 0;    
      for (int i = 0; i < cont / 2; ++i) {
        Meit1 += nb % 10;
        nb /= 10;    
      }
      int Meit2 = 0;  
      int nc = n /(pow(10, (cont / 2)));    
      for (int i = 0; i < cont / 2; ++i) {
        Meit2 += nc % 10;
        nc /= 10;       
      }
      if (Meit1 == Meit2) cout << Meit2 << " = " << Meit1 << endl;
      if (Meit1 > Meit2) cout << Meit2 << " < " << Meit1 << endl;
      if (Meit1 < Meit2) cout << Meit2 << " > " << Meit1 << endl;                
   }
   else cout << "res" << endl;                                                                       
} 
