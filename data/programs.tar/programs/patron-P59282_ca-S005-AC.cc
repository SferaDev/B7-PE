#include <iostream>
#include <map>
#include <string>

using namespace std;

int main()
{
  cout.setf(ios::fixed);
  cout.precision(4);
  map<int,int> mymap;
  string comanda;
  int numero;
  double ave = 0; 
  int count = 0;
  
  while(cin >> comanda)
  {
    if(comanda == "number")
    {
      cin >> numero;
      auto it = mymap.find(numero);
      if(it == mymap.end()) mymap.insert(make_pair(numero,1));
      else ++it->second;
      ++count;
      ave += numero;
      
      auto it2 = mymap.rbegin();
      cout << "minimum: " << mymap.begin()->first << ", maximum: " << it2->first << ", average: " << ave/double(count) << endl;
    }
    else if(comanda == "delete")
    {
      if(mymap.empty()) cout << "no elements" << endl;
      else{
	--count;
	ave -= mymap.begin()->first;
	if(mymap.begin()->second == 1) mymap.erase(mymap.begin());
	else --mymap.begin()->second;
	
	if(not mymap.empty()){
	  auto it = mymap.rbegin();
	  cout << "minimum: " << mymap.begin()->first << ", maximum: " << it->first << ", average: " << ave/double(count) << endl;
	}
	else cout << "no elements" << endl;
      }
    }
  }
}