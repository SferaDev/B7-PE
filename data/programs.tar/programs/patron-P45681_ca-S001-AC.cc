#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main ()
{
  int n,m;
  int cas=0;
  while(cin>>n>>m){
    ++cas;
    vector<string> v(n);
    for (int i=0; i<n; ++i)
      cin>>v[i];
    int ir,jr;
    cin>>ir>>jr;
    string ordres;
    cin>>ordres;
    int deixalles=0;
    for (int k=0;k<int(ordres.size());++k){
      char o=ordres[k];
      int di=0,dj=0;
      if (o == 'S') di=1;
      else if (o == 'N') di=-1;
      else if (o == 'E') dj=1;
      else dj=-1;
      while (v[ir+di][jr+dj]!='X'){
	ir+=di;
	jr+=dj;
	if (v[ir][jr]!='.'){
	  deixalles+=v[ir][jr]-'0';
	  v[ir][jr]='0';
	}
      }
    }
    cout<<"Cas "<<cas<<": "<<deixalles<<endl;
  }
}
