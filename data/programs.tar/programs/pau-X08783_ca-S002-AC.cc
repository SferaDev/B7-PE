#include <iostream>
#include <math.h>
using namespace std;
int main() {
  int a;
  int b;                                   
  while (cin >> a >> b) {  
      int cont = 0;
      int i = 0;    
      while ((b - pow(a,i)) >= 0) {
        ++cont;
        ++i;
      }
      cout << cont << endl;    
  }                                                 
} 
