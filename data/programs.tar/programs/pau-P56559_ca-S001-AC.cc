#include <iostream>
using namespace std;

int main() {
  int a1, b1, a2, b2;
  cin >> a1 >> b1 >> a2 >> b2;      
  if ((a1 == a2) && (b1 == b2)) {cout << "=" << endl;}
  if ((a1 == a2) && (b1 > b2)) {cout << '2' << endl;}
  if ((a1 == a2) && (b1 < b2)) {cout << "1" << endl;}
  if ((a1 < a2) && (b1 == b2)) {cout << "2" << endl;}
  if ((a1 < a2) && (b1 > b2)) {cout << "2" << endl;}
  if ((a1 < a2) && (b1 < b2)) {
    if (a2 <= b1) {cout << "?" << endl;}
    if (a2 > b1) {cout << "?" << endl;}
    }    
  if ((a1 > a2) && (b1 == b2)) {cout << "1" << endl;}
  if ((a1 > a2) && (b1 > b2)) {
    if (a1 <= b2) {cout << "?" << endl;}
    if (a1 > b2) {cout << "?" << endl;}   
     }
  if ((a1 > a2) && (b1 < b2)) {cout << "1" << endl;}
                            
}
