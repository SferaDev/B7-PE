#include <iostream>
#include <vector>

using namespace std;

typedef vector<vector<int> > Matriu;

bool es_simetrica(const Matriu& m)
{
  int tam = m.size();
  for (int i=0;i<tam;++i){
    for (int j=0;j<tam;++j){
      if(m[i][j]!=m[j][i]) return false;
    }
  }
  return true;
}