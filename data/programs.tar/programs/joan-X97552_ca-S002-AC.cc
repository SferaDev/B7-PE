#include <iostream>
#include <vector>
#include <string>

using namespace std;
    
struct Coord {
  int f,c;
};

Coord nextR (const Coord& p, bool& up, int n, int m){
  Coord r=p;
  if (p.c<m){
    if (p.f==n-1)up=false;
    else if (p.f==0)up=true;
    if (up){
      ++r.f;
      ++r.c;
    }
    else{
      --r.f;
      ++r.c;
    }
  }
  return r;
} 

int main (){
  int n;
  string entrada;
  bool primer=true;
  while (cin>>n and cin>>entrada){
    if (not primer) cout << endl;
    primer = false;
    int m = entrada.size();
    for (int i=0; i<entrada.size(); ++i){
      if (entrada [i]=='$')--m;
    }
    vector <vector<char> > frase (n, vector <char>(m,'.'));
    Coord p;
    p.f=p.c=0;
    frase [0][0]=entrada[0];
    bool up = true;
    int k=1;
    for (int i=1; i<entrada.size() and k<entrada.size();++i){
      p=nextR(p,up,n,m);
      if (entrada[k]=='$')++k;
      frase [p.f][p.c] = entrada[k];
      ++k;
    }
    for (int i=0; i<n; ++i){
      for (int j = 0; j<m; ++j){
	cout<<frase[i][j];
      }
      cout<<endl;
    }
    cout<<endl;
    int cuenta=0;
    bool espacio = true;
    for (int i=0;i<n;++i){
      for (int j=0;j<m;++j){
	char carac = frase [i][j];
	if (carac !='.'){
	  if (cuenta >= 5 and not espacio){
	    cuenta=0;
	    cout<<' ';
	  }
	  espacio=false;
	  cout<<carac;
	  ++cuenta;
	}
      }
    }
    cout<<endl;
  }
  
}