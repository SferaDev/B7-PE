#include <iostream>
#include <vector>

using namespace std;

bool primer(int a)
{
    if (a <= 1) return false;
    for (int i = 2; i*i <= a; ++i) {
        if (a%i == 0) return false;
    }
    return true;
}

void leer_vector(vector<int>& v)
{
  int n=v.size();
  for (int i=0;i<n;++i){
    cin >> v[i];
  }
}

bool suma_primera(const vector<int>& v)
{
  int n=v.size();
  for (int i=0;i<n;++i){
    for (int j=i+1;j<n;++j){
      if (primer(v[i]+v[j])) return true;
    }
  }
  return false;
}

int main()
{
  int n;
  while (cin >> n){
    vector<int> v(n);
    leer_vector(v);
    if(suma_primera(v)) cout << "si" << endl;
    else cout << "no" << endl;
    }
}