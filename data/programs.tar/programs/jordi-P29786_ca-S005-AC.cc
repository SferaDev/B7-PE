#include <iostream>
#include <cmath>

using namespace std;

bool es_potencia_de_3(int n){
  bool potencia= false;
  int cont1=0;
  int y=n;
  while (y%3==0 and y>0){
    y=y/3;
    ++cont1;
  }
  if (n==pow (3, cont1)){
    potencia = true;
  }
  return potencia;
}
int main(){
  int n;
  cin >>n;
  while ( n!=-1){
    bool potencia;
    potencia= es_potencia_de_3(n);
    if (potencia) cout << "cert" << endl;
    else cout << "fals" << endl;
    cin >> n;
  }
}
