#include <iostream>
using namespace std;

int main (){
    int n, suma, lastdigit;
    cin>>n;
    suma=0;
    lastdigit=(n%1000);
    cout<<"nombres que acaben igual que "<<n<<":"<<endl;
    while (cin>>n){
        if(n%1000==lastdigit){
            cout<<n<<endl;
            ++suma;
        }
    }
        cout<<"total: "<<suma<<endl;
}