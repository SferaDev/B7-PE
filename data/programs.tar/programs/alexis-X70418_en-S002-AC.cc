#include <iostream>
using namespace std;

int main() {
    int x;
    bool first = true;
    while (cin >> x) {
        if (first) first = false;
        else cout << endl;
        int max = (x * 2) - 1;
        for (int i = 0; i < x; ++i) {
            for (int j = 0; j < i; ++j) {
                cout << ' ';
            }
            for (int j = 0; j < (max - 2*i); ++j) {
                cout << 'X';
            }
            cout << endl;
        }
        for (int i = x - 2; i >= 0; --i) {
            for (int j = 0; j < i; ++j) {
                cout << ' ';
            }
            for (int j = 0; j < (max - 2*i); ++j) {
                cout << 'X';
            }
            cout << endl;
        }
    }
}