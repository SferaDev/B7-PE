#include <iostream>
using namespace std;

int digits(int n) {
        int i = 1;
        while (n/10 != 0) {
                ++i;
                n /= 10;
        }
        return i;
}

bool es_estrobogramatic(int n) {
        int x = digits(n);
        int invers, potencia;
        invers = 0;
        potencia = 1;
        int aux = n;
        for (int i = x; i >= 0; --i) {
                x = i;
                if (n%10 == 2 or n%10 == 3 or n%10 == 4 or n%10 == 5 or n%10 == 7)
                return false;
                while (x > 1) {
                        potencia = potencia*10;
                        --x;
                }
                if (n%10 != 6 and n%10 != 9) {
                        invers = invers + potencia*(n%10);
                        n /= 10;
                }
                else if (n%10 == 6) {
                        invers = invers + potencia*9;
                        n /= 10;
                }
                else if (n%10 == 9) {
                        invers = invers + potencia*6;
                        n /= 10;
                }
                potencia = 1;
        }
        if (invers == aux) return true;
        return false;
}

int main() {
        int n;
        int x = 0;
        while (cin >> n) {
                cout << n << " ";
                if (n > 0 and n%10 == 0) cout << "no es estrobogramatic" << endl;
                else if (es_estrobogramatic(n)) {
                        cout << "si es estrobogramatic" << endl;
                        if (n%2 != 0) ++x;
                }
                else cout << "no es estrobogramatic" << endl;
        }
        cout << endl;
        cout << "estrobogramatics senars: " << x << endl;
}
