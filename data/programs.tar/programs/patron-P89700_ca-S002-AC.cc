#include <iostream>

using namespace std;

void info_secuencia(int& suma, int& ultimo)
{
    int x;
    while (cin>>x and x!=0){
        suma +=x;
        ultimo = x;
    }
}

int main()
{
    int suma = -1, ultimo = -1, sumaFin, ultimoFin, res=0;
    bool primero = true;
    while (suma!=0){
        suma=0;
        info_secuencia(suma,ultimo);
        if (primero){
            primero = false;
            sumaFin=suma;
            ultimoFin=ultimo;
        }
        if (suma==sumaFin and ultimo==ultimoFin){
            ++res;
        }
    }
    cout<<res<<endl;
}
