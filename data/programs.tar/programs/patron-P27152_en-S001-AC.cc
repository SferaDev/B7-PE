#include <iostream>
#include <string>
#include <vector>

using namespace std;

int calcula_valor(char c)
{
  if (c=='a' or c=='e') return 1;
  else if (c=='o' or c=='s') return 2;
  else if (c=='d' or c=='i' or c=='n' or c=='r') return 3;
  else if (c=='c' or c=='l' or c=='t' or c=='u') return 4;
  else if (c=='m' or c=='p') return 5;
  else if(c=='b' or c=='f' or c=='g' or c=='h' or c=='j' or c=='q' or c=='v' or c=='x' or c=='y' or c=='z') return 6;
  else return 7;
}

int main()
{
  string paraula;
  int suma=0;
  while(cin >> paraula)
    for (int j=0; j<int(paraula.size());++j)
      suma+=calcula_valor(paraula[j]);
  cout << suma << endl;
}
