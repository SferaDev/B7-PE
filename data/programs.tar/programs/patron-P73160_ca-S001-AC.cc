#include <iostream>
#include <vector>
 
using namespace std;
 
string guanyador(const vector<string>& nom, const vector<bool>& guanya){
    int m = nom.size();
   
    int g = 0;
    int i = 0;
    while (m > 1){
        m /= 2;
       
        if (guanya[g]) g = 2*g + 1;
        else {
            g = 2*g + 2;
            i += m;
        }
    }
   
    return nom[i];
}