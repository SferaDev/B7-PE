#include <iostream>
using namespace std;
int main() {
  int n;
  int m;
  int cont = 9;
  bool primer = true;            
  while (cin >> n >> m) {
     if (primer) primer = false;
     else cout << endl;      
     for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
           if (cont == -1) cont = 9;
           cout << cont;
           --cont;
           if (j == m - 1) cout << endl;               
        }
     }   
     cont = 9;            
  }                                                       
} 
