#include <iostream>
using namespace std;
 
int main() {
    int b, a, f;
    while (cin >> b >> a >> f) {
        for (int i = f; i >= 0; --i) {
            for (int j = 0; j < i; ++j) cout << ' ';
            if (f - i != 0) cout << '/';
            if (i == f) {
                for (int j = 0; j < b + 1; ++j) cout << '_';
            }
            else if (i == 0){
                for (int j = 0; j < b; ++j) cout << '_';
            }
            else {
                for (int j = 0; j < b; ++j) cout << ' ';
            }
            if (f - i != 0) cout << '/';
            for (int j = f - i - 1; j > 0; --j) cout << ' ';
            if (f - i != 0) cout << '|';
            cout << endl;
        }
        for (int i = a; i > 0; --i) {
            cout << '|';
            if (i == 1) {
                for (int j = 0; j < b; ++j) cout << '_';
            }
            else {
                for (int j = 0; j < b; ++j) cout << ' ';
            }
            cout << '|';
            if (i - f > 0) {
                for (int j = f - 1; j > 0; --j) cout << ' ';
                cout << '|';
            }
            else {
                for (int j = i - 1; j > 0; --j) cout << ' ';
                cout << '/';
            }
            cout << endl;
        }
        cout << endl;
    }
}
