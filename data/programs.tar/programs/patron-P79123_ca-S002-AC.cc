#include <iostream>

using namespace std;


int base4(int n)
{
  if (n==0) return 0;
  else return n%4 + base4(n/4);
}

bool es_diabolic(int n)
{
  int suma = base4(n);
  if ( (n%(2*suma))==0 ) return true;
  return false;
}


int main()
{
  int n;
  int cont=0;
  while (cin >> n and n!=-1){
    if (es_diabolic(n)) ++cont;
  }
  
  if (cont==-1) cout << "000000" << endl;
  else if(cont<10) cout << "00000" << cont << endl;
  else if(cont<100) cout << "0000" << cont << endl;
  else if(cont<1000) cout << "000" << cont << endl;
  else if(cont<10000) cout << "00" << cont << endl;
  else if(cont<100000) cout << "0" << cont << endl;
  else if(cont<1000000) cout << cont << endl;
  
}