#include <iostream>
#include <vector>

using namespace std;

typedef vector <vector<int> > matrix;

matrix mult(const matrix &a, const matrix &b, int m)
{
  matrix res(2, vector<int>(2,0));
  res[0][0] = ((a[0][0]*b[0][0])%m + (a[0][1]*b[1][0])%m)%m;
  res[0][1] = ((a[0][0]*b[0][1])%m + (a[0][1]*b[1][1])%m)%m;
  res[1][0] = ((a[1][0]*b[0][0])%m + (a[1][1]*b[1][0])%m)%m;
  res[1][1] = ((a[1][0]*b[0][1])%m + (a[1][1]*b[1][1])%m)%m;
  return res;
}

matrix dubstep (const matrix &M, int n, int m)
{
  matrix res(2, vector<int>(2,0));
  if (n == 0)
  {
    res[0][0] = 1;
    res[1][1] = 1;
  }
  else if (n == 1)
  {
    res[0][0] = M[0][0]%m;
    res[0][1] = M[0][1]%m;
    res[1][0] = M[1][0]%m;
    res[1][1] = M[1][1]%m;
  }
  else if (n % 2 == 0)
  {
    res = dubstep(M,n/2,m);
    res = mult(res,res,m);
  }
  else 
  {
    res = dubstep(M,(n-1)/2,m);
    res = mult(res,res,m);
    res = mult(res,M,m);
  }
  return res;
}

int main ()
{
  matrix M (2, vector <int> (2));
  int n;
  while (cin >> n)
  {
    M[0][0] = n;
    cin >> n; M[0][1] = n;
    cin >> n; M[1][0] = n;
    cin >> n; M[1][1] = n;
    cin >> n;
    int m; cin >> m;
    M = dubstep(M,n,m);
    cout << M[0][0] << ' ' << M[0][1] << endl;
    cout << M[1][0] << ' ' << M[1][1] << endl;
    cout << "----------" << endl;
  }
}