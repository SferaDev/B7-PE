#include <vector>
using namespace std;

bool resistant_search(double x, const vector<double>& v, int start, int end) {
    if(start >= end) return false;
    int pos = (start + end) / 2;
    if(x == v[pos]) return true;
    if(pos - 1 >= 0 and v[pos - 1] == x) return true;
    if(pos + 1 < v.size() and v[pos + 1] == x) return true;
    if(x < v[pos]) return resistant_search(x, v, start, pos);
    return resistant_search(x, v, pos + 1, end);      
}

bool resistant_search(double x, const vector<double>& v) {
    return resistant_search(x, v, 0, v.size());
}

int main() {
    //
}
