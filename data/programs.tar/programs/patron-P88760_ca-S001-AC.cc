#include <iostream>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

struct zamburg{
	double x;
	double y;
	double r;
	int id;
};

typedef vector <zamburg> graph;

double d;

bool valid_dist(zamburg a, zamburg b){
	double dist = sqrt(pow(a.x-b.x,2) + pow(a.y-b.y,2)) - a.r - b.r;
	return dist <= d;
}

int bfs (const graph &g)
{
	vector <bool> vis (g.size(), false);
	vis[0] = true;
	queue <pair <zamburg, int>> Q;
	Q.push(make_pair(g[0], 0));
	
	while (not Q.empty()){
		auto inf = Q.front(); Q.pop();
		auto act = inf.first;
		for (int i = 0; i < g.size(); ++i){
			if (i != act.id and not vis[i] and valid_dist(act, g[i])){
				vis[i] = true;
				int salts = inf.second + 1;
				if(i == g.size() - 1) return salts;
				Q.push(make_pair(g[i], salts));
			}
		}
	}
	return -1;
}

void read(graph &g){
	int n = g.size();
	for (int i = 0; i < n; ++i){
		cin >> g[i].x >> g[i].y >> g[i].r;
		g[i].id = i;
	}
}


int main (){
	int n;
	while (cin >> n >> d){
		graph g(n);
		read(g);
		int salts = bfs (g);
		if (salts != -1) cout << salts << endl;
		else cout << "Xof!" << endl;
	}
}

