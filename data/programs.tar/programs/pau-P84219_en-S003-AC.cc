#include <iostream>
#include <vector>

using namespace std;

int dico (const vector <double> &v, int e, int d, double x)
{
  if (e > d) return -1;
  int m = (e+d)/2;
  if (v[m] < x) return dico (v,m+1,d,x);
  if (v[m] > x) return dico (v,e,m-1,x);
  if (m > 0)
  {
    int pos = dico(v,e,m-1,x);
    if (pos >= 0) return pos;
  }
  return m;
}



int first_occurrence(double x, const vector<double>& v)
{
  return dico(v,0,v.size()-1,x);
}

void read (vector <double> &v)
{
  for (int i = 0; i < v.size(); ++i) cin >> v[i];
}

int main ()
{
  int n; cin >> n;
  vector <double> v(n);
  read(v);
  cout << "Escriu x" << endl;
  double x; cin >> x;
  cout << first_occurrence(x,v) << endl;
}