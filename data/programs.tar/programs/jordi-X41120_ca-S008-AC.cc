#include <iostream>
#include <vector>

using namespace std;


vector<int> calcula_cims(const vector<int>& v) {
  vector <int> w(0);
  for ( int i = 2; i< v.size(); ++i) {
    if ( v[i-2] < v[i-1] and v[i] < v[i-1]) {
      //importante la forma de utilizar el push back
      w.push_back (v[i-1]);
    }
  }
  return w;
}
      
void llegeix_vector (vector<int>& v) {
  for ( int i = 0; i < v.size(); ++i) {
    cin >> v[i];
  }
}
  

void imprimir_vector ( vector<int>& w){
  cout << w.size() << ":";
  for ( int i = 0; i < w.size(); ++i) {
    cout << " " << w[i];
  }
  cout << endl;
  if ( w.size() == 0 or w.size() == 1) cout << "-";
  else {
    bool primero = true;
    int numero =  w[w.size()-1];
    for ( int i = 0; i < w.size()-1; ++i) {
      if (w[i] > numero){
	if (primero) {
	  cout << w[i];
	  primero = false;
	} else cout << " " << w[i];
      }
    }
    if (primero) cout << "-";
  }
  cout << endl;
}

int main() {
  int n;
  cin >> n;
  vector <int> v(n);
  vector <int> w;
  llegeix_vector(v);
  w = calcula_cims (v);
  imprimir_vector (w);
}