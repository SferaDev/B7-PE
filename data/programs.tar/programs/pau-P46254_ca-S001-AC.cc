#include <iostream>
#include <math.h>
using namespace std;

struct Punt {
  double x, y;
};

double distancia(const Punt& a, const Punt& b) {
  return sqrt(pow(a.x-b.x,2) + pow(a.y-b.y,2));
}

void llegirpunt (Punt& p) {
  cin >> p.x >> p.y;
}

int main () {
  Punt a;
  Punt b;
  llegirpunt(a);
  llegirpunt(b);
  cout << distancia(a,b) << endl;
}
