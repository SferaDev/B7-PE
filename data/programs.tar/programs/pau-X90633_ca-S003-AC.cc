#include "Cjt_estudiants.hh"
#include <algorithm>

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b) {
  int i = nest - 1;
  bool trobat = false;
  int dni = est.consultar_DNI();
  int x = cerca_dicot(vest,0,nest-1,dni);
  if (x >= 0 and x < nest) b = (dni == vest[x].consultar_DNI());
  else b = false;
  if (not b) {
    while (i >= 0 and not trobat) {
      if (dni > vest[i].consultar_DNI()) trobat = true;
      else {
        vest[i+1] = vest[i];
        --i;
      }
    }
    ++nest;
    vest[i+1]=est;
    if (est.te_nota()) {
      ++nest_amb_nota; 
      suma_notes += est.consultar_nota();
    }   
  } 
}

void Cjt_estudiants::esborrar_estudiant(int dni, bool& b) {
  int x = cerca_dicot(vest,0,nest-1,dni);
  if (x >= 0 and x < nest) b = dni == vest[x].consultar_DNI();
  else b = false;
  if (b) {
    vector <Estudiant> aux(MAX_NEST);
    int i = 0;
    int k = 0;
    if (vest[x].te_nota()) {
      --nest_amb_nota;
      suma_notes -= vest[x].consultar_nota();
    }
    while (i < x) {
      aux[k] = vest[i];
      ++i; ++k; 
    }
    while (k < nest -1) {
      aux[k] = vest[i+1];
      ++i; ++k;
    }
    vest = aux;
    --nest;
  }   
}
