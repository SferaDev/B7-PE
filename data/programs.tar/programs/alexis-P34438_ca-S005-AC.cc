#include <iostream>
#include <vector>
using namespace std;

struct Provincia {
    string nom;
    string capital;
    int habitants;
    int area;
    double pib;
};

struct Pais {
    string nom;
    string capital;
    vector<Provincia> provs;
};

typedef vector<Pais> Paisos;

int habitants(const Paisos& p, double x) {
    int result = 0;
    for (int i = 0; i < p.size(); ++i) {
        int count = 0;
        int tempResult = 0;
        for (int j = 0; j < p[i].provs.size(); ++j) {
            if (p[i].provs[j].pib <= x) count += 1;
            tempResult += p[i].provs[j].habitants;
        }
        if (count > 1) result += tempResult;
    }
    return result;
}

int main() {}
