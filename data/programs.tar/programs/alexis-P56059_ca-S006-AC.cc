#include <iostream>
using namespace std;

int main() {
    int n, count, result;
    count = result = 0;
    string temp, first, middle;
    while(cin >> n) {
        ++count;
        for (int i = 0; i < n; ++i) {
            cin >> temp;
            if (n%2 != 0 && i == 0) first = temp;
            if (n%2 != 0 && i == n/2) middle = temp;
            if (n%2 != 0 && i == n - 1 && temp == first && temp == middle) ++result;
            }
    }
    if (result == 0) cout << "cap de xula" << endl;
    else if (result == count) cout << "totes xules" << endl;
    else cout << "dels dos tipus" << endl;
}