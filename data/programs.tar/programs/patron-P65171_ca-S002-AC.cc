#include <iostream>
#include <cmath>

using namespace std;

int main ()
{
	cout.setf(ios::fixed);
    cout.precision(2);
	int n;
	cin>>n;
	double s=n-1;
	double m;
	double sumatorio;
	double sum_cuadrado;
	for (int i=0; i<n; ++i){
		cin>>m;
		sum_cuadrado+=m*m;
		sumatorio+=m;
	}
	double op1= (1/s) * sum_cuadrado;
	double op2= (1/(n*s)) * pow(sumatorio,2);
	cout<<op1-op2<<endl;
}
