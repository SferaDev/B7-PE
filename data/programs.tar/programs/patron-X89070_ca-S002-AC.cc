#include <iostream>

using namespace std;

int main(){
  int x,y,z;
  cin>>x>>y>>z;
  if (x<y and y<z)
    cout<<x+z<<endl;
  else if (z<y and y<x)
    cout << z+x << endl;
  else if (z<x and x<y)
    cout<<z+y<< endl;
  else if (y<x and x<z)
    cout<<y+z<<endl;
  else if (y<z and z<x)
    cout<<y+x<<endl;
}