#include <iostream>

using namespace std;

int main ()
{
	
	int n,m;
	cin >> n >> m;
	cout << (n+m)/2.0 << endl; 
	
}
