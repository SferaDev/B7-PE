#include <iostream>
using namespace std;
int multiple (int a, int b){
    int valor=0;
    if (a%b == 0) valor = a;
    else valor = (a/b)*b + b;
    return valor; 
}


int main() {
    int a,b;
    int hast=0;
    while (cin>>a>>b){
        ++hast;
        cout<<"#"<<hast<<" : "<<multiple(a,b)<<endl;
    }
}