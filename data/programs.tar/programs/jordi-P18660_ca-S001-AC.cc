#include <iostream>
#include <vector>
using namespace std;

typedef vector<char> Fila;
typedef vector<Fila> Matrix;

void readVector(vector<string>& vector) {
  for (int i = 0; i < vector.size(); ++i) {
    cin >> vector[i];
  }
}

void readMatrix(Matrix& matrix) {
  for (int i = 0; i < matrix.size(); ++i) {
    for (int j = 0; j < matrix[i].size(); ++j) {
      cin >> matrix[i][j];
    }
  }
}

void printMatrix(Matrix& matrix) {
  for (int i = 0; i < matrix.size(); ++i) {
    bool first = true;
    for (int j = 0; j < matrix[i].size(); ++j) {
      if (!first) cout << ' ';
      cout << matrix[i][j];
      first = false;
    }
    cout << endl;
    
  }
}

char toUpperCase(char c) {
    if (c >= 'a' and c <= 'z') return c - 'a' + 'A';
    return c;
}

bool match(const Matrix& input, string word,
           int i, int j, int a, int b) {
    int k = 0;
    while (i < input.size() and j < input[0].size() and k < word.size()) {
        if (input[i][j] != word[k]) return false;
        i += a;
        j += b;
        k += 1;
    }
    return k == word.size();
}

void highlight(Matrix& result, string word,
           int i, int j, int a, int b) {
    for (int k = 0; k < word.size(); ++k) {
        result[i][j] = toUpperCase(result[i][j]);
        i += a;
        j += b;
    }
}

void findWord(const Matrix& input, string word, Matrix& result) {
    for (int i = 0; i < input.size(); ++i) {
        for (int j = 0; j < input[i].size(); ++j) {
            if (match(input, word, i, j, 0, 1)) {
                highlight(result, word, i, j, 0, 1);
            }
            if (match(input, word, i, j, 1, 1)) {
                highlight(result, word, i, j, 1, 1);
            }
            if (match(input, word, i, j, 1, 0)) {
                highlight(result, word, i, j, 1, 0);
            }
        }
    }
}

int main() {
    int x, m, n;
    bool first = true;
    while (cin >> x >> m >> n) {
        vector<string> words(x);
        readVector(words);
        Matrix input(m, Fila(n));
        readMatrix(input);
        Matrix result = input;
        for (int i = 0; i < words.size(); ++i) {
            findWord(input, words[i], result);
        }
        if (!first) cout << endl;
        printMatrix(result);
        first = false;
    }
}