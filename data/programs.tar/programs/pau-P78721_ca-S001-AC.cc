#include <iostream>
using namespace std;

void ordenar (string n) {
  if (n != "END") {
    string n1;
    cin >> n1;
    if (n1 != "END") {
      string petit;
      string gran;
      if (n < n1) {
        petit = n;
        gran = n1;
      }
      else {
        petit = n1;
        gran = n;
      }
      cout << petit << endl;
      ordenar (gran);
    }
    else cout << n << endl;
  }     
}

int main () {
  string n;
  cin >> n;
  ordenar(n); 
}
