#include <iostream>
#include <vector>

using namespace std;

void leer_vectores(vector<double>& v)
{
  int n=v.size();
  for (int i=0;i<n;++i){
    cin >> v[i];
  }
}

void calcula_mitjana(const vector<double>& v,int maxim, int max_esquerra,double& mitjana)
{
  int x=maxim-max_esquerra;
  ++x;
  for (int i=max_esquerra;i<=maxim;++i){
    mitjana = mitjana + v[i];
  }
  mitjana = mitjana/(x+0.0);
}




void calcula_posicions (const vector<double>& v,int& p,int& q)
{
  int n=v.size();
  p=1;
  q=0;
  if (n>2){
    for (int i=2;i<n;++i){
      if (v[i]>v[p]) p=i;
    }
    for (int j=0; j<p;++j){
      if (v[j]>v[q]) q=j;
    }
  }
}

int main()
{
  cout.setf(ios::fixed);
  cout.precision(6);
  
  int n,max,max_es;
  double mitjana=0;
  
  while(cin>>n){
    
    vector<double> v(n);
    leer_vectores(v);
    calcula_posicions(v,max,max_es);
    calcula_mitjana(v,max,max_es,mitjana);
    cout << mitjana << endl;
    mitjana=0;
  }
}