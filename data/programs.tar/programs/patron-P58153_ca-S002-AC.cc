#include <iostream>

using namespace std;

int main ()
{
  
  //precision de 10 decimales
  cout.setf(ios::fixed);
  cout.precision(10);
  
  int n,m;
  while (cin>>n>>m){
    //valor inicial del harmonico de n,m
    double Hn=0;//,Hm=0;
    
    //contadores de los bucles
    int contn=m+1;
    //double contm=1;
    
    //calcula el harmónico de n
    while (contn<=n){
      Hn=Hn+(double(1)/contn);
      ++contn;
    }
    /*
    //calcula el harmónico de m
    while (contm<=m){
      Hm=Hm+(1/contm);
      ++contm;
    }
    */
    cout << Hn << endl;
  }
}