#include <iostream>
using namespace std;
 
int your_function_name(int n) {
    int resultat;
    for (int i = 0; i < n; ++i) resultat+= i*(i+1);
    return resultat;
}
 
int main() {
  int n;
  while (cin>>n) {
    cout<<your_function_name(n)<<endl;
  }
}
