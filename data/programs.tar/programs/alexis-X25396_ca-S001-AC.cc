#include <iostream>
#include <vector>
#include <string>
using namespace std;

const int LONG_ALFABET =  int('z') - int('a') + 1;

bool isLowercaseLetter(char c) {
    if (c >= 'a' && c <= 'z') return true;
    return false;
}

void escriu_fals(const vector<bool>& v) {
    for (int i = 0; i < v.size(); ++i) {
        char c = 'a' + i;
        if (!v[i]) cout << c << endl;
    }
}

vector<bool> missingLetters(const vector<string>& v) {
    vector<bool> output(LONG_ALFABET, false);
    for (int i = 0; i < v.size(); ++i) {
        for (int j = 0; j < v[i].size(); ++j) {
            int position = v[i][j] - 'a';
            if (isLowercaseLetter(v[i][j])) {
                output[position] = true;
            }
        }
    }
    return output;
}

string longestWord(const vector<string>& vector) {
    int tempSize, position;
    tempSize = position = 0;
    for (int i = 0; i < vector.size(); ++i) {
        if (vector[i].size() > tempSize) {
            tempSize = vector[i].size();
            position = i;
        }
    }
    return vector[position];
}

vector<string> readInput(int size) {
    vector<string> result(size);
    for (int i = 0; i < size; ++i) {
        cin >> result[i];
    }
    return result;
}

int main() {
    int size;
    cin >> size;
    vector<string> input = readInput(size);
    cout << longestWord(input) << endl;
    escriu_fals(missingLetters(input));
}