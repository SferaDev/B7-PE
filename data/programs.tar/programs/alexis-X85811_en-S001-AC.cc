#include <iostream>
#include <vector>
using namespace std;

int main() {
    int n;
    while(cin >> n) {
        vector<int> input(n);
        for (int i = 0; i < n; ++i) {
            cin >> input[i];
        }
        bool first = true;
        for (int i = 1; i <= n/2; ++i) {
            if (!first) cout << ' ';
            first = false;
            cout << input[i - 1] << ' ' << input[n - i];
        }
        if (n%2) cout << ' ' << input[n/2];
        cout << endl;
    }
}