#include <iostream>
#include <vector>
#include "Estudiant.hh"

using namespace std;

typedef vector<int> V_Sub;
typedef vector<double> V_Notes;

struct Notes_Est{
  Estudiant est;
  V_Notes v_notes;
};

typedef vector<Notes_Est> V_Est;

void omplir_subconjunt(vector<int>& v_sub, int S)
{
  for (int i=0; i<S; ++i)
    cin>>v_sub[i];
}

double calcular_mitjana(const V_Notes& notes, int N, const V_Sub& v_sub, int S)
{
  double mitja = 0;
  for (int i=0; i<S; ++i)
  {
    int j=0;
    int pos = v_sub[i]-1;
    while (j<N and pos!=j) ++j;
    mitja += notes[j];
  }
  return mitja/S;
}

void omplir_notes_i_calcular_mitjana_est(V_Est& v_est, int M, int N, const V_Sub& v_sub, int S)
{
  int aux;
  for (int i=0; i<M; ++i)
  {
      cin>>aux;
      Estudiant aux_est(aux);
      v_est[i].est = aux_est;
      v_est[i].v_notes = vector<double> (N);
      for (int j=0; j<N; ++j)
	cin>>v_est[i].v_notes[j];
      v_est[i].est.afegir_nota(calcular_mitjana(v_est[i].v_notes, N, v_sub, S));
  }
}

void imprimir_est(V_Est& v_est, int M)
{
  for (int i=0; i<M; ++i)
  {
      v_est[i].est.escriure();
  }
}

int main(){
  int M,N,S;
  cin>>M>>N>>S;
  
  V_Sub v_sub = vector<int> (S);
  omplir_subconjunt(v_sub,S);
  
  V_Est v_est = vector<Notes_Est> (M);
  omplir_notes_i_calcular_mitjana_est(v_est, M, N, v_sub, S);
  imprimir_est(v_est, M);
}