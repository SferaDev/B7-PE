#include <iostream>

using namespace std;

int suma_digits(int n)
{
  int cont=0;
  if(n==0){
    cont=cont+n;
    return cont;
  }
  else while (n>0){
    cont+=n%10;
    n/=10;
  }
  return cont;
}

int reduccio_digits (int x)
{
  if(suma_digits(x)<10) return suma_digits(x);
  return reduccio_digits((suma_digits(x)%10) + (suma_digits(x)/10%10));
}

int main ()
{
  int n;
  cin>>n;
  cout<<reduccio_digits(n)<<endl;
}
