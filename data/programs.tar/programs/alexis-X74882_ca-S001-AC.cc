#include "Estudiant.hh"
#include "Cjt_estudiants.hh"
using namespace std;

bool updateNota(const Estudiant& x, const Estudiant& y) {
  if (!y.te_nota()) return false;
  else if (!x.te_nota()) return true;
  else return y.consultar_nota() > x.consultar_nota();
}

void updateVector(Cjt_estudiants& first, const Cjt_estudiants& second) {
  for (int i = 1; i <= second.mida(); ++i) {
    Estudiant y = second.consultar_iessim(i);
    if (first.existeix_estudiant(y.consultar_DNI())) {
      Estudiant x = first.consultar_estudiant(y.consultar_DNI());
      if (x.te_nota()) {
        if (updateNota(x, y)) x.modificar_nota(y.consultar_nota());
      } else {
        if (updateNota(x, y)) x.afegir_nota(y.consultar_nota());
      }
      first.modificar_estudiant(x);
    } else if (first.mida() < first.mida_maxima()) {
      first.afegir_estudiant(y);
    }
  }
}

int main() {
  Cjt_estudiants first;
  first.llegir();
  Cjt_estudiants second;
  second.llegir();
  updateVector(first, second);
  first.escriure();
}
