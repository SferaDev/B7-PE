#include <iostream>

using namespace std;

void digit_maxim_i_minim_aux(int n, int& maxim, int& minim){
    if (n%10>maxim) maxim=n%10;
    if (n%10<minim) minim=n%10;
    if (n/10!=0) digit_maxim_i_minim_aux(n/10, maxim, minim);
}
void digit_maxim_i_minim(int n, int& maxim, int& minim){
  minim=9;
  maxim=0;
  digit_maxim_i_minim_aux(n,maxim,minim);
}
  
int main(){
}