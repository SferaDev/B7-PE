#include <iostream>
using namespace std;

void gipa (int& cont, int n) {
  string act;
  if (cin >> act) gipa (cont,n);
  if (cont != 0 and cont <= n) cout << act << endl;
  ++cont;
}

int main () {
  int n;
  cin >> n;
  int cont = 0;
  gipa (cont,n);
}
