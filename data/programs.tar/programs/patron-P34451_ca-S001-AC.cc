#include <iostream>

using namespace std;

int main ()
{
  int n;
  cin>>n;
  int x;
  int cont=0;
  
  while (cin>>x){
    if (x%n==0) ++cont;
  }
  cout<<cont<<endl;
}