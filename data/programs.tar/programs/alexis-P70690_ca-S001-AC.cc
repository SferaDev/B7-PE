#include <vector>
#include <iostream>

using namespace std;

typedef vector<vector<pair<char, bool>>> graph;

bool possible(graph& mapa, int x, int y) {
    if (!mapa[x][y].second and mapa[x][y].first != 'X') {
        // Mark position so we do not return
        mapa[x][y].second = true;
        // If you've found money, run for your life
        if (mapa[x][y].first == 't') return true;
        // Call the recursion where you can move
        return
        (x-1 >= 0             and possible(mapa, x-1, y))   or
        (y-1 >= 0             and possible(mapa, x,   y-1)) or
        (x+1 < mapa.size()    and possible(mapa, x+1, y))   or
        (y+1 < mapa[x].size() and possible(mapa, x,   y+1));
    }
    return false;
}

int main() {
    int n, m;
    cin >> n >> m;
    graph mapa(n, vector<pair<char, bool>>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            char x;
            cin >> x;
            mapa[i][j] = make_pair(x, false);
        }
    }
    int x, y;
    cin >> x >> y;
    if (possible(mapa, x-1, y-1)) cout << "yes";
    else cout << "no";
    cout << endl;
}
