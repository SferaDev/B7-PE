#include <iostream>
#include <string>
#include <cmath>

using namespace std;

string dia_de_la_setmana (int d, int m, int a)
{
  
  string dia;
  m =m-2;
  if (m <= 0 ){
    m+=12;
    --a;
  }
  
  int c = a/100;
  int y = a%100;
  int f (2.6*m - 0.2);
  f = f + d + y - 2*c;
  
  y = y/4;
  c = c/4;
  
  f = f + c + y;
  
  while (f < 0) f+=7;
  f=f%7;
  
  if (f==0) dia = "diumenge";
  if (f==1) dia = "dilluns";
  if (f==2) dia = "dimarts";
  if (f==3) dia = "dimecres";
  if (f==4) dia = "dijous";
  if (f==5) dia = "divendres";
  if (f==6) dia = "dissabte";
  
  return dia;
}

int main ()
{
  int dia,mes,any;
  cin >> dia >> mes >> any;
  cout << dia_de_la_setmana (dia,mes,any) << endl;
}