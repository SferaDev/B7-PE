#include <iostream>
using namespace std;

int main () {
  char a;
  cin >> a;
  bool chivato = false;
  if ((a >= 'a' and a <= 'z') or (a >= 'A' and a <= 'Z')) {
    cout << "lletra" << endl;
    chivato = true;
    }
  if (a >= '0' and a <= '9') {
    cout << "digit" << endl;
    chivato = true; 
  }
  if (!chivato) cout << "res" << endl;
}
