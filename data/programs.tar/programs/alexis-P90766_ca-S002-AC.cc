#include <vector>
#include <iostream>

using namespace std;

typedef vector<vector<pair<char, bool>>> graph;

int tresors(graph& mapa, int x, int y) {
    int count = 0;
    if (!mapa[x][y].second and mapa[x][y].first != 'X') {
        // Mark position so we do not return
        mapa[x][y].second = true;
        // If you've found money, run for your life
        if (mapa[x][y].first == 't') count += 1;
        // Call the recursion where you can move
        if (x-1 >= 0)             count += tresors(mapa, x-1, y);
        if (y-1 >= 0)             count += tresors(mapa, x,   y-1);
        if (x+1 < mapa.size())    count += tresors(mapa, x+1, y);
        if (y+1 < mapa[x].size()) count += tresors(mapa, x,   y+1);
    }
    return count;
}

int main() {
    int n, m;
    cin >> n >> m;
    graph mapa(n, vector<pair<char, bool>>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            char x;
            cin >> x;
            mapa[i][j] = make_pair(x, false);
        }
    }
    int x, y;
    cin >> x >> y;
    cout << tresors(mapa, x-1, y-1) << endl;
}
