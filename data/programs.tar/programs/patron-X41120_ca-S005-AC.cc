#include <iostream>
#include <vector>

using namespace std;

void leer_vector(vector<int>& v)
{
  int n=v.size();
  for(int i=0;i<n;++i){
    cin >> v[i];
  }
}


vector<int> calcula_cims(const vector<int>& v)
{
  vector<int> cims;
  int n=v.size();
  
  for (int i=1;i<n-1;++i){
    if (v[i]>v[i-1] and v[i]>v[i+1])
      cims.push_back(v[i]);
  }
  return cims;
}

int main()
{
  int n;
  cin >> n;
  vector<int> v(n);
  leer_vector(v);
  vector<int> cims = calcula_cims(v);
  int t=cims.size();
  cout << t << ":";
  for (int i=0; i<t;++i){
    cout << " " << cims[i];
  }
  cout << endl;
  bool mes_alt=false;
  bool primer=true;
  for (int j=0;j<=t-1;++j){
    if (cims[j]>cims[t-1]){
      if (not primer)
	cout << " ";
      primer=false;
      cout << cims[j];
      mes_alt=true;
    }
  }
  if (not mes_alt) cout << "-" << endl;
  else cout << endl;
}