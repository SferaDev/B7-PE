#include <iostream>
using namespace std;

int main (){
    int a,b;
    while(cin>>a>>b){cout << "suma dels cubs entre " << a << " i " << b << ": ";
       int suma=0;
    while (a<=b){
       suma=(a*a*a)+suma;
       ++a;
    }cout<<suma << endl;

    }
    }