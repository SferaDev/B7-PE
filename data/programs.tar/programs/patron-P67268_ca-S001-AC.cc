#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

void leer_vector(vector<int>& v)
{
  int n=v.size();
  for (int i=0;i<n;++i){
    cin >> v[i];
  }
}

int main()
{
  int n;
  while (cin >> n){
    
    vector <int> v(n);
    leer_vector(v);
    
    bool primer = true;  
    for (int j = n-1; j >= 0; --j) {  
      if (not primer) cout << ' ';    
      cout << v[j];    
      primer = false;              
    }  
    cout << endl;
  }
  
}