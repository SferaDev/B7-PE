#include "Estudiant.hh"
#include <vector>
using namespace std;

/* Leer vector */
vector<Estudiant> leer_vector(int size) {
  vector<Estudiant> result(size);
  for (int i = 0; i < size; ++i) {
    result[i].llegir();
  }
  return result;
}

/* Escribir vector */
void escribir_vector(const vector<Estudiant>& est) {
  for (int i = 0; i < est.size(); ++i) {
    est[i].escriure();
  }
}

/* Simplify vector */
vector<Estudiant> simplifyVector(const vector<Estudiant>& input) {
  vector<Estudiant> result;
  // Insert student 0 (PRE: input > 0)
  result.push_back(input[0]);
  // For all students from i = 1 to i < size()
  for (int i = 1; i < input.size(); ++i) {
    // If DNIs not match add new entry
    if (input[i].consultar_DNI() != result[result.size() - 1].consultar_DNI()) {
      result.push_back(input[i]);
    } else {
      // Condition: DNIs match
      if (!result[result.size() - 1].te_nota()) {
        // If previous "nota" is invalid update it
        result[result.size() - 1] = input[i];
      } else if (input[i].te_nota() and input[i].consultar_nota() > result[result.size() - 1].consultar_nota()) {
        // Condition previous has valid "nota" and new one has "nota"
        // Check which one is higher and update accordingly
	    result[result.size() - 1].modificar_nota(input[i].consultar_nota());
      }
    }
  }
  return result;
}  

int main() {
  int size;
  cin >> size;
  vector<Estudiant> input = leer_vector(size);
  vector<Estudiant> simple = simplifyVector(input);
  escribir_vector(simple);
}