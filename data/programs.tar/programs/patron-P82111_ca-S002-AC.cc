#include <iostream>
#include <vector>
 
using namespace std;
 
// Pre:(0 <= esq) and (dre < dicc.size()) and (dicc esta ordenat lexicogra)
// Post: retorna i tal que, o b� troba la paraula, o -1 si no hi �s
bool esta_al_diccionari(string s, const vector<string>& dicc, int esq, int dre) {
    if (esq > dre) return false;
    int pos = (esq + dre)/2; // posicio central de v[esq..dre]
    if (s < dicc[pos]) return esta_al_diccionari(s, dicc, esq, pos - 1);
    if (s > dicc[pos]) return esta_al_diccionari(s, dicc, pos + 1, dre);
    return true;
   
}
// Pre: dicc vector string ordenat lexicograficament
//      m vector string amb k paraules de k caracters
// Post: retorna true si es un taulell m�gic.
// M�gic == simetric + la paraula est� al diccionari.
bool es_magic (const vector<string>& dicc, const vector<string>& m) {
    // comprobamos simetr�a
    int n = m.size();
    for (int i = 0; i < n; ++i) {
        for (int j = i; j < n; ++j) {
            if (m[i][j] != m[j][i]) return false;
        }
       
    }
    // comprobamos si est� en diccionario
    for (int i = 0; i < n; ++i) {
        int esq = 0;
        int dre = dicc.size();
        if (not esta_al_diccionari(m[i],dicc,esq,dre)) return false;            
    }
    return true;
}
 
int main() {
    int n;
    cin >> n;
    vector<string> dicc(n);
    for (int i = 0; i < n; ++i) {
        cin >> dicc[i];
    }
    int k;
    cin >> k;
    while (k != 0) {
        vector<string> taulell(k);
        for (int i = 0; i < k; ++i) {
            cin >> taulell[i];
        }
       
        if (es_magic(dicc,taulell)) cout << "SI" << endl;
        else cout << "NO" << endl;
        cin >> k;
    }
}
