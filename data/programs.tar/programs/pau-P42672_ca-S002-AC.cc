#include <iostream>
using namespace std;

int minbase(int n) {          
  if (n%2 > 2) return minbase(n%2);
  return n%2;
}

void barreja (int x, int y) {
  int xn = minbase(x);
  int yn = minbase(y);
  if (x >= 2) barreja(x/2,y/2);
  cout << xn << yn;
}

int main () {
  int x;
  int y;
  while (cin >> x >> y) {
    barreja(x,y);
    cout << endl;
  }
}
