#include <iostream>
#include <vector>
using namespace std;

typedef vector< vector <char> > Tauler;

struct Bola {
  int x_ant, y_ant;  // Posicio anterior de la bola
  int x_act, y_act;  // Posicio actual de la bola
  int x_seg, y_seg;  // Posicio seguent de la bola
};

void incialitza (Bola& b, Tauler& t) {
  cin >> b.x_ant >> b.y_ant;
  t[b.x_ant][b.y_ant] = '=';
  if (b.x_ant == 0) {
    b.x_act = 1;
    if (b.y_ant == 0) b.y_act = 1;
    else b.y_act = b.y_ant - 1;
  } else {
    b.x_act = b.x_ant - 1;
    if (b.y_ant == 0) b.y_act = 1;
    else b.y_act = b.y_ant - 1;
  }
  b.x_seg = 2*b.x_act - b.x_ant;
  b.y_seg = 2*b.y_act - b.y_ant;  
}

void vermella (Tauler& t) {
  int x,y;
  cin >> x >> y;
  t[x][y] = 'b';
}

bool condicio (const Bola& b, const Tauler& t) {
  int n = t.size() - 1;
  int m = t[0].size() -1;
  if (b.x_act == 0 or b.x_act == n) {
    if (b.y_act == 0) return true;
    if (b.y_act == m) return true;
  }
  return false;
}

void moure_fins_xocar (Tauler& t, Bola& b) {
  bool para = false;
  int n = t.size() - 1;
  int m = t[0].size() - 1;
  while (not para) {
    if (b.x_act == n or b.x_act == 0 or b.y_act == m or b.y_act == 0) {
      b.x_seg = b.x_act;
      b.y_seg = b.y_act;
      para = true;
    }
    else if (t[b.x_act][b.y_act] == 'b') para = true;
    else {
      t[b.x_act][b.y_act] = '=';
      b.x_ant = b.x_act;
      b.y_ant = b.y_act;
      b.x_act = b.x_seg;
      b.y_act = b.y_seg;
      b.x_seg = 2*b.x_act - b.x_ant;
      b.y_seg = 2*b.y_act - b.y_ant;   
    }
  }
}

void dirseguent (Bola& b, Tauler& t) {
  int n = t.size() - 1;
  int m = t[0].size() - 1;
  t [b.x_act][b.y_act] = '=';
  if (b.x_act == 0) {
    ++b.x_seg;
    if (b.y_seg - b.y_ant == 1) ++b.y_seg;
    else --b.y_seg;
  }
  if (b.x_act == n) {
    --b.x_seg;
    if (b.y_seg - b.y_ant == 1) ++b.y_seg;
    else --b.y_seg;
  }
  if (b.y_act == 0) {
    ++b.y_seg;
    if (b.x_seg - b.x_ant == 1) ++b.x_seg;
    else --b.x_seg;
  }
  if (b.y_act == m) {
    --b.y_seg;
    if (b.x_seg - b.x_ant == 1) ++b.x_seg;
    else --b.x_seg;
  }
  b.x_ant = b.x_act;
  b.y_ant = b.y_act;
  b.x_act = b.x_seg;
  b.y_act = b.y_seg;
  b.x_seg = 2*b.x_act - b.x_ant;
  b.y_seg = 2*b.y_act - b.y_ant;  
}   

bool simula (Tauler& t, Bola& b) {
  int cont = 0;
  while (cont < 4) {
    moure_fins_xocar(t,b);
    if (condicio(b,t)) return false;
    if (t[b.x_act][b.y_act] == 'b') return cont == 3;
    cout << "(" << b.x_act << "," << b.y_act << ")";
    ++cont;
    if (cont < 4) dirseguent(b,t);
  }
  return false;
}

void imprimeix (const Tauler& t) {
  int n = t.size();
  int m = t[0].size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      cout << t[i][j];
    }
    cout << endl;
  } 
}

int main () {
  int n,m;
  while (cin >> n >> m) {
    Tauler t (n, vector <char> (m,'.'));
    Bola b;
    incialitza (b,t);
    vermella (t);
    if (simula(t,b)) cout << ": si" << endl;
    else cout << ": no" << endl;
    t[b.x_act][b.y_act] = 'B';
    imprimeix(t);
    cout << endl;    
  }
}
