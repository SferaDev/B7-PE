#include<iostream>
using namespace std;
  
int main (){
  int num;
  while(cin >> num){
    int cont=0;
    int diferencia = 0;
    int salida = 0;
    int x=0;
    cin >> x;
    while (cont<num-1){
      int y;
      cin >> y;
      if ( x < y){
      diferencia = y - x;
      }else{
	diferencia = x - y;
      }
      if (diferencia > salida){
	salida = diferencia;
      }
      x = y;
      cont++;
      
    }
    cout << salida << endl;
      
   }   
}