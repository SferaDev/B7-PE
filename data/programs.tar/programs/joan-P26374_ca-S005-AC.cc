#include <iostream>
#include <vector>
using namespace std;
typedef vector< vector<int> > Matriu;


Matriu suma(const Matriu& a, const Matriu& b){
  int m=a.size();
  Matriu l(m, vector <int>(m));
  for (int i=0;i<m;++i){
    for (int j=0;j<m;++j) {l[i][j]=a[i][j]+b[i][j];}
  }
  return l;
}

/*int main(){
  int f;
  cin>>f;
  Matriu a(f,vector<int>(f));
  Matriu b(f,vector<int>(f));
  for (int i=0;i<f;++i){
    for (int j=0;j<f;++j)cin>>a[i][j];
  }
  for (int i=0;i<f;++i){
    for (int j=0;j<f;++j)cin>>b[i][j];
  }
  Matriu c(f, vector<int>(f));
  c=suma(a,b);
  for (int i=0;i<f;++i){
    for (int j=0;j<f;++j)cout<<c[i][j]<<' ';
    cout<<endl;
  }
}*/
