#include <iostream>
#include <vector>
using namespace std;
 
typedef vector <char> Fila;
typedef vector <Fila> Matriu;
 
void imprimir(const Matriu& tauler){
        for(int i=0;i<tauler.size();++i){
                for(int j=0;j<tauler[0].size();++j){
                        cout << tauler[i][j];
                }
                cout << endl;
        }
}
 
char adjacent(const Matriu& tauler2,int i,int j,Matriu& tauler){
        int bacteris=0;
        for(int h=i-1;h<=i+1;++h){
                for(int o=j-1;o<=j+1;++o){
                        if (h >= 0 and h < tauler2.size() and o >= 0 and o < tauler2[0].size()) {
                if (tauler2[h][o] == 'B'){
                        ++bacteris;
                                }
             }
                }
        }
        if (tauler[i][j] == '.') {
        if (bacteris == 3){
           return 'B';
                }
        else
                   return '.';
    }
    else {
        if (bacteris == 4 or bacteris == 3){
           return 'B';
                }  
        else
                   return '.';
    }
}
 
void actualitzar(Matriu& tauler,Matriu& tauler2,bool& primer){
        for(int i=0;i<tauler.size();++i){
                for(int j=0;j<tauler[0].size();++j){
                        tauler[i][j]=adjacent(tauler2,i,j,tauler);
                }
        }
        if(primer){
                imprimir(tauler);
                primer=false;
        }
        else {
                cout << endl;
                imprimir(tauler);
        }
 
}
 
void llegir(Matriu& tauler){
        for(int i=0;i<tauler.size();++i){
                for(int j=0;j<tauler[0].size();++j){
                        cin >> tauler[i][j];
                }
        }
}
 
int main(){
        int n,m;
        bool primer=true;
        while(cin >> n >> m and n!=0 and m!=0){
                Matriu tauler(n,Fila(m));
                Matriu tauler2(n,Fila(m));
                llegir(tauler);
                tauler2=tauler;
                actualitzar(tauler,tauler2,primer);
        }
}
