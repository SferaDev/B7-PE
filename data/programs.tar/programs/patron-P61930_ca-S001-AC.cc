#include <iostream>
 
using namespace std;
 
int suma_digits(int n) {
    int b = n%10;
    if (n < 10) return b;
    return b + suma_digits(n/10);
}
 
bool es_multiple_3(int n) {
    int b = suma_digits(n);
    if (b < 10) return b == 3 or b == 6 or b == 9;
    return es_multiple_3(b);
}
 
int main() {
    int n;
    while (cin >> n) {
        cout << es_multiple_3(n) << endl;
    }
}
