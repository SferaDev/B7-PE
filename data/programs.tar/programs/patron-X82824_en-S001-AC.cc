#include <iostream>
using namespace std;


char atbash(char c){
	if(c == 'a' or c == 'A') return 'Z';
	else {
		return atbash (c-1)-1;
	}
}

void print_atbash_encipherment(){
	char c;
	cin >> c;
	if(c != '#'){
		if((c >= 'a' and c <= 'z') or (c >= 'A' and c <= 'Z')) cout << atbash(c);
		print_atbash_encipherment();
	}
	else cout << '#' << endl;
	
}

int main() {
	print_atbash_encipherment();
}
