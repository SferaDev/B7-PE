#include <iostream>
using namespace std;

struct Racional {
  int num, den;
};

int mcd(int a , int b ) {
  if (a == b) return a;
  if (a == 0) return b;
  if (b == 0) return a;
  if (a%b == 0) return b;
  return mcd(b, a%b);
}

Racional racional(int n, int d) {
  Racional res;
  if (d < 0) {
    d = d*(-1);
    n = n*(-1);
  }
  int naux = n; 
  if (naux < 0) naux = 0 - naux;
  int c = mcd(naux,d);
  if (n == 0) {
    res.num = 0;
    res.den = 1;
  } else if (c == 1) {
    res.num = n;
    res.den = d;
  } else {
    res.num = n/c;
    res.den = d/c;
  }
  return res;         
}

void llegiex (Racional& r) {
  cin >> r.num >> r.den;
}

void escriu (const Racional& r) {
  cout << r.num << '/' << r.den << endl;
}

int main () {
  Racional r;
  llegiex (r);
  r = racional(r.num, r.den);
  escriu (r);  
}
