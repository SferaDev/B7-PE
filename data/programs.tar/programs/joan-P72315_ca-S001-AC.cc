#include<iostream>
using namespace std;
 
int intercalacio (int x, int y) {
        int num;
        if (x < 10 and y < 10) {
                num = x*10 + y;
        }
        else {
                num = (x%10)*10 + y%10 + intercalacio(x/10,y/10)*100;
        }
        return num;
}
 
int main() {
        int x, y;
        while (cin >> x >> y) {
                cout << intercalacio(x,y) << endl;
        }
}