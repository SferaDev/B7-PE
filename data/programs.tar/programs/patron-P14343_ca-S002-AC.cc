#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
 
struct Enviament {
         
  string dni;
  string exer;
  int temps;
  string res;
};
 
typedef vector<Enviament> Historia;
 
void llegeix_env(Enviament& a){
 
  cin>>a.dni>>a.exer>>a.temps>>a.res;
}
 
bool cond(const Enviament& a, const Enviament& b){ //Muy importante esta condicion.
 
  if(a.dni==b.dni)return a.exer<b.exer;
  return a.dni<b.dni;
}
 
void actualiza_contadores(vector<string>& alumne, vector<int>& num, const vector<int>& cont, const string& al){
 
  for(int i=0; i<5; i++){ //Hay 5 contadores, los 4 primeros de repeticiones (verdes,rojos...) y el ultimo del tiempo maximo
 
    if(cont[i]>num[i]){
 
      num[i] = cont[i];
      alumne[i] = al;
    }
  }
}
 
void obte_resultats(const Historia& h, vector<string>& alumne, vector<int>& num){
 
  int llarg = h.size();
  int i = 0;
 
  while(i<llarg){ //Condicion de prioridad
 
    vector<int> cont(5,0); //Inicializamos los contadores con valor 0
    string al = h[i].dni; //Inicializamos la variable al para saber el alumno actual
 
    while(i<llarg and h[i].dni==al){ //Tratando alumno por alumno
     
      string ej = h[i].exer; //Ejercicio actual
      bool es_verd,es_groc,es_vermell;
      es_verd=es_groc=es_vermell=false;
 
      while(i<llarg and h[i].dni==al and h[i].exer==ej){ //Ejercicio por ejercicio (de cada alumno)
 
        if(h[i].res=="verd"){
 
          cont[0]++;
          es_verd = true;
        }
        else if(h[i].res=="groc")es_groc=true;
        else if(h[i].res=="vermell")es_vermell=true;
        if(h[i].temps>cont[4])cont[4]=h[i].temps; //Tiempo maximo
 
        i++;
      }
      if(es_verd)cont[1]++;                                    //Resultados de cada parte del ejercicio
      if(not es_groc and not es_verd and es_vermell)cont[2]++;
      cont[3]++;
    }
    actualiza_contadores(alumne,num,cont,al); //Busca el maximo de cada contador (el maximo de todos los alumnos)
  }
}
 
void mostra_resultats(const vector<string>& alumne, const vector<int>& num){
 
  for(int i=0; i<4; i++){ //Los primeros cuatro resultados tienen condiciones iguales
 
    if(i==0)cout<<"alumne amb mes enviaments verds:     ";
    if(i==1)cout<<"alumne amb mes exercicis verds:      ";
    if(i==2)cout<<"alumne amb mes exercicis vermells:   ";
    if(i==3)cout<<"alumne amb mes exercicis intentats:  ";
 
    if(num[i]>0)cout<<alumne[i]<<" ("<<num[i]<<')';
    else cout<<'-';
    cout<<endl;
  }
  cout<<"alumne que ha fet l'ultim enviament: "; //El ultimo depende de si hay algun ejercicio
  if(num[3]>0)cout<<alumne[4]<<endl;
  else cout<<'-'<<endl;
}
 
int main(){
 
  int n;
  cin>>n;
  Historia h(n);
 
  for(int i=0; i<n; i++)llegeix_env(h[i]);
  sort(h.begin(),h.end(),cond);
 
  vector<string> alumne(5);
  vector<int> num(5,0);
  obte_resultats(h,alumne,num);
  mostra_resultats(alumne,num);
}
