#include <iostream>
#include <vector>

using namespace std;

typedef vector<vector<int> > Matriu;

void leer_matriz(Matriu& v)
{
  int nfilas = v.size();
  int ncolumnas = v[0].size();
  for(int i=0;i<nfilas;++i)
    for(int j=0;j<ncolumnas;++j)
      cin >> v[i][j];
}

bool es_ziga_zaga(const Matriu& v)
{  
  int ant = v[0][0];
  int i=1;
  int factor=1;
  for(int j=0;j<int(v[0].size());++j){
    int n = v.size();
    while(i >= 0 and i < n){
      if(ant>=v[i][j]) return false;
      ant = v[i][j];
      i = i + factor;
    }
    factor = -factor;
    i = i + factor;
  }
  return true;
}

int main()
{
  int nfiles,ncolumnas;
  int cont=1;
  while(cin >> nfiles >> ncolumnas){
    
    Matriu v(nfiles,vector<int>(ncolumnas));
    leer_matriz(v);
    if(es_ziga_zaga(v)) cout << "matriu " << cont << ": si" << endl;
    else cout << "matriu " << cont << ": no" << endl;
    ++cont;
  }
}