#include <iostream>
using namespace std;

int canvi_base_3(int n) {
    int aux;
    int err; 
    err= n%3 +1;
    aux = err;
    n = n/3;
    while (n != 0) {
        err = n%3 + 1;
        aux = 10*aux + err;
        n = n/3;
        }
        return aux;
}
      



int main (){
    int n;
    while (cin>>n){
        if (n < 0) {
            n = -1*n;
            cout << ':';}
        n=canvi_base_3(n);
        while (n!=0){
            if (n%10==1)cout<<"-";
            else if (n%10==2)cout<<"+";
            else if (n%10==3)cout<<"*";
            n/=10;
        }cout<<endl;
    }
   
}

