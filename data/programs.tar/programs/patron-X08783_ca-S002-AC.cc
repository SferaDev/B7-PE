#include <iostream>

using namespace std;

int main (){
  
  int b,n;

  
  while (cin>>b>>n){
    
    int r=0;
    
    while (b > 1 and n > 0 ){
      
      n /= b;
      ++r;
      
    }
    cout << r << endl;
  }
}