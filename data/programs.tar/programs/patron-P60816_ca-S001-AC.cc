#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    if (n==0)
    cout<<0;
    else for(int i=n;n>0;i=n/=16)
    if (i%16==10) cout<<"A";
    else if (i%16==11) cout<<"B";
    else if (i%16==12) cout<<"C";
    else if (i%16==13) cout<<"D";
    else if (i%16==14) cout<<"E";
    else if (i%16==15) cout<<"F";
    else cout<<i%16;
    cout<<endl;
}