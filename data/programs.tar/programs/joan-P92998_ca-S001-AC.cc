#include <iostream>
#include <string>
using namespace std;

void reverse (int n){
    string s;
    if (n == 1){
        cin >> s;
        cout << s << endl;
    }
    else {
        cin >> s;
        reverse(n - 1);
        cout << s << endl;
    }
}

int main(){
    int n;
    cin >> n;
    if (n != 0)reverse (n);
}