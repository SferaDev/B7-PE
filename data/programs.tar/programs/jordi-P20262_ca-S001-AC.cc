#include <iostream>

using namespace std;

int main (){
  int n;
  while (cin >> n){
    int y=n;
    int x, suma,sumab, maxsum;
    suma=maxsum=sumab=0;
    for (int i=1; i<=n; ++i){
      cin >> x;
      suma=suma+x; // de izquierda a derecha
      sumab=sumab+x;//voy sumando y si es negativo la igualo a 0. Es para el valor de derecha a izquierda
      if (suma>=maxsum) maxsum=suma;
      if (sumab <0) sumab=0;
    }
    cout << maxsum << " " << sumab << endl;
  }
}
  