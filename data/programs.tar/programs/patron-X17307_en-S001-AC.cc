#include <iostream>
using namespace std;
 
int main(){
  int x;
  while (cin >> x) {
    
    int anterior, y, dismax, dis, aux;
    dismax = dis = aux = 0;
    cin >> anterior;
    for(int i=0; i<x-1; ++i){
      
      cin >> y;
      aux = y;
      if (aux > anterior) dis = aux - anterior;
      else if (aux < anterior) dis = anterior - aux;
      anterior = aux;
      if (dis > dismax) dismax = dis;
      
    }
    
    cout << dismax << endl;
  
    
  }
 }