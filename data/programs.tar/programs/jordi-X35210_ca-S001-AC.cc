#include <iostream>

using namespace std;

void base3(int n){
  if (n<0){
    n=-n;
    cout << ':';
  }
  if ( n==1){
     if ( n== 2) cout << '*';
     else if ( n== 1) cout << '+';
     else if ( n== 0) cout << '-';
   }else if (n>0){
     base3 (n/3);
     if ( n%3== 2) cout << '*';
     else if ( n%3== 1) cout << '+';
     else if ( n%3== 0) cout << '-';
  }
}
 


int main (){
  int n;
  while (cin >> n){
    if (n==0) cout << '-';
    base3(n);
    cout << endl;
  }
}
  