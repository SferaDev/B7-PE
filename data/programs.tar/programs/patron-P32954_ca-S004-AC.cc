#include <iostream>
#include <algorithm>
using namespace std;


void sort3(int& a, int& b, int& c)
{
  int minim,maxim;
  maxim = max(a,max(b,c));
  minim = min(a,min(b,c));
  if(maxim == a){
    if(minim == b){
      a = minim;
      b = c;
      c = maxim;
    }else{
      a = minim;
      c = maxim;
    }
  }
  else if(maxim == b){
    if(minim == a ){
      b = c;
      c = maxim;
    }else{
      b = a;
      a = minim;
      c = maxim;
    }
  }else{
    if(minim == b){
      b = a;
      a = minim;
    }
  }
}

int main(){
  int a,b,c;
  while (cin >> a >> b >> c){
    sort3(a,b,c);
    cout << a << ' ' << b << ' ' << c << endl;
  }
}