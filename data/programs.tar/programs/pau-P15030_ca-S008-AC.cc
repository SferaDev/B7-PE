#include <iostream>
#include <vector>
using namespace std;

int main () {
  int n;
  int k;
  int p;
  char c;
  cin >> n >> p >> k >> c;
  vector<string> S(n);
  for (int i = 0; i < n; ++i) {
    cin >> S[i];
  }
  if (c == 'd') {
    bool primer = true;
    int fin = k + p;
    if (fin > n) {
      for (int i = p + 1; i < n; ++i) {
	if (primer) {
          cout << S[i];
	  primer = false;
	} else {
	  cout << ' ' << S[i];
	}
      }
      fin = k - n + p + 1;
      for (int i = 0; i < fin; ++i) {
        if (primer)  {
	  cout << S[i];
	  primer = false;
	} else {
	  cout << ' ' << S[i];
	}
      }
    } else  {
      for (int i = p + 1; i <= fin; ++i) {
	if (primer)  {
	  cout << S[i];
	  primer = false;
	} else {
	  cout << ' ' << S[i];
	}
      }  
    }
    cout << endl;
  } else {
    bool primer = true;
    int fin = p - k - 1;
    if (fin < 0) {
      for (int i = p - 1; i >= 0; --i) {
        if (primer)  {
	  cout << S[i];
	  primer = false;
	} else {
	  cout << ' ' << S[i];
	}
      }
      for (int i = n - 1; i > n + fin; --i) {
        if (primer)  {
	  cout << S[i];
	  primer = false;
	} else {
	  cout << ' ' << S[i];
	}
      }
    } else {
      for (int i = p - 1; i > fin; --i) {
        if (primer)  {
	  cout << S[i];
	  primer = false;
	} else {
	  cout << ' ' << S[i];
	}
      }
    }
    cout << endl;
  }
}
