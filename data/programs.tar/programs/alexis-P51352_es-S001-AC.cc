#include <iostream>
using namespace std;

/* SPEC
 * 
 * in: Dos letras (A, P o V) separados por un espacio.
 * 
 * out: Escribe una línea con el número 1 si vence el primero,
 * el número 2 si vence el segundo, o un guión (‘-’) si se produce un empate.
 * 
 */

int main() {
    char x, y;
    cin >> x >> y;
    
    if (x == y) {
        cout << '-' << endl;
    } else if (x == 'A' && y == 'P') {
        cout << 1 << endl;
    } else if (x == 'P' && y == 'V') {
        cout << 1 << endl;
    } else if (x == 'V' && y == 'A') {
        cout << 1 << endl;
    } else {
        cout << 2 << endl;
    }
}