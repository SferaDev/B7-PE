#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef vector <int> fila;
typedef vector <fila> matriu;

void llegeix_matr (matriu &M) {
  int n = M.size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < 2*n; ++j) cin >> M[i][j];
  }
}

void imprimeix_matr (const matriu &M) {
  int n = M.size();
  for (int i = 0; i < n; ++i) {
    bool primer = true;
    for (int j = 0; j < 4; ++j) {
      if (primer) primer = false;
      else cout << ' '; 
      cout << M[i][j];
    }
    cout << endl;
  }
}

matriu info (const matriu &M) {
  int n = M.size();
  matriu res (n, fila(4,0));
  for (int i = 0; i < n; ++i) res[i][0] = i + 1;
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < 2*n; j += 2) {
      if (i != j/2) {
	if (M[i][j] == M[i][j+1]) {
	  ++res[i][1];
	  ++res[j/2][1];
	} 
	else if (M[i][j] > M[i][j+1]) res [i][1] += 3;
	else if (M[i][j] < M[i][j+1]) res [j/2][1] += 3;
	res[i][2] += M[i][j]; // A favor (local)
	res[i][3] += M[i][j+1]; // En contra (local)
	res[j/2][2] += M[i][j+1];  // A favor (visitant)
	res[j/2][3] += M[i][j];  // En contra (visitant)
      }
    }
  }
  return res;
}

bool ordena (const fila &a, const fila &b) {
  if (a[1] > b[1]) return true;
  if ((a[2] - a[3]) > (b[2] - b[3]) and a[1] == b[1]) return true;
  if ((a[2] - a[3]) == (b[2] - b[3]) and a[1] == b[1] and a[0] < b[0]) return true;
  return false;
}

int main () {
  int n; cin >> n;
  matriu a (n, fila(2*n));
  llegeix_matr(a);
  matriu res = info(a);
  sort (res.begin(), res.end(), ordena);
  imprimeix_matr(res);
}
