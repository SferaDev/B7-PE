#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b)
{
  int dni = est.consultar_DNI();
  int index = cerca_dicot(vest,0,nest-1,dni);
  
  if(index < nest and dni == vest[index].consultar_DNI()){
    b = true;
  }else{
    
    ++nest;
    for(int i=nest-1; i>index;--i)
      vest[i] = vest[i-1];
    vest[index] = est;
    recalcular_posicio_imax();
    b = false;
  }
}

void Cjt_estudiants::eliminar_estudiants_sense_nota()
{
  int i=0;
  while(i < nest){
    if(not vest[i].te_nota()){
      for(int j=i;j<nest;++j)
	vest[j]=vest[j+1];
      --nest;
    }
    else ++i;
  }
  recalcular_posicio_imax();
}