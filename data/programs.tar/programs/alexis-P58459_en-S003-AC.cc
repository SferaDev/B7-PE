#include <iostream>
using namespace std;

// Check if it's leap year
bool isLeapYear(int year) {
    int compareYear = year/100;
    if (year%4 == 0 && year%100 != 0) {
        return true;
    } else if (year%100 == 0 && compareYear%4 == 0) {
        return true;
    } else {
        return false;
    }
}

// Check if numbers of day in a month is valid
int getMaxDays(int month, int year) {
    if (month == 2 && isLeapYear(year)) {
        return 29;
    } else if (month == 2 && !isLeapYear(year)) {
        return 28;
    } else if (month < 8 && month%2 != 0) {
        return 31;
    } else if (month >= 8 && month%2 == 0) {
        return 31;
    } else {
        return 30;
    }
}

// Valid dates function
bool is_valid_date(int d, int m, int y) {
    bool validDay = (d >= 1) && (d <= getMaxDays(m, y));
    bool validMonth = (m >= 1) && (m <= 12);
    bool validYear = (y >= 1800) && (y <= 9999);
    return validDay && validMonth && validYear;
}