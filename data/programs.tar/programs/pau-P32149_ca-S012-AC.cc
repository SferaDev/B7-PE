#include <iostream>
using namespace std;

int nombre_digits(int n){
  if (n >= 10) return 1 + nombre_digits(n/10);
  return 1; 
}

bool es_ascendent(int n) {
  if (n < 0) n = 0 - n;
  int numant = n%10;
  while (n >= 10) {
    bool nouzero = false;
    int numact = (n/10)%10; 
    if (numant == 0 and numact == 9) nouzero = true;
    if (numant == 0 and numact != 9) return false;
    if (numant != numact + 1 and not nouzero) return false;
    n /= 10;
    numant = numact;
  }
  return true;
}

int main () {
  bool consecutiu = false;
  int n;
  cin >> n;
  bool numant = es_ascendent(n);
  while (not consecutiu and cin >> n) {
    bool numact = es_ascendent(n);
    if (numant and numact) consecutiu = true;
    numant = numact;
  }
  if (consecutiu) cout << "SI" << endl;
  else cout << "NO" << endl;
}
