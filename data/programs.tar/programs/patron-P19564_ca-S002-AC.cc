#include <iostream>

using namespace std;


int valencia(int n) {
    int suma = 0;
    while (n > 0) {
        if (n > 0) {
            suma = suma + n%10;
            n = n/10;
            suma -=n%10;
            n /=10;
        }
    }
    return suma;
}

int main() {
     int n;
     int max_val;
     bool found = false;
     while (cin >> n and not found) {
         int val = valencia(n);
         if (val == 0 and not found) {
             cout << "El primer nombre equilibrat es " << n << '.' << endl;
             found = true;
         }
         else if (val < 0) val = val*-1;
         if (val > max_val) max_val = val;
     }
    if(not found) cout << "La valencia maxima es "<< max_val << '.' << endl;
}
