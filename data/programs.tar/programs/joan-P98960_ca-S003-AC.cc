#include<iostream>
using namespace std;

int main (){
    char x;
    cin >>x;
  
    if (x>=97 and x<=122) {
        x-=32;
        cout<< x <<endl;
    }
      else if (x>=65 and x<=90) {
        x=x+32;
        cout<< x <<endl;
    }
}