#include <iostream>
using namespace std;

bool romulan (int n) {
  bool parell = false;
  bool senar = false;
  for (int i = 0; i < n; ++i) {
    int act; cin >> act;
    if (act%2 == 0) parell = true;
    else senar = true;
  }
  return senar and parell;
}

int main () {
  int n;
  while (cin >> n) {
    if (romulan(n)) cout << "si" << endl;
    else cout << "no" << endl;
  }
}
