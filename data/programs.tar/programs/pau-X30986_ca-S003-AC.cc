#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Paraula {
  string nom;
  int cont;
};

bool ordenar (const Paraula& p1, const Paraula& p2) {
  if (p1.cont > p2.cont) return true;
  if (p1.cont == p2.cont and p1.nom < p2.nom) return true;
  return false;
}

typedef vector<Paraula> Paraules;

void imprimeix (const Paraules& p) {
  for (int i = 0; i < p.size(); ++i) {
    cout << p[i].cont << ' ' << p[i].nom << endl;
  }
  cout << "----------" << endl;
}

int main () {
  int n;
  while (cin >> n) {
    vector<string> noms;
    for (int i = 0; i < n; ++i) {
      string a;
      cin >> a;
      noms.push_back(a);
    }
    sort (noms.begin(), noms.end());
    Paraules p;
    int j = 0;
    Paraula a;
    bool primer = true; 
    for (int i = 0; i < n; ++i) {
      if (primer) {
	p.push_back(a);
	p[j].nom = noms[i];
	p[j].cont = 1;
	primer = false;
      } else {
	if (noms[i] == noms[i-1]) {
	  ++p[j].cont;
	} else {
	  p.push_back(a);
	  ++j;
	  p[j].nom = noms[i];
	  p[j].cont = 1;
	}
      }
    }
    sort (p.begin(), p.end(), ordenar);
    imprimeix (p);
  }
}

    
    