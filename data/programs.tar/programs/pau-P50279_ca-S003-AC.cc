#include <iostream>
using namespace std;

char complement(char c){
  if (c == 'A') return 'T';
  if (c == 'C') return 'G';
  if (c == 'T') return 'A';
  return 'C';
}

bool sequencia (char c1, char c2, char c3) {
  if (c1 == 'T' and c2 == 'A' and c3 == 'G' ) return true;
  return false;
}

int main () {
  char c1, c2, c3;
  while (!sequencia(c1,c2,c3) and (cin >> c1 >> c2 >> c3)) {
    if (c3 == 'T') {
      c1 = c3;
      cin >> c2 >> c3;
    }
    if (c2 == 'T' and c3 == 'A') {
      c1 = c2;
      c2 = c3;
      cin >> c3;
    }
  }
  char cf;
  while (cin >> cf) cout << complement(cf);
  cout << endl;
}
