#include <iostream>

using namespace std;

int potencia2(int n)
{
  int suma=0;
  for (int i=1; i<=n; ++i)
  {
    suma=suma+(i*i);
  }
  return suma;
}

int main ()
{
  int n;
  cin >> n;
  cout << potencia2(n) << endl;
}