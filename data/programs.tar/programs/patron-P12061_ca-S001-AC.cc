#include <iostream>
#include <string>

using namespace std;

int main() {
    string n;
    bool empieza = true;
    bool final = false;
    int cuenta = -1;
    while (cin >> n and n != "final") {
        if (n == "principi") empieza = false;
        if (not empieza and not final) ++cuenta;
    }
    if (empieza or n != "final") cout << "sequencia incorrecta" << endl;
    else cout << cuenta << endl;
}
