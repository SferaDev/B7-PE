#include <iostream>
using namespace std;

void swap2(int& a, int& b){
  int m;
  m=a;
  a=b;
  b=m;
} int main(){
  int a,b;
  cin>>a>>b;
  swap2(a,b);
  cout<<a<<b;
}