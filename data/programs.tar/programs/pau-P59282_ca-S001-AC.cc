#include <iostream>
#include <map>

using namespace std;

int main ()
{
  cout.setf(ios::fixed);
  cout.precision(4);
  map<double,int> m;
  string op;
  double cont = 0;
  double tot = 0;
  while (cin >> op)
  {
    if (op == "number")
    {
      double num; cin >> num;
      auto info = m.emplace(num,1);
      if (not info.second) ++info.first->second;
      ++cont;
      tot += num;
    }
    else
    {
      if (not m.empty())
      {
        --cont;
        tot -= m.begin()->first;
        --m.begin()->second;
        if (m.begin()->second <= 0) m.erase(m.begin()->first);
      }
    }
    if (not m.empty())
    {
      cout << "minimum: " << (int)m.begin()->first << ", maximum: " << (int)m.rbegin()->first;
      cout << ", average: " << tot/cont << endl;
    }
    else cout << "no elements" << endl;
  }
}