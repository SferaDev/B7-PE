#include <iostream>
#include <vector>
#include <list>

using namespace std;

typedef vector<vector<int>> graph;

bool es_ciclico(int x, const graph& G, vector<bool>& visitat, vector<int>& padre)
{
  if(visitat[x]) return true;
  visitat[x] = true;
  for (int y : G[x]){
    if (padre[x] != y){
      padre[y] = x;
      if(es_ciclico(y, G,visitat,padre)) return true;
    }
  }
  return false ;
}



int nombre_arbres(const graph &G)
{
  vector<bool> visitat(G.size(),false);
  vector<int> padre(G.size(),-1);
  int n_arb = 0;
  for(int i = 0; i < G.size(); ++i){
    if(not visitat[i]){
      if(es_ciclico(i,G,visitat,padre)) return -1;
      else ++n_arb;
    }
  }
  return n_arb;
}

int main()
{
  int n, m;
  while(cin >> n >> m){
    int x, y;
    int cont = 0;
    graph G(n);
    for(int i=0; i < m; ++i){
      int x,y;
      cin >> x >> y;
      G[x].push_back(y);
      G[y].push_back(x);
    }
    int arbres = nombre_arbres(G); 
    if(arbres == -1) cout << "no" << endl;
    else cout << arbres << endl;
  }
}