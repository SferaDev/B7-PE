#include <iostream>
using namespace std;

void girpa (int cont,int& n) {
  string act;
  bool chivato = false;
  if (cin >> act) girpa (++cont, n);
  else {
    n = cont;
    chivato = true;
  }
  if (cont <= n/2 and not chivato) cout << act << endl; 
}

int main () {
  int cont = 0;
  int n = 0;
  girpa (cont, n);
}
