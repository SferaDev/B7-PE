#include <iostream>
using namespace std;

int main(){
  int n;
  cin >> n;
  cout << n;
  int sum = 0, i = 1;
  while (n > 0){
    if (i%2 != 0) sum += n%10;
    n /= 10;
    ++i;  
  }
  if (sum%2 == 0) cout << " ES TXATXI";
  else cout << " NO ES TXATXI";
  cout << endl;
}