#include <iostream>
#include <vector>
   
using namespace std;

typedef vector < vector <int> > Mivector;

void llegeix( Mivector& v) {
  for ( int i = 0; i < v.size(); ++i) {
    for ( int j = 0; j < v[i].size(); ++j) {
      cin >> v[i][j];
    }
  }
}
    
bool busqueda(const Mivector& v) {
  int a, b;
  a = v[0][0] - 1;
  int nc = v[0].size();
  int nf = v.size();
  for ( int j = 0; j < nc; ++j) {
    for ( int i = 0; i < nf; ++i) {
      if ( j%2 == 0) b = v[i][j];
      else b = v[nf - 1 - i][j];
      if ( b <= a) return false;
      a = b;
    }
  }
  return true;
}
  

int main () {
  int a, b;
  int cont = 0;
  while ( cin >> a >> b) {
    ++cont;
    Mivector v(a,vector<int>(b));
    llegeix (v);
    if (busqueda(v)) cout << "matriu " << cont << ":" << " si" << endl;
    else cout << "matriu " << cont << ":" << " no" << endl;
  }
}
	 