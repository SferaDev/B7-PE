#include <iostream>
#include <string>
using namespace std;


int main()
{
	string s1,s2,s3;
	cin >> s1 >> s2 >> s3;
	cout << s3 << ' ' << s2 << ' ' << s1 << endl;
}
