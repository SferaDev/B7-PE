#include <iostream>
using namespace std;

char atbash(char c){
    if (c>='a' and c<='z') return char('Z'-(c-'a'));
    else if (c<='Z' and c>='A') return char('Z'-(c-'A'));
    else return '?';
}


void print_atbash_encipherment(){
  char c;
  while ( cin >> c and c != '#'){
    char transformacio = atbash(c);
    if ( transformacio != '?') cout << atbash(c);
  }
    cout << '#' << endl; 
}

int main (){
    print_atbash_encipherment();
}