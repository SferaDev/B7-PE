#include<iostream>
using namespace std;
 
int numero_de_xifres (int n) {
        int count = 0;
        while (n > 0) {
                n = n/10;
                ++count;
        }
        return count;
}
 
int rotacio_dreta (int x, int k) {
        if (k > 0) return x%10 + rotacio_dreta(x/10,--k)*10;
        return 0;
}
 
int main() {
        int x1, k1;
        while (cin >> x1 >> k1) {
                int x3 = x1;
                int k2 = k1;
                int s = numero_de_xifres(x1) - k1;
                while (k2 > 0) {
                        x3 = x3/10;
                        --k2;
                }
                int x4 = rotacio_dreta(x1,k1);
                while (s > 0) {
                        x4 = x4*10;
                        --s;
                }
                cout << x4 + x3 << endl;
        }
}
