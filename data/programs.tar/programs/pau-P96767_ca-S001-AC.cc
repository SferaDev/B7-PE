#include <iostream>
#include <math.h>
using namespace std;
int main() {
  cout.setf(ios::fixed);
  cout.precision(4);
  double x;
  cin >> x;
  int exp = 0;
  double a;
  double tot = 0;      
  while (cin >> a) {   
     tot += a * pow(x,exp);
     ++exp;      
  }
  cout << tot << endl;                                                                        
} 
