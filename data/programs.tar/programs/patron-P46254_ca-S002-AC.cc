#include <iostream>
#include <cmath>

using namespace std;

struct Punt { 
  double x, y; 
};

double distancia(const Punt& a, const Punt& b)
{
  return sqrt( ((max(a.x,b.x)-min(a.x,b.x)) * (max(a.x,b.x) - min(a.x,b.x))) + ((max(a.y,b.y)-min(a.y,b.y)) * (max(a.y,b.y) - min(a.y,b.y))));
}
