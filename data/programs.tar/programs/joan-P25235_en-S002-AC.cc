#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#define infinit -1

using namespace std;

typedef pair<double, int> WArc; // weighted arc
typedef vector<vector<WArc>> WGraph; // weighted digraf

int dijkstra(const WGraph& G, int s, int x, vector <int> &p, vector <int> &steps){
  int n = G.size();
  vector<double> d(n, infinit); d[s] = 0;
  vector<bool> S(n, false);
  p = vector<int>(n, -1);
  steps = vector<int>(n, 0);
  priority_queue<WArc, vector<WArc>, greater<WArc> > Q;
  Q.push(WArc(0, s));
  while (not Q.empty()){
    int u = Q.top().second; Q.pop();
    if (not S[u]){
      S[u] = true;
      for (WArc a : G[u]){
        int v = a.second;
        double c = a.first;
        if ((d[v] > d[u] + c) or d[v] == infinit){
          steps[v] = steps[u] + 1;
          d[v] = d[u] + c;
          p[v] = u;
          Q.push(WArc(d[v], v));
        }
        else if ((d[v] == d[u] + c) and steps[v] > steps[u] + 1) steps[v] = steps[u] + 1;
      }
    }
  }
  return d[x];
}

void read (WGraph& G){
  int m; cin >> m;
  for (int i = 0; i < m; ++i){
    int u,v;
    double c;
    cin >> u >> v >> c;
    G[u].push_back(make_pair(c,v));
  }
}

void print (const vector <int> &p , int y, int c){
  stack <int> s;
  bool found = false;
  int i = y;
  int cont = -1;
  while (not found){
    s.push(i);
    i = p[i];
    found = i == -1;
    ++cont;
  }
  bool first = true;
  cout << "cost " << c <<", " << cont << " step(s)" <<endl;
}

int main (){
  int n;
  while (cin >> n){
    WGraph G(n);
    read(G);
    int x,y; cin >> x >> y;
    vector <int> p;
    vector <int> steps;
    int c = dijkstra(G, x, y, p, steps);
    if (c != -1)
    cout << "cost " << c << ", " << steps[y] << " step(s)" << endl;
    else cout << "no path from " << x << " to " << y << endl;
  }
}
