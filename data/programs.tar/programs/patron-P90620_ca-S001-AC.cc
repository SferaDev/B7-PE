#include <iostream>

using namespace std;

int main ()
{
	int anterior, actual, posterior;
	cin >> anterior >> actual >> posterior;
	bool pic=false;
	
	while (anterior != 0 and actual != 0 and posterior != 0){
		if (anterior < actual and posterior < actual and actual > 3143) pic = true;
		anterior = actual;
		actual = posterior;
		cin >> posterior;
	}
	
	if (pic) cout << "SI" << endl;
	else cout << "NO" << endl;
}
