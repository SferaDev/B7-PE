#include <iostream>
#include <string>

using namespace std;

int main() {
    string n;
    bool comienza = true;
    bool final = false;
    int cont = -1;
    while (cin >> n and n != "final") {
        if (n == "principi") comienza = false;
        if (not comienza and not final) ++cont;
    }
    if (comienza or n != "final") cout<<"sequencia incorrecta"<< endl;
    else cout <<cont<< endl;
}
