#include<iostream>
#include <vector>

using namespace std;

int main(){
    int n;
    while (cin >> n) {
        vector<int> entrada(n);
        vector<int> entrada_sin_repetir(n);
        int g = 0;
        for (int i = 0; i < n; ++i) {
            cin >> entrada[i];
            bool repite = false;
            int m = 0;
            while (not repite and m < i) {
                if (entrada[i] == entrada_sin_repetir[m]) repite = true;
                ++m;
            }
            if (not repite) {
                entrada_sin_repetir[g] = entrada[i];
                ++g;
            }
        }
        //for (int i = 0; i < g; ++i) cout << "ENTRADA SIN REPETIR: " << entrada_sin_repetir[i] << endl;
        vector<int> repeticiones(g);
        int max_rep = 0;
        for (int i = 0; i < g; ++i) {
            int aux = 0;
            for (int k = 0; k < n; ++k) {
                if (entrada_sin_repetir[i] == entrada[k]) ++aux;
            }
            repeticiones[i] = aux;
            if (aux > max_rep) max_rep = aux;
        }
        int mas_grande_con_max_rep = 0;
        for (int i = 0; i < g; ++i) {
            if (repeticiones[i] == max_rep and entrada_sin_repetir[i] > mas_grande_con_max_rep) mas_grande_con_max_rep = entrada_sin_repetir[i];
        }
        cout << mas_grande_con_max_rep << endl;

    }
}