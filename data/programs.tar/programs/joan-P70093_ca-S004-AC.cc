#include <iostream>
#include <vector>

using namespace std;


vector<double> fusio(const vector<double>& v1, const vector<double>& v2){
  int n= v1.size();
  int m= v2.size();
  int l=n+m;
  vector <double> v3(l);
  int i=0;
  int q=0;
  int k=0;
  while (i<v1.size() and q<v2.size()){
    if (v1[i]==v2[q]){
      v3[k]=v1[i];
      v3[k+1]=v2[q];
      k=k+2;
      ++i;
      ++q;
    } else if (v1[i]<v2[q]){
      v3[k]=v1[i];
      ++i;
      ++k;
    }else if (v1[i]>v2[q]){
      v3[k]=v2[q];
      ++q;
      ++k;
    }
  }
  while (i<v1.size()){
    v3[k]=v1[i];
    ++i;
    ++k;
  }
  while (q<v2.size()){
    v3[k]=v2[q];
    ++q;
    ++k;
  }
  return v3;
}

