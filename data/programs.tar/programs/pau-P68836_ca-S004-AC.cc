#include <iostream>
using namespace std;

struct Data 
{
  int dia, mes, any;
};

bool menor(const Data& d1, const Data& d2) 
{
  if (d1.any < d2.any) return true;
  if (d1.mes < d2.mes and d1.any == d2.any) return true;
  if (d1.dia < d2.dia and d1.mes == d2.mes and d1.any == d2.any) return true;
  return false;
}

int entrada () 
{
  int tot;
  char c;
  cin >> tot >> c;
  return tot;
}
void imprimeix_data (const Data& d) 
{
  cout << d.dia << '/';
  cout << d.mes << '/';
  cout << d.any << endl;
}

void llegix_data (Data& d) 
{
  d.dia = entrada();
  d.mes = entrada();
  cin >> d.any;  
}

int main () 
{
  int n;
  cin >> n;
  Data d1,d2,d3,elegida;
  llegix_data(d1);
  llegix_data(d2);
  bool trobat = false;
  for (int i = 2; i < n and not trobat; ++i) 
  {
    llegix_data(d3);
    if (menor(d1,d2) and menor (d2,d3) or menor(d2,d1) and menor (d3,d2)) 
    {
      trobat = true;
      elegida = d2;     
    }
    d1 = d2;
    d2 = d3;
  }
  if (not trobat) cout << "cap data trobada" << endl;
  else imprimeix_data(elegida);  
}