#include <iostream>
#include <vector>
#include <string>
using namespace std;
 
 struct Paraula {
    string contingut; // la paraula
        int consonants; // nombre d�aparicions de consonants
 };
 
typedef vector< vector<Paraula> > MatParaules;
 
bool es_consonant(char a) {
        return (a != 'A' and a != 'E' and a != 'I' and a != 'O' and a != 'U');
}
 
void llegeix_matriu(MatParaules& m) {
        for (int i = 0; i < m.size(); ++i) {
                for (int j = 0; j < m[0].size(); ++j) {
                        cin >> m[i][j].contingut;
                        m[i][j].consonants = 0;
                        for (int k = 0; k < m[i][j].contingut.size(); ++k) {
                                if (es_consonant(m[i][j].contingut[k])) ++m[i][j].consonants;
                        }
                }
        }
}
 
bool esc_consonant(const MatParaules& m, int x, int y, int k) {
        int f = m.size();
        int c = m[0].size();
        int i = x, j = y;
        if ((x + k - 1) < f and (y + k - 1) < c) {
                while (i < x + k - 1 and j < y + k - 1) {
                        if (m[i][j].consonants >= m[i+1][j+1].consonants) return false;
                        else {
                                ++i;
                                ++j;
                        }
                }
                return true;
        }
        return false;
}
int main() {
        int n,m,k;
        cin >> n >> m >> k;
        MatParaules mat(n,vector<Paraula>(m));
        llegeix_matriu(mat);
        bool trobada = false;
        int i, j;
        i = j = 0;
        while (not trobada and i < n) {
                if (esc_consonant(mat,i,j,k)) trobada = true;
                else {
                        ++j;
                        if (j == m) {
                                ++i;
                                j = 0;
                        }
                }
        }
        if (trobada) cout << i << " " << j << " " << mat[i][j].contingut << endl;
        else cout << "-1 -1" << endl;
}
