#include<iostream>
using namespace std;

int main (){
  int a,b;
  cin>>a>>b;
  int d;
  d=a/b;
  cout<<d<<" ";
  int r;
  r=a%b;
  cout<<r<<endl;
}
