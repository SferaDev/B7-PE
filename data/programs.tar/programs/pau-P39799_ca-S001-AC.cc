#include <iostream>
#include <math.h>
using namespace std;

struct Punt {
  double x, y;
};

struct Cercle {
  Punt centre;
  double radi;
};

void escala(Cercle& c, double esc) {
  c.radi *= esc;
}

void desplaca(Cercle& c, const Punt& p) {
  c.centre.x += p.x;
  c.centre.y += p.y;
}

void desplaca(Punt& p1, const Punt& p2) {
  p1.x += p2.x;
  p1.y += p2.y;
}

void llegeix(Punt& p) {
  cin >> p.x >> p.y;
}

void llegeix(Cercle& c) {
  llegeix(c.centre);
  cin >> c.radi;
}

bool es_interior(const Punt& p, const Cercle& c) {
  if (pow(p.x - c.centre.x,2) + pow(p.y-c.centre.y,2) < pow(c.radi,2))
  return true;
  return false;
}

int main () {
  Cercle c;
  Punt p;
  llegeix(c);
  llegeix(p);
  bool previ = es_interior(p,c);
  if (previ) cout << "inicialment a dins" << endl;
  else cout << "inicialment a fora" << endl;
  int n; cin >> n;
  for (int i = 1; i <= n; ++i) {
    Punt a;
    llegeix (a);
    desplaca (p,a);
    bool act = es_interior(p,c);
    if (act != previ) {
      if (act) cout << "al pas " << i << " ha entrat a dins" << endl;
      else cout << "al pas " << i << " ha sortit a fora" << endl;
    }
    previ = act;
  }   
}
