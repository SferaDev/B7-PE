#include <iostream>

using namespace std;

int compara (int d1, int m1, int a1, int d2, int m2, int a2)
{
  int x,y;
  x=a1*480+m1*40+d1;
  y=a2*480+m2*40+d2;
  int res;
  //if (a1>a2 or (a1==a2 and (m1>m2 or (m1==m2 and (d1>d2))))) {
  if (x>y){
    res=1;
  } else if (x<y){
    res=-1;
  } else if (x==y){
    res=0;
  }
  return res;
}

int main()
{
  char c;
  int d1,m1,a1,d2,m2,a2;
  while (cin>>d1>>c>>m1>>c>>a1>>d2>>c>>m2>>c>>a2){
    if(compara(d1,m1,a1,d2,m2,a2)>0){
      cout<<"posterior"<<endl;
    } else if (compara(d1,m1,a1,d2,m2,a2)<0){
      cout<<"anterior"<<endl;
    } else if (compara (d1,m1,a1,d2,m2,a2)==0)
      cout<<"iguals"<<endl;
  }
}
