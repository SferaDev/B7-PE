#include "Cjt_estudiants.hh"
#include "PRO2Excepcio.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b) {
  // Find position with dicot search
  int pos = cerca_dicot(vest, 0, nest-1, est.consultar_DNI());
  // b means FOUND, think about it (Hint: DNI is a unique identifier)
  b = vest[pos].consultar_DNI() == est.consultar_DNI();
  // If student is not found add it in pos
  if (!b) {
    // Move all the values ahead one place
    for (int i = nest; i > pos; --i) {
      vest[i] = vest[i - 1];
    }
    // Add est in its pos
    vest[pos] = est;
    // Increment nest because it's a nice thing to do in linear time
    nest += 1;
    recalcular_posicio_imax();
  }
}

void Cjt_estudiants::eliminar_estudiants_sense_nota() {
  // Let's find the position, shall we?
  for (int pos = nest - 1; pos >= 0; --pos) {
    if (!vest[pos].te_nota()) {
      for (int i = pos; i < nest - 1; ++i) {
        vest[i] = vest[i + 1];
      }
      nest -= 1;
    }
  }
  recalcular_posicio_imax();
}
