#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
  cout.setf(ios::fixed); 
  cout.precision(4);
  double c,i,t;
  string s;
  cin>>c>>i>>t>>s;
  if (s=="simple"){
    c=c*( 1+ (t* (i/100) ) ); //fórmula capital simple Cf = C0 * (1+i*t)
    cout << c << endl;
  } else {
    c=c* pow ((1+(i/100) ), t); //fórmula capital compost Cf = C0 * (1+i)^t
    cout<<c<<endl;
  }
}