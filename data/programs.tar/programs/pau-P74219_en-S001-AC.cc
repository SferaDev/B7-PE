#include <iostream>
#include <vector>

using namespace std;

typedef vector <vector<int> > matrix;

matrix mult(const matrix &a, const matrix &b, int m)
{
  matrix res(2, vector<int>(2,0));
  res[0][0] = ((a[0][0]*b[0][0])%m + (a[0][1]*b[1][0])%m)%m;
  res[0][1] = ((a[0][0]*b[0][1])%m + (a[0][1]*b[1][1])%m)%m;
  res[1][0] = ((a[1][0]*b[0][0])%m + (a[1][1]*b[1][0])%m)%m;
  res[1][1] = ((a[1][0]*b[0][1])%m + (a[1][1]*b[1][1])%m)%m;
  return res;
}

matrix dubstep (const matrix &M, int n, int m)
{
  matrix res(2, vector<int>(2,0));
  if (n == 0)
  {
    res[0][0] = 1;
    res[1][1] = 1;
  }
  else if (n == 1)
  {
    res[0][0] = M[0][0]%m;
    res[0][1] = M[0][1]%m;
    res[1][0] = M[1][0]%m;
    res[1][1] = M[1][1]%m;
  }
  else if (n % 2 == 0)
  {
    res = dubstep(M,n/2,m);
    res = mult(res,res,m);
  }
  else 
  {
    res = dubstep(M,(n-1)/2,m);
    res = mult(res,res,m);
    res = mult(res,M,m);
  }
  return res;
}

int main ()
{
  int n, m;
  while (cin >> n >> m)
  {
    if (n == 0) cout << 0 << endl;
    else 
    {
      matrix f = {{1, 1}, {1, 0}};
      matrix p = dubstep(f, n-1, m);
      cout << p[0][0] << endl;
    }
  }
}