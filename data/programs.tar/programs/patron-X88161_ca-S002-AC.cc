#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Partits{
  int local;
  int visitant;
};

struct Classificacio{
  int equip=0;
  int punts=0;
  int GF=0;
  int GC=0;
};

bool comp(const Classificacio& a, const Classificacio& b)
{
  int gol_av_a = a.GF-a.GC;
  int gol_av_b = b.GF-b.GC;
  if (a.punts == b.punts and (gol_av_a==gol_av_b)) return a.equip < b.equip;
  else if(a.punts == b.punts) return gol_av_a > gol_av_b;
  else return a.punts > b.punts;
}

void llegir_matriu(vector<vector<Partits> >& v)
{
  int n=v.size(); 	//files
  for (int i=0;i<n;++i){
    for (int j=0;j<n;++j){
      cin >> v[i][j].local >> v[i][j].visitant;
    }
  }
}

void res_classif(const vector<vector<Partits> > p,vector<Classificacio> &res)
{
  int n=p.size();
  int m=p[0].size();
  for(int i=0;i<n;++i){
    
    res[i].equip=i+1;
    
    for (int j=0;j<m;++j){
      if(i!=j){
	if(p[i][j].local > p[i][j].visitant){
	  
	  res[i].punts+=3;
	  res[i].GF+=p[i][j].local;
	  res[i].GC+=p[i][j].visitant;
	  res[j].GF+=p[i][j].visitant;
	  res[j].GC+=p[i][j].local;
	  
	} else if (p[i][j].local < p[i][j].visitant){
		
		res[i].GF+=p[i][j].local;
		res[i].GC+=p[i][j].visitant;
		res[j].punts+=3;
		res[j].GF+=p[i][j].visitant;
		res[j].GC+=p[i][j].local;
		
	} else if (p[i][j].local == p[i][j].visitant){
	  
		  res[i].punts+=1;
		  res[i].GF+=p[i][j].local;
		  res[i].GC+=p[i][j].visitant;
		  res[j].punts+=1;
		  res[j].GF+=p[i][j].visitant;
		  res[j].GC+=p[i][j].local;
	}
      }
    }
  }
}

int main()
{
  int n;
  cin >> n;
  vector<vector<Partits> > v(n,vector<Partits>(n));
  llegir_matriu(v);
  vector<Classificacio> res(n);
  res_classif(v,res);
  sort(res.begin(),res.end(),comp);
  for (int i=0;i<n;++i){
    cout << res[i].equip << ' ' << res[i].punts << ' ' << res[i].GF << ' ' << res [i].GC << endl;
  }
}