#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int main () {
    cout.setf(ios::fixed); 
    cout.precision(4);
    double i,TAE, p;
    string t;
    cin>>i>>t;
    if (t == "setmanal") p = 52;
    else if (t == "mensual") p = 12;
    else if (t == "trimestral") p = 4;
    else if (t == "semestral") p = 2;
    i=i/100;
    i=i/p;
    //al ser un interés compost, apliquem la fórmula de l'interés compost cf=ci*(1+i)^t
    TAE=1+i;
    while (p>1) {
        //Mentres que les setmanes restants no siguin més petites o igual que 1, anem elevant TAE i restem una setmana
        TAE=TAE*(1+i);
        --p;
    }
    
    cout<<100*(TAE-1)<<endl;
     
}