#include <iostream>
#include <vector>

using namespace std;

void processa (vector <char> &Res){
  for (int i = 0; i < Res.size(); ++i) cout << Res[i];
  cout << endl;
}
void permuta (int i, vector <pair <bool, char>> &con, vector <pair <bool, char>> &voc, vector <char> &Res){
  if (i == Res.size()) processa (Res);
  else{
    for (int j = 0; j < con.size(); ++j){
      if (not con[j].first){
        for (int k = 0; k < voc.size(); ++k){
          if (not voc[k].first){
            con[j].first = true;
            voc[k].first = true;
            Res[i] = con[j].second;
            Res[i+1] = voc[k].second;
            permuta(i+2,con,voc,Res);
            con[j].first = false;
            voc[k].first = false;
          }
        }
      }
    }
  }
}

void read (vector <pair <bool, char>> &con, vector <pair <bool, char>> &voc){
  for (int i = 0; i < con.size(); ++i){
    char c; cin >> c;
    con[i] = make_pair(false,c);
  }
  for (int i = 0; i < voc.size(); ++i){
    char c; cin >> c;
    voc[i] = make_pair(false,c);
  }
}

int main (){
  int n; cin >> n;
  vector <pair <bool, char>> con(n);
  vector <pair <bool, char>> voc(n);
  read (con, voc);
  vector <char> Res(2*n);
  permuta(0,con,voc,Res);
}
