#include <iostream>
#include <map>
#include <iterator>
#include <list>

using namespace std;

const int TOPE = 100000000;

void seguent (int x, int y, int &n)
{
  if (n%2 == 0) n = n/2 + x;
  else n = 3*n + y;
}

int main ()
{
  int x,y,n;
  while(cin >> x >> y >> n)
  {
    map<int, list<int>::iterator> s;
    list<int> l;
    auto info = s.emplace(n,l.begin());
    l.emplace_back(n);
    auto it = l.begin();
    s.begin()->second = l.begin();
    seguent(x,y,n);
    while (info.second and n <= TOPE)
    {
      info = s.emplace(n,l.begin());
      if (info.second)
      {
        l.emplace_back(n);
        ++it;
        info.first->second = it;
        seguent(x,y,n);
      } 
    }
    if (not info.second) cout << distance(info.first->second,l.end()) << endl;
    else cout << n << endl;
  }
}