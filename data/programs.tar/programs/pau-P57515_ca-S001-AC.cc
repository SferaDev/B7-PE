#include <iostream>
#include <math.h>
using namespace std;

int nombre_digits(int n){
  if (n >= 10) return 1 + nombre_digits(n/10);
  return 1; 
}

int nombdre (int x, int k) {
  int b = pow(10,k);
  return x%b;
}

int main () {
  int x;
  int k;
  while (cin >> x >> k) {
    int n = nombdre(x,k);
    int tot = 0;
    tot += n*(pow(10,nombre_digits(x) - k));
    int b = pow(10,k);
    tot += x/b;
    cout << tot << endl;
  }
}
