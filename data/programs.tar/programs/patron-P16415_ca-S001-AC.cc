#include <iostream>
using namespace std;
#include <vector>

int reines (int i, vector <int> & taulell, vector <bool> &mc, vector <bool> &md1, vector <bool> &md2);

bool legal (int i, vector <int> & taulell, vector <bool> &mc, vector <bool> &md1, vector <bool> &md2);

int main () {
  
  int n;
  cin >> n;
  vector <int> taulell (n,-1);
  vector <bool> mc (n, false);
  vector <bool> md1 (2*n-1, false);
  vector <bool> md2 (2*n-1, false);
  int resultat = reines(0,taulell,mc,md1,md2);
  cout << resultat << endl;
  
}

int reines (int i, vector <int> & taulell, vector <bool> &mc, vector <bool> &md1, vector <bool> &md2){

  if (i == taulell.size())return 1;
  else{
    int res = 0;
    for (int j = 0; j < taulell.size(); ++j){
      taulell[i]=j;
      if (legal(i,taulell,mc,md1,md2)){

	mc[j]=true;
	md1[taulell.size()-j+i] = true;
	md2[i+j] = true;
	res = res + reines(i+1,taulell,mc,md1,md2);
	mc[j]=false;
	md1[taulell.size()-j+i] = false;
	md2[i+j] = false;
      }
    }
    return res;
  }
  return 0;
  
}

bool legal (int i, vector <int> & taulell, vector <bool> &mc, vector <bool> &md1, vector <bool> &md2){
  int columna = taulell[i];
  if (mc[columna])return false;
  if (md1[taulell.size()-columna+i])return false;
  if (md2[i+columna])return false;
  return true;
  
}