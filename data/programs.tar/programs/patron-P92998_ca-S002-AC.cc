#include <iostream>
#include <string>

using namespace std;

void volta(int n)
{
    string s;
    cin >> s;
    if (n > 1) volta(--n);
    cout << s << endl;
}

int main()
{
    int n;
    cin>>n;
    if (n!=0) volta(n);

}
