#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <string>
#include <list>

using namespace std;

typedef vector<vector<int> > Graph;

void topological_sort(const Graph& adj,map<string, int>& M, vector<int>& d, vector<string>& str) {
  
  int n = (int)adj.size();
  priority_queue<string, vector<string>, greater<string> > Q;
  
  for (int i = 0; i < n; ++i) if (d[i] == 0) Q.push(str[i]);
  
  list<string> L;
  while (not Q.empty()) {
    int u = M[Q.top()]; Q.pop();
    L.push_back(str[u]);
    for (int j = 0; j < (int)adj[u].size(); ++j) if (--d[adj[u][j]] == 0) Q.push(str[adj[u][j]]);
  }
  
  if (L.size() == str.size()) {
    list<string>::iterator itl;
    for (itl = L.begin(); itl != L.end(); itl++) cout << *itl;
  } else cout << "NO VALID ORDERING";
  cout << endl;
}

int main() {
  int n;
  while (cin >> n) {
    map<string, int> M;
    vector<string> str(n);
    
    for (int i = 0; i < n; ++i) {
      cin >> str[i];
      M[str[i]] = i;
    }
    
	int m; cin >> m;
	
    Graph adj(n);
    vector<int> d(n, 0);
    
    for (int i = 0; i < m; ++i) {
      string s,t;
      cin >> s >> t;
      adj[M[s]].push_back(M[t]);
      ++d[M[t]];
    }
    topological_sort(adj,M,d,str);
  }
}