node_pila* copia_node_pila_it(node_pila* m) {
    if (m == NULL) return NULL;
    else {
        node_pila* it;
        node_pila* origin;
        it = origin = new node_pila;
        it->info = m->info;
        m = m->seguent;
        while(m != NULL) {
            it->seguent = new node_pila;
            it = it->seguent;
            it->info = m->info;
            m = m->seguent;
        }
        it->seguent = NULL;
        return origin;
    }
}

Pila& operator=(const Pila& original) {
    if (&original != this) {
        altura = original.altura;
        esborra_node_pila(primer_node);
        primer_node = copia_node_pila_it(original.primer_node);
    }
    return *this;
}
