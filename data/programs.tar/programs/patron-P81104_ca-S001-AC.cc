#include <iostream>
#include <vector>
using namespace std;
 
struct Assignatura {
    string nom;                 // Nom de l�assignatura
    double nota;                // Entre 0 i 10, -1 indica NP
};
 
struct Alumne {
    string nom;                 // Nom de l�alumne
    int dni;                    // DNI de l�alumne
    vector<Assignatura> ass;    // Llista d�assignatures de l�alumne
};
 
double nota(const vector<Alumne>& alums, int dni, string nom) {
        for (int i = 0; i < alums.size(); ++i) {
                if (alums[i].dni == dni) {
                        for (int j = 0; j < alums[i].ass.size(); ++j) {
                                if (alums[i].ass[j].nom == nom) {
                                        return alums[i].ass[j].nota;
                                }
                        }
                }
        }
        return -1;
}
 
double mitjana(const vector<Assignatura>& ass) {
    double mit = -1;
    int cont = 1;
    for (int i=0; i< ass.size(); ++i){
        if (ass[i].nota != -1) {
            if (mit !=- 1) {
                mit += ass[i].nota;
                ++cont;
            }
            else mit = ass[i].nota;
        }
    }
    return mit/cont;
}
 
void compta(const vector<Alumne>& alums, int dni, string nom, int& com) {
        com = 0;
        double nota_alumne = nota(alums,dni,nom);
        for (int i = 0; i < alums.size(); ++i) {
        if (mitjana(alums[i].ass) > nota_alumne) ++com;
        }
}
 
int main() {
        int n;
        cin >> n;
        vector<Alumne>alums(n);
        for (int i = 0; i < n; ++i) {
        cin >> alums[i].nom >> alums[i].dni;
        int n_ass;
        cin >> n_ass;
        alums[i].ass = vector<Assignatura>(n_ass);
        for (int j = 0; j < n_ass; ++j) {
            cin >> alums[i].ass[j].nom >> alums[i].ass[j].nota;
        }
    }
        int dni;
    string assig;
    while (cin >> dni >> assig) {
        int com;
        compta(alums,dni,assig,com);
        cout << com << endl;
    }
}
