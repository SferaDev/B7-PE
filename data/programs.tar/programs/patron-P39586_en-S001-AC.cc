#include <iostream>
#include <vector>
#include <queue>

#define infinit -1

using namespace std;

typedef pair<double, int> WArc; // weighted arc
typedef vector<vector<WArc>> WGraph; // weighted digraf

int dijkstra(const WGraph& G, int s, int x, vector <int> &p, vector <int> &ways){
	int n = G.size();
	vector<double> d(n, infinit); d[s] = 0;
	vector<bool> S(n, false);
	
	p = vector<int>(n, -1);
	ways = vector<int>(n, 0);
	ways[s] = 1;
	
	priority_queue<WArc, vector<WArc>, greater<WArc> > Q;
	Q.push(WArc(0, s));
	
	while (not Q.empty()){
		int u = Q.top().second; Q.pop();
		if (not S[u]){
			S[u] = true;
			for (WArc a : G[u]){
				int v = a.second;
				double c = a.first;
				if ((d[v] > d[u] + c) or d[v] == infinit)
				{
				ways[v] = ways[u];
				d[v] = d[u] + c;
				p[v] = u;
				Q.push(WArc(d[v], v));
				}
				else if (d[v] == d[u] + c) ways[v] += ways[u];
			}
		}
	}
	return d[x];
}


void read (WGraph& G){
	int m; cin >> m;
	for (int i = 0; i < m; ++i){
		int u,v;
		double c;
		cin >> u >> v >> c;
		G[u].push_back(make_pair(c,v));
	}
}


int main (){
	int n;
	while (cin >> n)
	{
	WGraph G(n);
	read(G);
	int x,y; cin >> x >> y;
	vector <int> p;
	vector <int> ways;
	int c = dijkstra(G, x, y, p, ways);
	if (c != -1) cout << "cost " << c << ", " << ways[y] << " way(s)" << endl;
	else cout << "no path from " << x << " to " << y << endl;
}
}
