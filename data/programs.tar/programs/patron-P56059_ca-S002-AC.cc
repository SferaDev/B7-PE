#include <iostream>
#include <string>
 
using namespace std;
 
int main() {
    int n;
    int suma_xula = 0;
    int xula_total = 0;
    int nombres = 0;
    while (cin >> n) {
        nombres = nombres + 1;
        suma_xula = 0;
        bool primer = true;
        int linea = 1;
        string palabra_aux;
        for (int i = 0; i < n; ++i) {
            string palabra;
            cin >> palabra;
            if (primer) {
                palabra_aux = palabra;
                primer = false;
            }
            if ((linea == n/2 + 1) or (linea == n)) {
                if (palabra_aux == palabra and n%2 != 0) ++suma_xula;
            }
            ++linea;
        }
        if (suma_xula == 2) ++xula_total;
    }
    if (nombres == xula_total) cout << "totes xules" << endl;
    else if (xula_total != 0) cout << "dels dos tipus" << endl;
    else cout << "cap de xula" << endl;
 
}
