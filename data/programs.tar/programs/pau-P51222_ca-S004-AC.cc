#include <iostream>
using namespace std;

int nombre_digits(int n){
   return (n >= 10)
        ? 1 + nombre_digits(n/10)
        : 1; 
}

int main () {
  int n;
  while (cin >> n) cout << nombre_digits(n) << endl;
}
