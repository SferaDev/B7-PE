#include <iostream>

using namespace std;

bool es_creixent (int n)
{
  if (n==0) return true;
  if (n/10%10>n%10) return false;
  return es_creixent(n/10);
}

int main ()
{
  int n;
  cin>>n;
  if(es_creixent(n)) cout<<"True"<<endl;
  else cout<<"False"<<endl;
}