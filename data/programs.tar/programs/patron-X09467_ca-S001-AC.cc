#include <iostream>
#include <vector>
using namespace std;
 
vector<bool>pos_rampas(const vector<int>& V) {
        vector<bool>pos(V.size(),false);
        for (int i = 0; i < V.size() - 2; ++i) {
                if (V[i] > V[i+1] and V[i+1] > V[i+2]) pos[i] = true;
                if (V[i] < V[i+1] and V[i+1] < V[i+2]) pos[i] = true;
        }
        return pos;
}
 
int pot_conflictives(const vector<bool>& B) {
        int suma = 0;
        for (int i = 0; i < B.size() - 2; ++i) {
                if (B[i] == true and B[i+1] == true) ++suma;
                if (B[i] == true and B[i+2] == true) ++suma;
        }
        return suma;
}
 
int main() {
        int n;
 
        while (cin >> n) {
                vector<int>v(n);
 
                for (int i = 0; i < n; ++i) cin >> v[i];
                cout << "posicions amb rampa:";
            vector<bool>pos = pos_rampas(v);
            for (int i = 0; i < pos.size(); ++i) {
                if (pos[i]) cout << " " << i;
            }
            cout << endl;
            cout << "potencialment conflictives: " << pot_conflictives(pos) << endl;
            cout << "---" << endl;
        }
}
