#include <iostream>
using namespace std;
 
int main(){
 
    cout.setf(ios::fixed);
    cout.precision(4);
 
    double n,seguent,min,max,sum, primer;
    int cont;
 
    cin >> n;
 
    for(int i = 0; i < n; ++i){
         cin >> cont;
         cin >> primer;
         min = max = sum = primer;
         for(int j = 1; j < cont; ++j){
             cin >> seguent;
             if(seguent > max) max = seguent;
             if(seguent < min) min = seguent;
             sum += seguent;
         }
         cout << min << ' ' << max << ' ' << sum / cont << endl;
    } 
}
