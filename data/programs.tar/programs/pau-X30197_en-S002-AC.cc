#include <iostream>
#include <vector>
using namespace std;

void leervect (vector<int>& A) {
  for (int i = 0; i < A.size(); ++i) {
    cin >> A[i];
  }
}

bool trobar (int x, const vector<int>& A, int esq, int dre) {
  if (esq > dre) return true;
  int pos = (esq + dre)/2;
  if (x < A[pos]) return trobar (x,A,esq,pos - 1);
  if (x > A[pos]) return trobar (x,A,pos + 1, dre);
  return false;
}

int numin (const vector<int>& A) {
  int tot = 0;
  for (int i = 0; i < A.size(); ++i) {
    int act = 0 - A[i];
    if (trobar(act,A,0,A.size() - 1)) ++tot;
  }
  return tot;
}

int main () {
  int n;
  cin >> n;
  vector <int> A(n);
  leervect(A);
  cout << numin(A) << endl; 
}
