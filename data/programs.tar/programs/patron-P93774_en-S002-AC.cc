#include <iostream>
#include <vector>

using namespace std;

int row, column;
typedef vector < vector <bool> > matrix;

long long int potencia (long long int x, int n){
	if (n == 0) return 1;
	else{
		long long int y = potencia (x, n / 2);
		if (n % 2 == 0) return y * y;
		return y * y * x;
	}
}

bool pos (long long int r, long long int c, int k, const matrix &p){

	if (k == 0) return true;
	if (k == 1) return p[r-1][c-1];
	long long int raux = r;
	long long int caux = c;
	long long int opr = potencia(row,k-1);
	long long int opc = potencia(column,k-1);
	
	if ((r + (r%opr))%opr == 0) r = (r + r%opr)/opr;
	else r = (r + (opr - r%opr))/opr;
	
	if ((c + (c%opc))%opc == 0) c = (c + c%opc)/opc;
	else c = (c + (opc - c%opc))/opc;
	
	if(p[r-1][c-1]){
		if (raux > opr) raux -= (r-1)*opr;
		if (caux > opc) caux -= (c-1)*opc;
		return pos (raux,caux,k-1,p);
	}
	return false;
}

void imprimeix (int k, const matrix &p){
	int n = potencia(row,k);
	int m = potencia(column,k);
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= m; ++j){
			if(pos(i,j,k,p)) cout << 'X';
			else cout << '.';
		}
		cout << endl;
	}
	cout << endl;
}


void read (matrix &m){
	for (int i = 0; i < m.size(); ++i){
		for (int j = 0; j < m[0].size(); ++j){
			char c; cin >> c;
			m[i][j] = c == 'X';
		}
	}
}


int main(){
	while (cin >> row >> column){
		matrix P(row, vector<bool> (column));
		read(P);
		int k; cin >> k;
		imprimeix(k,P);
		int q; cin >> q;
		for (int i = 0; i < q; ++i){
			int k;
			long long int r, c;
			cin >> k >> r >> c;
			cout << "after " << k << " step(s), (" << r << ", " << c << ')';
			if (pos(r,c,k,P)) cout << " is marked" << endl;
			else cout << " is empty" << endl;
		}
		cout << endl;
	}
}