#include <iostream>
#include <vector>
using namespace std;

void procesa(const vector<int> &A){
	bool first = true;
	for(int i = 0; i < A.size(); ++i){
		if (first) first = false;
		else cout << " ";
		cout << A[i];
	}
	cout << endl;
}

void binari(vector <int> &A, int m, int i, int z, int u){
	if (u > m or z > A.size()-m) return;
	if (i == A.size()) procesa (A);
	else {
		A[i] = 0; binari (A, m, i + 1, z + 1, u);
		A[i] = 1; binari (A, m, i + 1, z, u + 1);
	}
}

int main() {
	int n, m;
	cin >> n >> m;
	vector <int> A(n);
	binari(A, m, 0, 0, 0);
}