/* Pre: p.i. = C1, c = C2 */
/* Post: el p.i. passa a ser el resultat de trenar C1 i C2; c passa a ser buida */
void trenat(Cua &c)
{
  longitud += c.longitud;
  int i  = 1;
  node_cua* primer_aux = new node_cua;
  node_cua* c3 = primer_aux;
  while (primer_node != NULL and c.primer_node != NULL) {
    node_cua* aux = new node_cua;
    if (i % 2 == 0) {
      c3->info = c.primer_node->info;
      c.primer_node = c.primer_node->seguent;
    }
    else {
      c3->info = primer_node->info;
      primer_node = primer_node->seguent;
    }
    c3->seguent = aux;
    c3 = c3->seguent;
    ++i;
  }
  if (primer_node != NULL or c.primer_node != NULL) {
    while (primer_node != NULL) {
      node_cua* aux = new node_cua;
      c3->info = primer_node->info;
      primer_node = primer_node->seguent;
      c3->seguent = aux;
      c3 = c3->seguent;
    }
    while (c.primer_node != NULL) {
      node_cua* aux = new node_cua;
      c3->info = c.primer_node->info;
      c.primer_node = c.primer_node->seguent;
      c3->seguent = aux;
      c3 = c3->seguent;
    }
  }
  primer_node = copia_node_cua(primer_aux,ultim_node); 
}
