#include <iostream>
#include <stack>

using namespace std;

bool evaluar () {
  stack <char> p;
  char act; 
  cin >> act;
  bool correcte = true;
  while (act != '.') {
    if (correcte) {
      if (act == '(' or act == '[') p.push(act);
      else if (act == ')' ) {
        if (p.empty()) correcte = false;
        else if (p.top() == '[' or p.top() == ']') correcte = false;
        else p.pop();
      }
      else if (act == ']' ) {
        if (p.empty()) correcte = false;
        else if (p.top() == '(' or p.top() == ')') correcte = false;
        else p.pop();
      }
    }
    cin >> act;
  }
  return p.empty() and correcte;
}

int main () {
  if (evaluar()) cout << "Correcte" << endl;
  else cout << "Incorrecte" << endl;
}