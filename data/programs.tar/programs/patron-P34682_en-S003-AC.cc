#include <iostream>
#include <vector>

using namespace std;

int punt_fix(const int x,const vector<int>& v, int esquerra, int dreta)
{
  if(esquerra > dreta) return -1;
  else{
    int meitat = (esquerra+dreta)/2;
    if (v[meitat] + x == meitat+1 and (meitat == 0 or meitat != v[meitat-1] + x)) return meitat+1;
    if(v[meitat] + x < meitat+1) return punt_fix(x,v,meitat+1,dreta);
    else return punt_fix(x,v,esquerra,meitat-1);
  }
}

int punt_fix(const int x, const vector<int>& v)
{
  return punt_fix(x,v,0,v.size()-1);
}


int main()
{
  int n;
  int cont = 0;
  while(cin >> n){
    ++cont;
    vector<int> v(n);
    for(int i = 0; i < n; ++i){
      cin >> v[i];
    }
    int m;
    cin >> m;
    int a;
    cout << "Sequence #" << cont << endl;
    for(int j = 0; j < m; ++j){
      cin >> a;
      int puntfix = punt_fix(a,v);
      if(puntfix == -1) cout << "no fixed point for " << a << endl;
      else cout << "fixed point for " << a << ": " << puntfix << endl; 
    }
    cout << endl;
  }
}