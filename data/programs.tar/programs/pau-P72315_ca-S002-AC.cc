#include <iostream>
#include <math.h>
using namespace std;

int intercalacio(int x, int y) {
  return x*10 + y;
}

int nombre_digits(int n){
  if (n >= 10) return 1 + nombre_digits(n/10);
  return 1; 
}

int main () {
  int x;
  int y;
  while (cin >> x >> y) {
    int xif = nombre_digits(x);
    int tot = 0;
    for (int i = 1; i <= xif; ++i) {
      int b1 = x/(pow(10,xif - i));
      int b2 = y/(pow(10,xif - i));
      int x1 = b1%10;
      int y1 = b2%10;
      tot += intercalacio(x1,y1)*(pow(10,2*xif - 2*i));
    }
    cout << tot << endl;
  }
}
