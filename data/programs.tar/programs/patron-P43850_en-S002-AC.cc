#include <iostream>
 
using namespace std;
 
int main()
{
	int n;
	while(cin >> n){
		n /= 5;
		n -= 9;
		n /= 4;
		n -= 6;
		n /= 5;
		cout << n << endl;
	}
}
