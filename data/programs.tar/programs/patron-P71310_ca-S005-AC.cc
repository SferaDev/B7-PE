#include <iostream>
#include <vector>

using namespace std;

 double producte_escalar(const vector<double>& u, const vector<double>& v)
 {
 	double sumatorio=0;
 	for (int i=0; i<v.size(); ++i){
 		sumatorio+=v[i]*u[i];
	 }
	 return sumatorio;
 }
 
