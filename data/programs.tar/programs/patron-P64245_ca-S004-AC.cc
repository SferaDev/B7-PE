#include <iostream>
using namespace std;

bool es_capicua (int n, int b)
{
    int capb,capc,capd;
    capb=n;
    capd=0;
    capc=0;
    while (capb!=0){
        capc=capb%b;
        capd=capd*b+capc;
        capb=capb/b;
    }
    if (capd==n)
    return true;
    else
    return false;
}
