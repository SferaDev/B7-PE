#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool comp (int a, int b) {
    return a < b;
}

bool escala(vector<int> &v) {
    bool trobat = true;
    for (int i = 0; i < v.size(); ++i) {
    	if (v[i] != 1 and v[i] != 0) trobat = false;
    }
    return trobat;
}

bool poker(vector<int> &v) {
    bool trobat = false;
    for (int i = 0; i < v.size(); ++i) {
    	if (v[i] >= 4) trobat = true;
    }
    return trobat;
}
    	
bool full(vector<int> &v) {
    sort (v.begin(), v.end(), comp);
    bool trobat1, trobat;
    trobat1 = trobat = false;
    int i = 0;
    while (i < v.size() and not trobat) {
    	if (trobat1 and v[i] == 3) trobat = true;    	
	else if (v[i] == 2) trobat1 = true;
	
	++i;   
    }
    return trobat;
}

bool trio(vector<int> &v) {
    bool trobattres, trobat;
    trobattres = false;
    trobat = true;
    int i = 0;
    int x = 0;
    int y = 0;
    while (i < v.size()) {
    	if (v[i] == 1) ++x;
	if (v[i] == 0) ++y;
	if (v[i] == 3) trobattres = true;    	
        ++i; 
    }
    if (trobattres and x == 2 and y == 3) trobat = false;
    return trobat;
}

bool dparella(vector<int> &v) {
    bool trobatdos, trobat;
    trobatdos = trobat = false;
    int i = 0;
    while (i < v.size() and not trobat) {
    	if (trobatdos and v[i] == 2) trobat = true;
	if (v[i] == 2) trobatdos = true;    	
         
	++i; 
    }
    return trobat;
}	
	    
    
    
    

int main() {
    int k;
    vector<int> v(6, 0);
    bool Escala, Poker, Full, Trio, Dparella;
    cin >> k;
    int x;
    for (int j = 0; j < k; ++j) {
        
	for (int i = 0; i < 5; ++i) {
    	    cin >> x;
	    if (x == 1) ++v[0];
	    else if (x == 2) ++v[1];
	    else if (x == 3) ++v[2];
	    else if (x == 4) ++v[3];
	    else if (x == 5) ++v[4];
	    else ++v[5];
	   
	}
	
	
	
	     
	
	
	Escala = escala(v);
	Poker = poker(v);
	Full = full(v);
	Trio = trio(v);
	Dparella = dparella(v); 
	
	
	
	
	
	if (Escala) cout << "escala" <<endl;
	else if (Poker) cout << "poker" <<endl;
	else if (Full) cout << "full" <<endl;
	else if (not Trio) cout << "trio" <<endl;
	else if (Dparella) cout << "doble-parella" <<endl;
	else cout << "parella" <<endl;
	
	for (int s = 0; s < v.size(); ++s) {
	    v[s] = 0;
	}    	 
	}
}
