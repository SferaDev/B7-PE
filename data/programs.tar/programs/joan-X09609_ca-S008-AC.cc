static node_arbre* sub_arrel_recurs(node_arbre* n, const T& x, int &depth){
	node_arbre * t = NULL;
	if (n != NULL){
		if (n->info == x){
			t = copia_node_arbre(n);
		}
		else {
			int depthd = depth + 1;
			node_arbre * taux = sub_arrel_recurs(n->segD, x, depthd);
			int depthe = depth + 1;
			t = sub_arrel_recurs(n->segE, x, depthe);
			if (t == NULL){
				t = taux;
				depth += depthd;
			}
			else if (t != NULL and taux != NULL){
				if (depthd < depthe){
					t = taux;
					depth += depthd;
				}
			}
			else depth += depthe; 

		}
	}
	return t;
}

void sub_arrel(Arbre& asub, const T& x) /* Pre: p.i. = A, asub es buit */ /* Post: si A conte x, asub es el subarbre d'A resultat de la cerca;
    si A no conte x, asub es buit */
{
	int depth = 0;
	asub.primer_node = sub_arrel_recurs(primer_node, x, depth);
}