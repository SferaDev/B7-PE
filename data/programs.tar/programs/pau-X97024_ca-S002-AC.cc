#include <iostream>
using namespace std;

int nzeros_fact(int x) {
  if (x == 5) return 1;
  if (x/5 < 1) return 0;
  return x/5 + nzeros_fact(x/5);
}

int main () {
  int n;
  while (cin >> n) {
    cout << nzeros_fact(n) << endl;
  }
}
