#include <iostream>
using namespace std;



int main (){
    double n,a,l ;
    cin>>n;
    l=1;
    a=0;
    while (l<=n){
    a=(1/l)+a;
    l=l+1;}
    cout.setf(ios::fixed); 
    cout.precision(4);
    cout<<a<<endl;
    
    
 
}