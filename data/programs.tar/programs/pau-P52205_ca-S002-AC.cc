#include <iostream>
#include <vector>
using namespace std;

void fusionar (vector <double>& v, int e, int m, int d) {
  int n = d - e + 1;
  vector <double> aux(n);
  int i = e;
  int j = m + 1;
  int k = 0;
  while (i <= m and j <= d) {
    if (v[i] <= v[j]) {
      aux[k] = v[i];
      ++i;
    } else {
      aux[k] = v[j];
      ++j;
    }
    ++k;
  }
  while (i <= m) {
    aux[k] = v[i];
    ++k; ++i;
  }
  while (j <= d) {
    aux[k] = v[j];
    ++k; ++j;
  }
  for (k = 0; k < n; ++k) v[k + e] = aux[k];  
}

void ordena (vector<double>& v, int e, int d) {
  if (e < d) {
    int m = (e + d)/2;
    ordena (v,e,m);
    ordena (v,m+1,d);
    fusionar (v,e,m,d);
  }
}

void ordena_per_fusio(vector<double>& v) {
  ordena (v,0,v.size()-1);
}

int main () {

}       
