#include <iostream>
#include <list>
using namespace std;

void seleccio(const list<double>& l, list<double>& sel){ 
 /* Pre: l no es buida, sol es buida */ 
 /* Post: sel es el resultat de treure d'l els elements febles en mitjana */
    list<double>::const_iterator it = l.begin();
    list<double>::iterator it2 = sel.begin();
    double suma = *it;
    sel.insert(it2, suma);
    ++it;
    int nombres = 1;
    while (it != l.end()){
        if (suma / nombres <= *it) {
            double como = *it;
            sel.insert(it2, como);
        }
        suma += *it;
        ++it;
        ++nombres;
    }
}