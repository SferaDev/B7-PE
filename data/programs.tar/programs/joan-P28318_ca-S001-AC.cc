#include <iostream>
#include <vector>
#include <string>
using namespace std;
typedef vector <int> Fila;
typedef vector <Fila> Matriu;

int main(){
  int numf,numc;
  cin>>numf>>numc;
  Matriu mat (numf,Fila(numc));
  for (int i=0;i<mat.size();++i){
    for (int j=0; j<mat[0].size();++j){
      cin>>mat[i][j];
    }
  }
  string paraula;
  while (cin>>paraula){
    if (paraula=="fila"){
      int fila;
      cin>>fila;
      cout<<"fila "<<fila<<":";
      for (int j=0;j<numc;++j){
	cout<<" "<<mat[fila-1][j];
      }
      cout<<endl;
    }
    if (paraula=="columna"){
      int columna;
      cin>>columna;
      cout<<"columna "<<columna<<":";
      for (int i=0;i<mat.size();++i){
	cout<<" "<<mat[i][columna-1];
      }
      cout<<endl;
    }
    if (paraula=="element"){
      int x,y;
      cin>>x>>y;
      cout<<"element "<<x<<" "<<y<<": "<<mat[x-1][y-1]<<endl;
    }
  }
}



