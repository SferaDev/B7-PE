#include <iostream>
#include <math.h>
using namespace std;

int nombre_digits(int n, int b){
  int i = 0;    
  while ((n - pow(b,i)) >= 0) ++i;
  return i;    
}

int minbase(int n, int b) { 
  int x = n%b;              
  if (x > b) return minbase(x,b);
  return x;
}

int sumxif(int n, int b) {
  if (n < b) return minbase(n,b);
  return minbase(n,b) + sumxif(n/b,b);
}

bool rodo (int n, int b) {
  int xif = nombre_digits(n,b);
  int sum = sumxif(n,b);
  if (xif == sum) return true;
  return false; 
}

int main () {
  int n;
  int b;
  bool primer = false;
  bool segon = false;
  bool trobat = false;
  while (not trobat and cin >> n >> b) {
    if (primer and rodo(n,b)) segon = true;
    if (not primer and rodo(n,b)) primer = true;
    if (primer and segon) trobat = true;
  }
  if (trobat) cout << "SI" << endl;
  else cout << "NO" << endl;
}
