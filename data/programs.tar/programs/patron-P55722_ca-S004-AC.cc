#include <iostream>
#include <string>

using namespace std;

int nombre_digits(int n)
{
  int suma = 1;
  while(n > 9){
    ++suma;
    n /= 10;
  }
  return suma;
}

int main()
{
  int n;
  while(cin >> n){
    int digits = nombre_digits(n);
    cout << digits << endl;
  }
}
