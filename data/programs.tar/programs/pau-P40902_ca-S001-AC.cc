#include <iostream>
#include <map>

using namespace std;

int main ()
{
  map <string, int> cas;
  string nom;
  while (cin >> nom)
  {
    string op; cin >> op;
    auto it = cas.find(nom);
    if (op == "enters")
    {
      if (it != cas.end()) cout << nom << " is already in the casino" << endl;
      else cas.insert(pair<string,int>(nom,0));
    }
    else if (op == "leaves")
    {
      if (it == cas.end()) cout << nom << " is not in the casino" << endl;
      else
      {
        cout << nom << " has won " << it->second << endl;
        cas.erase(it);
      }
    }
    else
    {
      int x; cin >> x;
      if (it == cas.end()) cout << nom << " is not in the casino" << endl;
      else it->second += x;
    }
  }
  cout << "----------" << endl;
  for (auto it = cas.begin(); it != cas.end(); ++it) cout << it->first << " is winning " << it->second << endl;
}