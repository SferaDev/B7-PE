#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  int a1,b1,a2,b2;
  cin>>a1>>b1>>a2>>b2;
  int a=max (a1,a2);
  int b=min (b1,b2);
  
  if (a>b) cout<<"[]"<<endl;
  else cout<<"["<<a<<","<<b<<"]"<<endl;

}
