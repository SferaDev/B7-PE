#include <iostream>
#include<string>
using namespace std;

int main (){
    string c;
    int count=0;
    while (cin>>c) {
        if (c=="hola") count=count+1;
    }
    cout<<count<<endl;
}