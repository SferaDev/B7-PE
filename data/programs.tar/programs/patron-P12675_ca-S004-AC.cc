#include <iostream>
#include <vector>

using namespace std;

int elements_comuns (const vector<int>& X, const vector<int>& Y)
{
 
  int cont=0,i=0,k=0;
  while (i<X.size() and k<Y.size() ){
    
    if (X[i]<Y[k])++i;
    else if(X[i] > Y[k]) ++k;
    else {
      ++i;
      ++k;
      ++cont;
    }
  }
  return cont;
}
