#include <iostream>

using namespace std;

int dif(int x, int y)
{
  return (x-y);
}

int main ()
{
  int a,b;
  cin >> a >> b;
  cout << dif(a,b) << endl;
}