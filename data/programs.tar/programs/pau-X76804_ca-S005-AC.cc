#include <iostream>
#include <vector>
using namespace std;

struct Info {
  char contingut;             // Mur (’X’), buit (’.’) o deixalles (dígit)
  int  energia;               // Aportacio d’energia solar de la casella
};

typedef  vector< vector<Info> >  Camp;

void llegeix_contingut (Camp& C) {
  int n = C.size();
  int m = C[0].size();
  string act;
  for (int i = 0; i < n; ++i) {
    cin >> act;
    for (int j = 0; j < m; ++j) {
      C[i][j].contingut = act[j];
    }
  }
}

void llegeix_energia (Camp& C) {
  int n = C.size();
  int m = C[0].size();
  string act;
  for (int i = 0; i < n; ++i) {
    cin >> act;
    for (int j = 0; j < m; ++j) {
      C[i][j].energia = act[j] - '0';
    }
  }
}

void calcula_pos (const Camp& C, int& i, int& j, int& k, string mov) {
  int l = mov.size();
  bool trobat = false;
  while (not trobat and k < l) {
    if (mov[k] == 'N') {
      if (C[i-1][j].contingut != 'X') {
        --i;
        trobat = true;
      }
      else ++k;
    }
    else if (mov[k] == 'S') {
      if (C[i+1][j].contingut != 'X') {
        ++i;
        trobat = true;
      }
      else ++k;
    }
    else if (mov[k] == 'E') {
      if (C[i][j+1].contingut != 'X') {
        ++j;
        trobat = true;
      }
      else ++k;
    }
    else if (mov[k] == 'O') {
      if (C[i][j-1].contingut != 'X') {
        --j;
        trobat = true;
      }
      else ++k;
    }
  }
}

void Walle (Camp& C,int& i, int& j, int& energia, string mov,int& esc) {
  int k = 0;
  int l = mov.size();
  while (energia > 0 and k < l) {
    if (C[i][j].contingut != '.') {
      esc += C[i][j].contingut - '0';
      C[i][j].contingut = '.';
      --energia; 
    }
    if (C[i][j].energia > 0) {
      energia += C[i][j].energia;
      C[i][j].energia = 0;
    }
    if (energia > 0) calcula_pos (C,i,j,k,mov);
  }
}

int main () {
  int n,m;
  cin >> n >> m;
  Camp C (n, vector<Info> (m));
  llegeix_contingut (C);
  llegeix_energia (C);
  int i,j;
  cin >> i >> j;
  int energia; cin >> energia;
  string mov; cin >> mov;
  int esc = 0;
  Walle (C,i,j,energia,mov,esc);
  cout << "escombraries: " << esc << endl;
  cout << "energia: " << energia << endl;
  cout << "posicio: (" << i << ',' << j << ')' << endl;      
}       
