#include <iostream>
#include <vector>
using namespace std;

typedef vector <char> Fila;
typedef vector <Fila> Matriu;

void llegeix (Matriu& A) {
  int n = A.size();
  int m = A[0].size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) cin >> A[i][j];
  }
}

bool interior (const Matriu& M, int i, int j) {
  int n = M.size() - 1;
  int m = M[0].size() - 1;
  if (i == 0 or i == n) return false;
  if (j == 0 or j == m) return false;
  return true;  
}

void instant (const Matriu& M, Matriu& B) {
  int n = M.size();
  int m = M[0].size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      int cont = 0;
      for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {
          int Y = i + dy;
          int X = j + dx;
          if (Y >= 0 and X >= 0 and Y < n and X < m and M[Y][X] == 'B')
          ++cont;
        }
      }
      if (M[i][j] == 'B' and (cont != 3 and cont != 4)) B[i][j] = '.';
      else if (M[i][j] == '.' and cont == 3) B[i][j] = 'B';
    } 
  }  
}

void imprimeix (const Matriu& A) {
  int n = A.size();
  int m = A[0].size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) cout << A[i][j];
    cout << endl;
  }
}

int main () {
  int n,m; cin >> n >> m;
  bool primer = true;
  while (n != 0 and m != 0) {
    Matriu A(n, Fila(m));
    Matriu B(n, Fila(m));
    llegeix (A);
    B = A;
    if (primer) primer = false;
    else cout << endl;
    instant (A,B);
    imprimeix(B);
    cin >> n >> m;
  }
}      
