#include <stack>
#include "Arbre.hh"

using namespace std;

int nfills(Arbre <int> &a) 
{
  if (a.es_buit()) return 0;
  else {
    int x = a.arrel();
    Arbre <int> e;
    Arbre <int> d;
    a.fills(e,d);
    int tot = 1 + nfills(e) + nfills(d);
    a.plantar(x,e,d);
    return tot;
  } 
}

/* Pre: a=A, c es buida */
/* Post: c conte el cami preferent d'A; si no es buit, el primer element
del cami es al cim de c */
void cami_preferent(Arbre<int> &a, stack<int> &c) 
{
 if (not a.es_buit()) {
   int x = a.arrel();
   Arbre <int> e;
   Arbre <int> d;
   a.fills(e,d);
   int nfe = nfills(e);
   int nfd = nfills(d);
   if(nfe >= nfd) cami_preferent(e,c);
   else cami_preferent(d,c);
   c.push(x);
 } 
}
