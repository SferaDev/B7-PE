#include <iostream>

using namespace std;

double m,f,r;

double potencia (double x, int n) 
{
  if (n == 0) return 1;
  else 
  {
    double y = potencia (x, n / 2);
    if (n % 2 == 0) return y * y;
    else return y * y * x;
  }
}

int chapuza (int e, int d)
{
  if (e > d) return -1;
  if (e == d) 
  {
    if (potencia(1 + r/100,e)*m > e*f + m) return e;
    return -1;
  }
  int mi = (e+d)/2;
  if (potencia(1 + r/100,mi)*m <= mi*f + m) return chapuza (mi+1,d);
  return chapuza(e,mi);
}

int main ()
{
  while (cin >> m >> f >> r) cout << chapuza(1,10000000) << endl;
}
