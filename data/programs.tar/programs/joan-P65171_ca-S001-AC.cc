#include <iostream>
using namespace std;

int main(){
    cout.setf(ios::fixed); 
    cout.precision(2);
    int n;
    cin>>n;
    double x;
    double elevat=0;
    double suma=0;
    for (int i=0;i<n;++i){
        cin>>x;
        elevat=elevat+x*x;
        suma=suma+x;
    }cout<<(elevat/(n-1))-((suma*suma)/(n*n-n))<<endl;
}