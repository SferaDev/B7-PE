#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b)
{
  b = false;
  int right = nest - 1;
  int left = 0;
  int j;
  while (left <= right and not b){
    j = (right + left)/2;
    if (est.consultar_DNI() < vest[j].consultar_DNI()) right = j - 1;
    else if (est.consultar_DNI() > vest[j].consultar_DNI()) left = j + 1;
    else b = true;
    
}
  if (not b) {
     //afegir estudiant
    for (int i = nest - 1; i >= left; --i){
      vest[i + 1]=vest[i];
    }
    vest[left]=est;
    ++nest;
    recalcular_posicio_imax();
  }
}

void Cjt_estudiants::eliminar_estudiants_sense_nota()
{
    int i = 0;
    while (i < nest){
        if (vest[i].te_nota()) ++i;
        else {
            if (i == nest - 1) --nest;
            else {for (int j = i; j < nest - 1; ++j){
                vest[j] = vest [j+1];
            }
            --nest;}
        }
    }
    recalcular_posicio_imax();
}