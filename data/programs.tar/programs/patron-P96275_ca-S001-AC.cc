#include <iostream>
using namespace std;

int absolute(int n)
{
	if(n > 0) return n;
	else return n*-1;
}
