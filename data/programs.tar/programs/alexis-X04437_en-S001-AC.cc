#include <iostream>
#include <cmath>
using namespace std;

/* SPEC
 * 
 * in: The input is formed by two reals
 * 
 * out: You only need to submit the
 * required procedure; your main program will be ignored. 
 * 
 */

double dist_or(double x, double y) {
    // Pow the variables
    x = pow(x, 2);
    y = pow(y, 2);
    
    // Return the square root
    return sqrt(x + y);
}

int main() {
    // Read the doubles
    double x, y;
    cin >> x >> y;
    
    // Print the function result
    cout << dist_or(x, y) << endl;
}