#include <iostream>
#include <vector>
#include "Estudiant.hh"
using namespace std;

void seleccionades(vector<bool>& s,int S)
{
  int j, cont=0;
  while(cont < S and cin >> j)
  {
    s[j-1] = true;;
    ++cont;
  }
}

void calcul_mitjanes(int M, int N,int S, vector<bool> &s)
{
  for(int i=0;i<M;++i)
  {
    double suma_notes=0;
    int dni;
    cin >> dni;
    Estudiant est(dni);
    
    for(int j=0;j<N;++j)
    {
      double nota;
      cin >> nota;
      if(s[j])
      {
	suma_notes+=nota;
      }
    }
    
    est.afegir_nota(suma_notes/S);
    est.escriure();
  }
}

int main()
{
  int M; //nombre estudiants
  cin >> M;
  int N; //nombre assginatures
  cin >> N;
  int S; //nombre d'assignatures seleccionades
  cin >> S;
  vector <bool> s(N,false); //Vector amb les assignatures seleccionades
  seleccionades(s,S);
  calcul_mitjanes(M,N,S,s);
}