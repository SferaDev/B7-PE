#include <iostream>
using namespace std;

void infoSequencia(int& max, int& lpos){
  int act;
  int cont = 1;
  lpos = 1;
  cin >> act;
  if (act == 0) {
    max = 0;
    lpos = 0;
  }
  else max = act;
  while (act != 0) {
    if (act >= max) {
      max = act;
      lpos = cont;
    }
    ++cont;
    cin >> act;
  }
}

void infoSequencia2(int max, int& lpos, bool& trobat){
  int act;
  int cont = 1;
  lpos = 1;
  cin >> act;
  while (not trobat and act !=  0) {
    if (act == max) {
      lpos = cont;
      trobat = true;
    }
    ++cont;
    cin >> act;
  }
}


int main () {
  int maxsec;
  int pos1, pos2;
  bool trobat = false;
  infoSequencia(maxsec,pos1);
  infoSequencia2(maxsec,pos2,trobat);
  if (trobat) {
    cout << maxsec << ' ' << pos1 << ' ' << pos2 << endl;
  }
  else cout << maxsec << ' ' << pos1 << " -" << endl;
}
