#include <iostream>
#include <vector>
using namespace std;

void leer(vector<int> &v){
  int n = v.size();
  for(int i=0;i<n;++i){
    cin >> v[i];
  }
}

int main()
{
  int n;
  cin >> n;
  vector<int> v(n);
  leer(v);
  int principi = 0, fin = n-1;
  int no_apareix = 0;
  while(principi < fin){
    if(-v[principi] == v[fin]){
      --fin;
      ++principi;
    }
    else if(-v[principi] < v[fin]){
      --fin;
      ++no_apareix;
    }
    else{
      ++principi;
      ++no_apareix;
    }
  }
  if(principi == fin and v[principi] != 0) ++no_apareix;
  cout << no_apareix << endl;
}