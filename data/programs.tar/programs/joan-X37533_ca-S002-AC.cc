

#include "Arbre.hh"
 
void calcula_arbre(Arbre<int> &a, Arbre<int> &agd, int &h) {
/* Pre: a=A */
/* Post: agd es un arbre amb la mateixa estructura que A on cada
   node conte el grau de desequilibri del subarbre d'A corresponent;
   h conte l'altura d'A */
 
        if (a.es_buit()) h = 0;
        else {
                Arbre <int> a1, a2, agd1, agd2;
                int h1, h2;
                a.fills(a1,a2);
                calcula_arbre(a1,agd1,h1);
                calcula_arbre(a2,agd2,h2);
                h = 1 + max(h1,h2);
                int x = h1-h2;
                agd.plantar(x,agd1,agd2);
        }
}
void arbre_graus_desequilibri(Arbre<int> &a, Arbre<int> &agd) {
/* Pre: a=A */
/* Post: agd es un arbre amb la mateixa estructura que A on cada
   node conte el grau de desequilibri del subarbre d'A corresponent */
       
        int h;
        calcula_arbre(a,agd,h);
}