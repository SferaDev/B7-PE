#include <iostream>

using namespace std;

bool is_odd_even_increasing()
{
  int x1,x2;
  cin >> x1 >> x2;
  int x3;
  while(cin >> x3){
    if (x3<x1) return false;
    x1=x2;
    x2=x3;
  }
  return true;
}

int main()
{
  if(is_odd_even_increasing()) cout << "yes" << endl;
  else cout << "no" << endl;
  
}