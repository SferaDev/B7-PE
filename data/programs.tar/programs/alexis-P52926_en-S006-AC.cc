#include <iostream>
using namespace std;

void printNamesReverse(string input) {
    if (input != "end") {
        string next;
        cin >> next;
        printNamesReverse(next);
        cout << input << endl;
    }
}

int main() {
    string input;
    cin >> input;
    printNamesReverse(input);
}