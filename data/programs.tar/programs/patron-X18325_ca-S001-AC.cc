#include<iostream>
using namespace std;

int main() {
	int l, r;
	int x;
	cin >> l >> r;
	int sum = 0;
	int count = 0;
	while (cin >> x) {
		if (x >= l and x <= r) sum = sum + x;
		else ++count;
	}
	cout << "Sum Inside: " << sum << endl;
	cout << "Num Outside: " << count << endl;
}
