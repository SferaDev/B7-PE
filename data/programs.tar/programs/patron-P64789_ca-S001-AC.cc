#include <iostream>
#include <vector>
using namespace std;
typedef vector<vector<int> > Matriu;
 
int suma_diagonals(const Matriu& mat){
    int n = mat.size();
    int sum = 0;
    for( int i = 0; i < n; ++i){
         for(int j = 0; j < n; ++j){
                 if( i == j) sum += mat[i][j];
                 else if( i + j == n - 1) sum += mat[i][j];
                 }
         }
         return sum;
}
 
 
 
int main(){
    int n;
    while( cin >> n){
           Matriu mat(n, vector<int>(n));
           for( int i = 0; i < n; ++i){
                for(int j = 0; j < n; ++j){
                        cin >> mat[i][j];
                        }
                }
                cout << suma_diagonals(mat) << endl;
           }
}
