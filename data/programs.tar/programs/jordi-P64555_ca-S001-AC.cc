#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

struct Punt_dist {
  int dist, x, y;
};

bool comp( Punt_dist a, Punt_dist b) {
  if ( a.dist == b.dist and a.x == b.x) return a.y < b.y;
  else if ( a.dist == b.dist) return a.x < b.x;
  else return a.dist <= b.dist;
}

int main () {
  int x0, y0, n;
  cin >> x0 >> y0 >> n;
  if ( n!= 0) {
    vector<Punt_dist> vpd(n);
    for ( int i = 0; i<n; ++i) {
      cin >> vpd[i].x >> vpd[i].y;
      vpd[i].dist = (abs(vpd[i].x-x0)) + (abs(vpd[i].y-y0));
      
    }
    sort(vpd.begin(),vpd.end(), comp);
    int distact= vpd[0].dist;
    cout << "punts a distancia " << distact << endl;
    cout << vpd[0].x << " " << vpd[0].y << endl;
    for ( int i = 1; i < n; ++i) {
      if ( vpd[i].dist > distact) {
	distact = vpd[i].dist;
	cout << "punts a distancia " << distact << endl;
      }
      cout << vpd[i].x << " " << vpd[i].y << endl;
    }
  }
}