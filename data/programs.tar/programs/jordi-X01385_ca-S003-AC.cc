#include <iostream>
#include <vector>

using namespace std;

bool esta(int el, const vector<int>& v) {
  bool b = false;
  int pos = 0;
  int cont = v.size();
  while (pos < cont and not b ) {
    if ( v[pos] == el) b = true;
    else ++pos;
  }
  return b;
}

int main () {
  int n;
  while ( cin >> n) {
    vector<int> v(0);
    for ( int i = 0; i < n; ++i) {
      int el;
      cin >> el;
      if ( not esta(el, v)) {
	v.push_back(el);
      }
    }
    cout << v.size() << endl;
  }
}