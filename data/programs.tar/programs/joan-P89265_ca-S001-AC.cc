#include <iostream>
using namespace std;

int main (){
  int a,b,c,d;
  cin>>a>>b>>c>>d;

  if (a==c and b==d)cout<<"="<<" , ";
  else if (c<a and d>=b) cout<<"1"<<" , ";
  else if (a<c and b>=d) cout<<"2"<<" , ";
  else if (c<=a and d>b) cout<<"1"<<" , ";
  else if (a<=c and b>d) cout<<"2"<<" , ";
  else cout<<"?"<<" , ";
  
   if (a<c and b<c) cout<<"[]"<<endl;
    else if (d<a and c<a) cout<<"[]"<<endl;
    else if (a<c){
	if (b>=d) cout<<"["<<c<<","<<d<<"]"<<endl;
        else cout<<"["<<c<<","<<b<<"]"<<endl; 
    }else if (a>=c){
        if (b>=d) cout<<"["<<a<<","<<d<<"]"<<endl;
	else cout<<"["<<a<<","<<b<<"]"<<endl;
        
    }
}