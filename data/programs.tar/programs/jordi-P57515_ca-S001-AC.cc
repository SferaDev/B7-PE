#include <iostream>
#include <cmath>
using namespace std;

int rotacio_dreta(int x, int k){
  int y,z;
  z=1;
  if (k>0){
    while (k>0){
      --k;
      z= 10*z;
    }
    y=x%z;
    x=x/z;
    cout << y;
  }
  cout << x << endl;
}
    
int main (){
  int x, k;
  while (cin >> x >> k){
    rotacio_dreta(x, k);
  }
}
  