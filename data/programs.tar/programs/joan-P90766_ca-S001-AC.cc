#include <iostream>
#include <vector>
using namespace std;
int n, m;

int dfs_rec (const vector <vector<char> >& G, int fi, int col,  vector <vector<bool> >& vis) {
    if (not vis[fi][col]) {
        int count = 0;
        vis[fi][col] = true;
        if (G[fi][col]=='X') return 0;
        else {
            if (G[fi][col]=='t') ++count;
            if (fi - 1 >= 0 )  count += dfs_rec(G, fi - 1, col, vis); //amunt
            if (fi + 1 < G.size() )  count += dfs_rec(G, fi + 1, col, vis);//avall
            if (col + 1 < G[0].size())  count +=dfs_rec(G, fi , col + 1, vis);//dreta
            if (col - 1 >= 0)  count += dfs_rec(G, fi , col - 1, vis);//esquerra
        }
        return count;
    }
    return 0;
}

int dfs_rec1 (const vector <vector<char> >& G, int fi, int col) {
    vector <vector<bool> > vis(n , vector<bool>(m, false));
    return dfs_rec(G, fi, col, vis);
}


int main (){
    
    cin >> n >> m;
    vector <vector<char> > v(n , vector<char>(m));
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < m; ++j){
            cin >> v[i][j];
        }
    }
    int f, c;
    cin >> f >> c;
    cout << dfs_rec1(v, f-1, c-1) << endl;
    
}