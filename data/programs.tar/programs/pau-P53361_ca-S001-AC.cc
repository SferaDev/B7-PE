#include <iostream>
using namespace std;

struct Racional {
  int num, den;
};

int mcd(int a , int b ) {
  if (a == b) return a;
  if (a == 0) return b;
  if (b == 0) return a;
  if (a%b == 0) return b;
  return mcd(b, a%b);
}

Racional normalitza(int n, int d) {
  Racional res;
  if (d < 0) {
    d = d*(-1);
    n = n*(-1);
  }
  int naux = n; 
  if (naux < 0) naux = 0 - naux;
  int c = mcd(naux,d);
  if (n == 0) {
    res.num = 0;
    res.den = 1;
  } else if (c == 1) {
    res.num = n;
    res.den = d;
  } else {
    res.num = n/c;
    res.den = d/c;
  }
  return res;         
}

void suma_un(Racional& r) {
  r.num = r.num + r.den;
  r = normalitza(r.num,r.den);
}

Racional suma(const Racional& a, const Racional& b) {
  Racional res;
  if (a.den == b.den) {
    res.num = a.num + b.num;
    res.den = a.den;
  } else {
    if (a.den%b.den == 0) {
      if (a.den > b.den) {
        res.num = a.num + b.num*(a.den/b.den);
        res.den = a.den;
      } else {
        res.num = b.num + a.num*(b.den/a.den);
        res.den = b.den;
      }
    } else {
      res.num = a.num*b.den + b.num*a.den;
      res.den = a.den*b.den;
    }
  }
  return normalitza(res.num,res.den);
}

Racional resta(const Racional& a, const Racional& b) {
  Racional res;
  if (a.den == b.den) {
    res.num = a.num - b.num;
    res.den = a.den;
  } else {
    if (a.den%b.den == 0) {
      if (a.den > b.den) {
        res.num = a.num - b.num*(a.den/b.den);
        res.den = a.den;
      } else {
        res.num = b.num - a.num*(b.den/a.den);
        res.den = b.den;
      }
    } else {
      res.num = a.num*b.den - b.num*a.den;
      res.den = a.den*b.den;
    }
  }
  return normalitza(res.num,res.den);
}

Racional producte(const Racional& a, const Racional& b) {
  Racional res;
  res.num = a.num*b.num;
  res.den = a.den*b.den;
  return normalitza(res.num,res.den);
}

Racional divisio(const Racional& a, const Racional& b) {
  Racional res;
  res.num = a.num*b.den;
  res.den = a.den*b.num;
  return normalitza(res.num,res.den);
}

void llegeix_racional(Racional& r) {
  cin >> r.num >> r.den;
  r = normalitza(r.num, r.den);
}

void escriu_racional(const Racional& r) {
  if (r.den != 1) cout << r.num << '/' << r.den << endl;
  else cout << r.num << endl;
}

int main () {
  Racional r1,r2,res;
  llegeix_racional(r1);
  char c;
  cin >> c;
  llegeix_racional(r2);
  if (c == '+') res = suma(r1,r2);
  if (c == '-') res = resta(r1,r2);
  if (c == 'x') res = producte(r1,r2);
  if (c == '/') res = divisio(r1,r2);
  if (c == '$') {
    suma_un(r1);
    res = r1;
  }
  escriu_racional(res);  
}
