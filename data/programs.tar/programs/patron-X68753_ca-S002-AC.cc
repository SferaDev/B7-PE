#include<iostream>
#include <vector>

using namespace std;

int main(){
  int n;
  while (cin >> n) {
    
    vector<int> e(n);
    vector<int> e_s_r(n);
    int g = 0;
    
    for (int i = 0; i < n; ++i) {
      cin >> e[i];
      bool repite = false;
      int m = 0;
      
      while (not repite and m < i) {
	if (e[i] == e_s_r[m]) repite = true;
	++m;
      }
      if (not repite) {
	e_s_r[g] = e[i];
        ++g;
      }  
    }
    
    vector<int> rep(g);
    int max_rep = 0;
    for (int i = 0; i < g; ++i) {
      int aux = 0;
      for (int k = 0; k < n; ++k) {
	if (e_s_r[i] == e[k]) ++aux;
      }
      rep[i] = aux;
      if (aux > max_rep) max_rep = aux;
     }
     int mas_grande_con_max_rep = 0;
     for (int i = 0; i < g; ++i) {
       if (rep[i] == max_rep and e_s_r[i] > mas_grande_con_max_rep) mas_grande_con_max_rep = e_s_r[i];
    }
    cout << mas_grande_con_max_rep << endl;
  }
}