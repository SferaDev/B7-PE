#include <iostream>
#include <stack>
using namespace std;

bool validar() {
  char c;
  int npar = 0, nclau = 0;
  bool hiha_par = false, hiha_clau = false;
  while (cin >> c and c != '.') {
      if (npar < 0 or nclau < 0) return false;
      if (c == '(') {
        hiha_par = true;
	++npar;
	hiha_clau = false;
      } else if (c == '[') {
	hiha_clau = true;
	++nclau;
	hiha_par = false;
      } else if (c == ')') {
	if (hiha_clau) return false;
        --npar;
	hiha_par = false;
      } else {
	if (hiha_par) return false;
        --nclau;
	hiha_clau = false;
      }
  }
  return true;
}

int main() {
  bool valid = validar();
  if (valid) cout << "Correcte";
  else cout << "Incorrecte";
  cout << endl;
}

