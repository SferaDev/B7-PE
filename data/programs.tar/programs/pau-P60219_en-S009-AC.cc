#include <iostream>
#include <map>
#include <algorithm>
#include <vector>

using namespace std;

bool sort_q_tinc (const string &a, const string &b)
{
  if (a.size() == b.size()) return a < b;
  return a.size() < b.size();
}

void new_game(map<string,bool> &g, string &op)
{
  cin >> op;
  while (op != "END" and op != "QUIT")
  {
    auto info = g.emplace(op,true);
    if (not info.second) info.first->second = not info.first->second;
    cin >> op;
  }
}

void score (map <string,bool> &g, int cont)
{
  vector <string> v;
  cout << "GAME #" << cont+1 << endl;
  cout << "HAS:" << endl;
  for (auto it = g.begin(); it != g.end(); ++it)
  {
    if (it->second) cout << it->first << endl;
    else v.push_back(it->first);
  }
  cout << endl;
  sort(v.begin(),v.end(),sort_q_tinc);
  cout << "HAD:" << endl;
  for (int i = 0; i < v.size(); ++i) cout << v[i] << endl;
}

int main ()
{
  vector<map<string,bool>> reg;
  bool quit = false;
  string op;
  while (not quit)
  {
    map<string,bool> g;
    new_game(g,op);
    reg.push_back(g);
    quit = op == "QUIT";
  }
  bool primer = true;
  for (int i = 0; i < reg.size(); ++i)
  {
    if (primer) primer = false;
    else cout << endl;
    score(reg[i],i);
  }
}