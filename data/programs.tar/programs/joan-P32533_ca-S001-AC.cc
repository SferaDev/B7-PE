#include <iostream>
using namespace std;

int main (){
    int n;
    cin >> n;
    //Fem un bucle que llegeixi a quina línia ens trobem per després poder restar o sumar "x","/" o "*" a
    //les corresponents línies.
    for (int lin = 1;lin <= n; ++lin) {
    for (int suma = 1;suma <= n - lin; ++suma) {
    cout << "+";
    }for (int div = 0;div<=0;++div) {
    cout << "/";
    }for (int multi = 0; multi < lin - 1; ++multi) {
    cout << "*";
    }
    cout << endl;
 
}

}