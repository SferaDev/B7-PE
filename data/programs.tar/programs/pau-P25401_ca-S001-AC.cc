#include <iostream>
#include <vector>
using namespace std;

void fusionar (vector <int>& v, int e, int m, int d) {
  int n = d - e + 1;
  vector <int> aux(n);
  int i = e;
  int j = m + 1;
  int k = 0;
  while (i <= m and j <= d) {
    if (v[i] <= v[j]) {
      aux[k] = v[i];
      ++i;
    } else {
      aux[k] = v[j];
      ++j;
    }
    ++k;
  }
  while (i <= m) {
    aux[k] = v[i];
    ++i; ++k;
  }
  while (j <= d) {
    aux[k] = v[j];
    ++k; ++j;
  }
  for (k = 0; k < n; ++k) v[k + e] = aux[k]; 
}

void ordena (vector <int>& v, int e, int d) {
  if (e < d) {
    int m = (e + d)/2;
    ordena (v,e,m);
    ordena (v,m+1,d);
    fusionar (v,e,m,d);
  }
}

int diferents (const vector <int> v) {
  int n = v.size();
  int cont = 1; 
  for (int i = 1; i < n; ++i) {
    if (v[i-1] != v[i]) ++cont;
  }
  return cont;
}

void llegeix (vector <int>& v) {
  int n = v.size();
  for (int i = 0; i < n; ++i) cin >> v[i];
}

int main () {
  int n;
  while (cin >> n) {
    vector <int> v(n);
    llegeix(v);
    ordena(v,0,n-1);
    cout << diferents(v) << endl;
  }
}
