#include <iostream>
#include <vector>
using namespace std;

struct Assignatura {
  string nom;                 // Nom de l’assignatura
  double nota;                // Entre 0 i 10, -1 indica NP
};

struct Alumne {
  string nom;                 // Nom de l’alumne
  int dni;                    // DNI de l’alumne
  vector<Assignatura> ass;    // Llista d’assignatures de l’alumne
};

void llegirass (vector <Assignatura>& A) {
  for (int i = 0; i < A.size(); ++i) {
    cin >> A[i].nom >> A[i].nota;
  }
} 

void llegiexdades (vector <Alumne>& A) {
  for (int i = 0; i < A.size(); ++i) {
    cin >> A[i].nom >> A[i].dni;
    int n; cin >> n;
    A[i].ass.resize(n);
    llegirass(A[i].ass);
  }
}

double nota(const vector<Alumne>& alums, int dni, string nom) {
  for (int i = 0; i < alums.size(); ++i) {
    if (alums[i].dni == dni) {
      for (int j = 0; j < alums[i].ass.size(); ++j) {
        if (alums[i].ass[j].nom == nom) {
          if (alums[i].ass[j].nota != -1) return alums[i].ass[j].nota;
          else return -1;
        }
      }
    }
  }
  return -1; 
}

double mitjana(const vector<Assignatura>& ass) {
  double tot = 0;
  int cont = 0;
  for (int i = 0; i < ass.size(); ++i) {
    if (ass[i].nota != -1) {
      tot += ass[i].nota;
      ++cont;
    }
  }
  return tot/cont;
}

void compta(const vector<Alumne>& alums, int dni, string nom, int& com) {
  com = 0;
  double tope = nota(alums,dni,nom);
  for (int i = 0; i < alums.size(); ++i) {
    if (mitjana(alums[i].ass) > tope) ++com;
  }  
}

int main () {
  int n; cin >> n;
  vector<Alumne> als (n);
  llegiexdades(als);
  int dni;
  string nom;
  while (cin >> dni >> nom) {
    int com;
    compta(als,dni,nom,com);
    cout << com << endl;
  } 
}
