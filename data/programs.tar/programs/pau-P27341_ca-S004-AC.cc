#include <iostream>
#include <math.h>
using namespace std;

int main() {
  int a;
  int b;            
  while (cin >> a >> b) {
    int cont;    
    int n;
    n = b - a + 1;
    cont = a;
    int i =0;
    int total = 0;
    while (i < n) {
	total += pow(cont,3);
	++cont;
	++i;
    }	  
    cout << "suma dels cubs entre " << a << " i " << b << ": " << total << endl;
  }                              
} 
 