#include <iostream>
using namespace std;

int main() {
  int a, b;
  cin >> a >> b;
  if ( a > b )
  {
    cout << b << endl;
  }
  else
  {
    cout << a << endl;
  }
  
    
}