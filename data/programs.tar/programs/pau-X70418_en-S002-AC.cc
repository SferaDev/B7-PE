#include <iostream>
using namespace std;

int main () {
  int n;
  bool primer = true;
  while (cin >> n) {
    if (primer) primer = false;
    else cout << endl;
    for (int i = 0; i < n; ++i) { //Primera part
      int espais = i;
      while (espais > 0) {
        cout << ' ';
        --espais;
      }
      int creu = 2*n - 1 - 2*i;
      while (creu > 0) {
        cout << 'X';
        --creu; 
      }
      cout << endl; 
    }
    for (int i = 1; i <= n - 1; ++i) { // Segona Part
      int espais = n - 1 - i;
      while (espais > 0) {
        cout << ' ';
        --espais;
      }
      int creu = 3 + 2*i - 2;
      while (creu > 0) {
        cout << 'X';
        --creu; 
      }
      cout << endl; 
    } 
  }
}
