#include <iostream>
#include <vector>
#include <string>

using namespace std;

const int LONG_ALFABET= 'z'-'a'+1;

char lletra_mes_frequent(const string& s) {
  vector <int> lmf(LONG_ALFABET, 0);
  int tams = s.size();
  for (int i = 0; i < tams; ++i) {
    ++lmf[s[i]-'a'];
  }
  int pos, freq = 0;
  for (int i = 0; i < LONG_ALFABET; ++i) {
    if (lmf[i] > freq) {
      pos = i;
      freq = lmf[i];      
    }
  }
  char c = 'a' + pos;
  return c;
}
  
int main (){
  cout.setf(ios::fixed);
  cout.precision(2);
  int n;
  cin >> n;
  vector<string> v(n);
  string y;
  double mitja=0;
  for (int i=0 ; i<n; ++i){
    cin >> y;
    for (int j=0; j<y.length();++j){
      ++mitja;
    }
    v[i]=y;
  }
  mitja= mitja/n;
  cout << mitja << endl;
  for (int i=0 ; i<n; ++i){
    if ( v[i].length() >=mitja){
      cout << v[i] << ": " << lletra_mes_frequent(v[i])<< endl;
    }
  }
}