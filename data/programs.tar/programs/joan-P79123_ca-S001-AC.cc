#include <iostream>
using namespace std;



/*int canvi_base (int n){
  if (n<4) return n;
  else {
    return canvi_base(n/4)*10+n%4;
}
}*/
int suma_digits (int n){
   /* int suma=0;
    i=canvi_base(i);
    while (i>0) {
      suma = suma+i%10;
      i=i/10;
    }return 2*suma;*/
int suma_digits=0;
while (n>0){
  suma_digits+=n%4;
  n=n/4;
} return suma_digits*2;
  
}
bool es_diabolic(int n){
  int s=suma_digits(n);
  if (n%s==0) return true;
  else return false;
}
int main (){
  int n;
  int cont=0;
  while (cin>>n and n!=-1){
    if (es_diabolic(n))++cont; 
  }
  if (cont<10) cout<<"00000"<<cont<<endl;
  else if (cont<100) cout<<"0000"<<cont<<endl;
  else if (cont<1000) cout<<"000"<<cont<<endl;
  else if (cont<10000) cout<<"00"<<cont<<endl;
  else if (cont<100000) cout<<"0"<<cont<<endl;
  else cout<<cont<<endl;
}