#include <iostream>
#include <math.h>
using namespace std;

double distancia(double x1, double y1, double x2, double y2) {
  double tot = sqrt(pow(x1 - x2,2) + pow(y1 - y2,2));
  return tot;
}

int main () {
  cout.setf(ios::fixed);
  cout.precision(4);
  string lloc;
  while (cin >> lloc) {
    double in1, in2;
    double x1, x2;
    double y1, y2;
    bool primer = true;
    cin >> in1 >> in2;
    cin >> y1 >> y2;
    double tot = 0;
    while (in1 != y1 or in2 != y2) {
      if (primer) {
        x1 = in1;
        x2 = in2;
        tot += distancia(x1,x2,y1,y2);
        primer = false;
      } else {
        x1 = y1;
        x2 = y2;
        cin >> y1 >> y2;
        tot += distancia(x1,x2,y1,y2);
      }
    }
    cout << "Trajecte " << lloc << ": " << tot << endl;
  }  
}
