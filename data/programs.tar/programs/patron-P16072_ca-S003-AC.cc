#include <iostream>
#include <vector>

using namespace std;

int min (int a,int b)
{
  if (a>b) return b;
  else return a;
}

vector<double> interseccio(const vector<double>& v1, const vector<double>& v2)
{
  vector<double> r(min(int (v1.size()),int(v2.size())));
  int i1=0,i2=0,ir=0;
  while (i1<int (v1.size()) and i2<int (v2.size())) {
    if (v1[i1]<v2[i2]) {
    ++i1;
  } else if (v2[i2]<v1[i1]){
    i2++;
  } else {
    //r.push_back(v1[i1]);
    r[ir]=v1[i1];
    ++ir;
    ++i1;
    while (i1<int(v1.size()) and v1[i1]==v1[i1-1]) ++i1;
    ++i2;
    while (i2<int (v2.size()) and v2[i2]==v2[i2-1]) ++i2;
    }
  }
  vector <double> nextr(ir);
  for (int i=0; i<ir; ++i)
    nextr[i]=r[i];
  return nextr;
}


int main()
{
  
}