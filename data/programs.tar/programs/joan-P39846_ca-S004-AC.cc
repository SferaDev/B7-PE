#include <iostream>
#include <vector>
#include <queue>
using namespace std;

typedef vector <char> VE;
typedef vector <VE> Graph;


int bfs(const Graph & G, int x, int y){
  Graph vis(G.size(), VE(G[0].size(), 'F'));
  vis[x][y] = 'T';
  queue <pair <int, int> > next;
  next.push(make_pair(x, y));
  queue <int> dQ;
  dQ.push(0);
  vector <int> dist;
  while(!next.empty()){
    int i1 = next.front().first;
    int j1 = next.front().second;
    int d = dQ.front()+1;
    //left
    if (j1 > 0 and G[i1][j1-1] != 'X' and vis[i1][j1-1] == 'F'){
      vis[i1][j1-1] = true;
      if (G[i1][j1-1] == 't'){
        dist.push_back(d);
      }
      next.push(make_pair(i1, j1-1));
      dQ.push(d);
    }
    //right
    if (j1 < G[0].size() and G[i1][j1+1] != 'X' and vis[i1][j1+1] == 'F'){
      vis[i1][j1+1] = true;
      if (G[i1][j1+1] == 't'){
        dist.push_back(d);
      }
      next.push(make_pair(i1, j1+1));
      dQ.push(d);
    }
    //top
    if (i1 > 0 and G[i1 - 1][j1] != 'X' and vis[i1 - 1][j1] == 'F'){
      vis[i1 - 1][j1] = true;
      if (G[i1-1][j1] == 't'){
        dist.push_back(d);
      }
      next.push(make_pair(i1-1, j1));
      dQ.push(d);
    }
    //below
    if (i1 + 1 < G.size() and G[i1 + 1][j1] != 'X' and vis[i1 + 1][j1] == 'F'){
      vis[i1 + 1][j1] = true;
      if (G[i1+1][j1] == 't'){
        dist.push_back(d);
      }
      next.push(make_pair(i1+1, j1));
      dQ.push(d);
    }
    next.pop();
    dQ.pop();
  }
  if (dist.size()==0) return -1;
  else return dist[dist.size()-1];
}

int main(){
  int n, m;
  cin >> n >> m;
  Graph G (n, VE(m));
  for (int i = 0; i < n; ++i){
    for (int j = 0; j < m; ++j){
      cin >> G[i][j];
    }
  }
  int x, y;
  cin >> x >> y;
  int res = bfs(G, x-1, y-1);
  if (res == -1) cout << "no es pot arribar a cap tresor" << endl;
  else cout << "distancia maxima: " << res << endl;
}
