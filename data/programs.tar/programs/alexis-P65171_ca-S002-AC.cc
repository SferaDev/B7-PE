#include <iostream>
#include <cmath>
using namespace std;

/* SPEC
 * 
 * in: L’entrada és un natural n≥ 2 seguit de n nombres reals x1, x2,…, xn.
 * 
 * out: Cal escriure el valor de la variança dels n nombres donats amb exactament dos dígits desprès del punt decimal.
 * 
 */

int main() {
    // Set cout precision
    cout.setf(ios::fixed);
    cout.precision(2);
    
    // Init n
    int n;
    cin >> n;
    
    // Init the result double
    double result, tempResult;
    result = tempResult = 0;
    
    // Do both product iterations at once
    for (int i = 0; i < n; ++i) {
        double x;
        cin >> x;
        result += pow(x, 2);
        tempResult += x;
    }
    
    // Do the outer operations of the first product
    result = result / (n - 1);
    
    // Do the outer operations of the second product
    tempResult = pow(tempResult, 2) / (n * (n -1));
    
    // Do the final substraction
    result = result - tempResult;
    
    // Print the results
    cout << result << endl;
}