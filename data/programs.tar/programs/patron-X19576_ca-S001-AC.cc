#include <iostream>
#include <vector>
 
using namespace std;
 
typedef vector<int> Fila;
typedef vector<Fila> Matriu;
 
struct Punto {
    int x;
    int y;
};
 
// PRE: Tiene como entrada una matriz
// POS: Indica con un booleano si esa matriz es aceptable o no, es decir,
//      mira que la primera y �ltima columna tengan mina (todo -1s)
bool es_aceptable(Matriu& matrix) {
  for (int i = 0; i < matrix.size(); ++i) {
    if (matrix[i][0] != -1 or matrix[i][matrix.size() - 1] != -1) return false;
  }
  return true;
}
 
// Trivial
void leer_entrada(Matriu& matriz) {
    int n = matriz.size();
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> matriz[i][j];
        }
    }
}
 
// Reutilizaci�n de c�digo para el ejercicio "El joc de la vida". Memorizarlo o saber c�mo funciona
// puede resultar MUY �til, ya es el tercer ejercicio que lo soluciona con este cacho de c�digo con
// peque�as modificaciones.
// PRE: Entrada del mapeado, las coordenas de una casilla y un entero que indica el tama�o de la matriz.
// POS: Devuelve el n�mero de minas que rodean al punto que le he pasado con una distancia de 1 casilla.
int numero_de_minas_alrededor(const Matriu& mapeado, int fila_casilla, int columna_casilla, int n) {
    // Genero hipot�tico cuadrado.
    Punto a, b, c;
    a.y = fila_casilla;
    a.x = columna_casilla;
    b = c = a;
    if (a.y > 0) {
        --a.y;
        b.y = a.y;
    }
    if (a.x > 0) --a.x;
    if (b.x < n - 1) {
        ++b.x;
        c.x = b.x;
    }
    if (c.y < n - 1) ++c.y;
    // Recorro todo el �rea de ese cuadrado con la intenci�n de ir sumando
    // todas las bacterias que me vaya encontrando a una distancia de 1 cuadrado.
    int encontrados = 0;
    for (int i = a.y; i <= c.y; ++i) {
            for (int j = a.x; j <= b.x; ++j) {
                if (mapeado[i][j] == -1) {
                    ++encontrados;
                }
            }
        }
    // Ya que se cuenta �l mismo cuando est� llena la casilla miraremos dos posibles casos... cuando
    // est� llena y cuando no...
    if (mapeado[fila_casilla][columna_casilla] == -1) return encontrados - 1;
    else return encontrados;
}
 
// PRE: entrada de la matriz con informaci�n de las minas
// POS: Saca por pantalla el contenido de la matriz
void printar(const Matriu& infominas, int n) {
    for (int i = 0; i < n; ++i) {
        bool primer = true;
        for (int j = 0; j < n; ++j) {
            if (primer) {
                if (infominas[i][j] >= 0) cout << '+' << infominas[i][j];
                else cout << infominas[i][j];
                primer = false;
            }
            else {
                if (infominas[i][j] >= 0) cout << " +" << infominas[i][j];
                else cout << ' ' << infominas[i][j];
            }
        }
        cout << endl;
    }
}
 
int main(){
    int a;
    cin >> a;
    for (int g = 0; g < a; ++g) {
        int n;
        cin >> n;
        Matriu matriz(n, Fila(n));
 
        leer_entrada(matriz);
        if (not es_aceptable(matriz)) cout << "reject" << endl;
        else {
            Matriu infominas(n, Fila(n));
            // Con "i" y "j" voy recorriendo la matriz cuadrada de la entrada (por eso es hasta i y j < n)
            // y voy llenando una segunda matriz (infomines) de informaci�n acerca de si tiene mina o
            // cu�ntas minas tiene alrededor.
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (matriz[i][j] == -1) infominas[i][j] = -1;
                    else infominas[i][j] = numero_de_minas_alrededor(matriz, i, j, n);
                }
            }
            printar(infominas, n);
        }
 
        cout << endl;
    }
}
