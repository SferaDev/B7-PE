#include <iostream>
using namespace std;

bool is_circular_increasing() {
  int ant;
  int act;
  int primer;
  bool increasing = true;
  cin >> ant;
  primer = ant;
  while (cin >> act) {
    if (not increasing and (act < ant or act > primer)) return false;
    if (increasing and act < ant) increasing = false;
    ant = act;
  }
  return true;
}

int main () {
  bool random = is_circular_increasing();
  if (random) cout << "yes" << endl;
  else cout << "no" << endl;
}
