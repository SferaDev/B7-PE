#include <iostream>
  #include <vector>
  using namespace std;
 
  typedef vector<int> Row;
  typedef vector<Row> Matrix;
 
  // Reads a matrix  with n rows and m columns
  // from the input and returns it. Assumes
  // that the input format is
  // a00 ... a0(m-1) a10 ... a1(m-1) ... a(n-1)0 ... a(n-1)(m-1)
  Matrix read_matrix(int n, int m)
  {
     Matrix M(n, Row(m));
     for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            cin >> M[i][j];    
     return M;
  }
 
  // prints the given non-empty matrix into the cout; the first line
  // gives the number of rows followed by the number
  // of columns, then each successive row is printed
  // in a different line, with each element of the row
  // separated from the next by a blank space,
  // and an end-of-line is printed at the end, after the
  // last row of the matrix
  void print_matrix(const Matrix& M) {
    //Imprimim el tamany de la matriu
    cout << M.size() << " " << M[0].size() << endl;
    //Per cada fila
     for(int i=0;i<M.size();i++){
       //Per cada element de la fila
        for(int j=0;j<M[0].size();j++){
    //Si es el primer element, no imprimeix espai i el valor
    if(j == 0) cout << M[i][j];
    //Si no ho es imprimeix espai i el valor
    else cout << " " << M[i][j];
        }
        //Imprimeix salt de linea entre elements de la mateixa matriu
        cout << endl;
     }
  }    
 
  // Returns the sum of two matrices of correct dimensions
  Matrix matrix_sum(const Matrix& A, const Matrix& B) {
    int n = A.size(); int m = A[0].size();
    Matrix C(n, Row(m));
    for (int i = 0; i < n; ++i)
       for (int j = 0; j < m; ++j)
           C[i][j] = A[i][j] + B[i][j];
    return C;
  }
 
  // Returns the product of two matrices of correct
  // dimensions
  Matrix matrix_product(const Matrix& A, const Matrix& B) {
    int n = A.size(); int p = A[0].size();
    int m = B[0].size();
    Matrix C(n, Row(m,0));
    for (int i = 0; i < n; ++i)
       for (int j = 0; j < m; ++j)
           for (int k = 0; k < p; ++k)
                C[i][j] += A[i][k]*B[k][j];
    return C;
  }
 
  // The main program reads commands from the input and
  // writes the appropriate answers in the output; the
  // commands are either
  // "+ <n> <m> <elements of A> <n'> <m'> <elements of B>",
  // which writes the sum of the two matrices if the
  // dimensions of the matrices are correct, and an error
  // message otherwise; or
  // "* <n> <m> <elements of A> <n'> <m'> <elements of B>",
  // which writes the product of the two matrices if the
  // dimensions of matrices are correct, and an error
  // message otherwise.
  int main() {
    char s;
    while (cin >> s) {
     
     
     
      //Declarem les dues matrius
      Matrix M1,M2;
      //Declarem dos integers per a les variables del nombre de files/cloumnes
      int a,b;
       //Agafem els 2 primers valors
       cin >> a >> b;
       //Llegim matriu 1
       M1 = read_matrix(a,b);
       //Agafem el tamany de la segona matriu
       cin >> a >> b;
       //Llegim la segona matriu
       M2 = read_matrix(a,b);
       
       //Comprobem que ambdues matrius son correctes
       
       
       if (s == '+') {
    bool posible_suma = true;
     if(M1.size() != M2.size() or M1[0].size() !=  M2[0].size()) posible_suma = false;
         //si es posible fem operacio
         if (posible_suma) print_matrix(matrix_sum(M1,M2));
         //Si no retornem error
         else cout << "The two matrices cannot be added." << endl;
       } else if (s == '*') {
    //Declarem un boleŕ per saber si es o no posible loperacio
         bool posible_mult = true;
     if(M1[0].size() != M2.size()) posible_mult = false;
         //Si es posible fem operacio
         if (posible_mult) print_matrix(matrix_product(M1,M2));
         //Si no retornem error
         else cout << "The two matrices cannot be multiplied." << endl;
       }
       cout << endl;
     }
   }