#include <iostream>
using namespace std;
 
int main () {
  int medida_octogono;
  while (cin >> medida_octogono){
    int cantidad_de_x = medida_octogono;
    int cantidad_de_esp = medida_octogono - 1;
   
    /*PARTE SUPERIOR DEL OCTOGONO*/  
    //Saltos de linea
    for (int i = 0; i < medida_octogono; ++i){
      //Cantidad de espacios
      for (int k = 0; k < cantidad_de_esp; ++k) cout << ' ';
      //Cantidad de X por linea
      for (int j = 0; j < cantidad_de_x; ++j) cout << 'X';
      cantidad_de_x += 2;  //Actualizacion de valor por cada salto
      --cantidad_de_esp; //Actualizacion del numero de espacios
      cout << endl;
    }
    /*CUERPO DEL OCTOGONO*/
    int cuerpo = medida_octogono - 2;
    int cantidad_x_cuerpo = cantidad_de_x - 2;
    //Salto de linea del cuerpo
    for (int s = 0; s < cuerpo; ++s){
      for (int l = 0; l < cantidad_x_cuerpo; ++l) cout << 'X';
      cout << endl;
    }
   
    /*PARTE INFERIOR*/
      //Saltos de linea
      int cantidad_x_inferior = cantidad_x_cuerpo;
      int cantidad_de_esp_inferior = -1;
      int aux;
      for (int x = medida_octogono; x > 0; --x){
        //Cantidad de espacios
        ++cantidad_de_esp_inferior;
        aux = cantidad_de_esp_inferior;
        while (cantidad_de_esp_inferior > 0) {
            cout << ' ';
            --cantidad_de_esp_inferior;
        }
        //Cantidad de las x inferiores
        for (int y = cantidad_x_inferior; y > 0; --y) cout << 'X';
        cantidad_x_inferior -= 2;
        cout << endl;
        cantidad_de_esp_inferior = aux;
      }
    cout << endl;
  }
}