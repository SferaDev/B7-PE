#include <iostream>
#include <vector>

using namespace std;

// Te piden un recorrido a la hora de mostrar a todas aquellas mujeres
// con edad menor al hombre con mayor edad.

struct Persona {
    string nom;
    bool dona;
    int edat;
};

int main(){
    int n;
    cin >> n;
    vector<Persona> p(n);
    Persona persona;
    // Bucle que crea el vector con las personas introducidas
    for (int i = 0; i < n; ++i) {
        cin >> persona.nom;
        string genero;
        cin >> genero;
        if (genero == "home") persona.dona = false;
        else persona.dona = true;
        cin >> persona.edat;
        p[i] = persona;
    }
    Persona home_mes_vell;
    home_mes_vell.dona = false;
    home_mes_vell.edat = 0;
    int size_p = p.size();
    // Se hacen varios bucles, uno para buscar el hombre ms viejo,
    // usando as� un recorrido; y otro para mostrar a aquellas mujeres
    // con edad inferior.
    for (int j = 0; j < size_p; ++j) {
        if (not p[j].dona and p[j].edat > home_mes_vell.edat) home_mes_vell = p[j];
    }
    for (int k = 0; k < size_p; ++k) {
        if (p[k].dona and p[k].edat < home_mes_vell.edat) cout << p[k].nom << ' ' << p[k].edat << endl;
    }
}
