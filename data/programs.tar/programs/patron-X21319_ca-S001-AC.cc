#include <iostream>
#include <vector>
#include <map>
#include <stack>

using namespace std;

typedef vector <vector <int> > graph;
typedef vector <string> VS;
typedef vector <bool> VB;
typedef map <string, int> MSI;
typedef vector <int> VI;

int noutputs, ninputs;

graph gdir, ginv;

MSI s2v;

VS v2s;

int string2vertex (const string &s){
	auto it = s2v.find(s);
	if (it != s2v.end()) return it->second;
	int v = v2s.size();
	v2s.push_back(s);
	s2v.insert(make_pair(s,v));
	return v;
}

int main (){
	
	noutputs = ninputs = 0;
	string token;
	cin >> token;
	
	while (cin >> token and token != "END"){ //OUTPUT
		++noutputs;
		string2vertex(token);
	}
	
	cin >> token;
	
	while (cin >> token and token != "END"){ //INPUT
		++ninputs;
		string2vertex(token);
	}
	while (cin >> token and token != "END"){ //OP
		
		string s;
		
		cin >> s;
		int ov = string2vertex(s);
		
		if (ov + 1 > gdir.size()) gdir.resize (ov+1);
		
		cin >> s;
		int iv1 = string2vertex(s);
		
		if (iv1 + 1 > ginv.size()) ginv.resize(iv1+1);
		
		if (token == "NOT"){
			gdir[ov].push_back(iv1);
			ginv[iv1].push_back(ov);
		}
		else{
			cin >> s;
			int iv2 = string2vertex(s);
			if (iv2 + 1 > ginv.size()) ginv.resize(iv2+1);
			if (token == "AND"){
				gdir[ov].push_back(min(iv1, iv2));
				gdir[ov].push_back(max(iv1, iv2));
			}
			else{
				gdir[ov].push_back(max(iv1, iv2));
				gdir[ov].push_back(min(iv1, iv2));
			}
			ginv[iv1].push_back(ov);
			ginv[iv2].push_back(ov);
		}
	}
	
	int n = gdir.size();
	
	VI ddir(n, 0); // Graus d'entrada dels vertexs
	
	for (int v = 0; v < n; ++v) ddir[v] = gdir[v].size();
	
	stack <int> bag;
	
	for (int v = noutputs; v < noutputs + ninputs; ++v) bag.push(v);
	
	VI ord; //Ordenacio topologica (at last)
	
	while (not bag.empty()){
		int v = bag.top();
		ord.push_back(v);
		bag.pop();
		for (auto w : ginv[v]){
			--ddir[w];
			if (ddir[w] == 0) bag.push(w);
		}
	}
	
	VB val(n);
	
	while (cin >> token){
		val[noutputs] = (token == "T");
		for (int v = noutputs + 1; v < noutputs + ninputs; ++v){
			cin >> token;
			val[v] = (token == "T");
		}
		for (auto v : ord){
			if (gdir[v].size() == 1) val[v] = not val[gdir[v][0]];
			else if (gdir[v].size() == 2){
				int iv1 = gdir[v][0];
				int iv2 = gdir[v][1];
				if(iv1 < iv2) val[v] = val[iv1] and val[iv2];
				else val[v] = val[iv1] or val[iv2];
			}
		}
		cout << (val[0] ? 'T' : 'F');
		for (int v = 1; v < noutputs; ++v) cout << ' ' << (val[v] ? 'T' : 'F');
		cout << endl;
	}
}