#include <iostream>
#include <vector>

using namespace std;

struct Info { 
   char contingut; // Mur (�X�), buit (�.�) o deixalles (d�git) 
   int energia; // Aportacio d�energia solar de la casella 
};

typedef vector< vector<Info> > Camp;

bool te_deixalles(const Info& casella){
  return(casella.contingut >= '0' and casella.contingut <='9');
}

bool visitada(const Info& casella){
  return (casella.contingut == '*');
}

void recollecta(Camp& v,int& i,int& j,int& e,char ordre,int& suma)
{
  //Calcules com ha d'avan�ar en funcio de l'ordre
  int di=0,dj=0;
  if(ordre == 'N') di = -1;      //Nord => decrementa fila
  else if(ordre == 'S') di = 1;  //Sud => incrementa fila
  else if(ordre == 'E') dj = 1;  //Est => incrementa columna
  else dj = -1;                  //Oest => decrementa columna
  
  //Recorregut
  suma=0;
  while(e>0 and v[i][j].contingut!='X'){
    if(te_deixalles(v[i][j])){
      suma += v[i][j].contingut - '0';    //Recull escombraries
      e = e - 1;                          //Gasta energia
    }
    if(not visitada(v[i][j])) e = e + v[i][j].energia;  //Recarga energia
    v[i][j].contingut = '*';
    i += di;
    j += dj;
  }
  
  //Torna a la posicio anterior a la topada amb el mur
  i -= di;
  j -= dj;
  
}

void recollectaordres(Camp& v, int& i, int& j,int& e, const string& ordres, int& sumatot)
{
  sumatot = 0;
  int n = ordres.size();
  for(int k=0;k<n;++k){
    int suma;
    recollecta(v,i,j,e,ordres[k],suma);
    sumatot += suma;
  }
}

int main()
{
  int f,c;
  cin >> f >> c;
  //Llegir el camp(contingut i energies)
  Camp v(f,vector<Info>(c));
  for(int i=0;i<f;++i){
    for(int j=0;j<c;++j){
      cin >> v[i][j].contingut;
    }
  }
  
  for(int i=0;i<f;++i){
    for(int j=0;j<c;++j){
      char r;
      cin >> r;
      v[i][j].energia = r - '0';
    }
  }
  
  //Llegir posicio i energia incials
  int x,y,e;
  cin >> x >> y >> e;
  
  //Legir ordres de moviment
  string ordre;
  cin >> ordre;
  
  //Recollir deixalles segons ordre
  int suma;
  recollectaordres(v,x,y,e,ordre,suma);
  cout << "escombraries: " << suma << endl;
  cout << "energia: " << e << endl;
  cout << "posicio: (" << x << "," << y << ")" << endl;
  
}
