#include <iostream>
#include <vector>
using namespace std;
 
void fusiona(vector<double>& v, int e, int m, int d) {
    int n = d - e + 1;
    vector<double> aux(n);
    int i = e;
    int j = m + 1;
    int k = 0;
 
    while (i <= m or j <= d) {
        if (i > m) {
            aux[k] = v[j];
            ++j;
            ++k;
        }
        else if (j > d) {
            aux[k] = v[i];
            ++i;
            ++k;
        }
        else if (v[i] < v[j]) {
            aux[k] = v[i];
            ++i;
            ++k;
        }
        else {
            aux[k] = v[j];
            ++j;
            ++k;
        }
    }
 
    for (int l = 0; l < n; ++l) {
        v[l + e] = aux[l];
    }
}
 
void mergesort (vector<double>& v, int e, int d) {
    if (e < d) {
        int m = (e + d)/2;
        mergesort(v, e, m);
        mergesort(v, m + 1, d);
        fusiona(v, e, m, d);
    }
}
 
void ordena_per_fusio(vector<double>& v) {
    int d = v.size();
    d -= 1;
    mergesort(v, 0, d);
}
 
int main() {
// Juego de prueba
    vector<double> v1(6);
    cout << "V1: ";
    for (int i = 0; i < 6; ++i) cin >> v1[i];
 
    ordena_per_fusio(v1);
 
    for (int i = 0; i < 6; ++i) cout << v1[i] << endl;
}
