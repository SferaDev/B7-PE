#include <iostream>
#include <vector>
using namespace std;
typedef vector< vector<int> > Matriu;


Matriu producte(const Matriu& a, const Matriu& b){
  int m=a.size();
  Matriu l(m, vector <int>(m));
  for (int i=0;i<m;++i){
    for (int j=0;j<m;++j){
        int suma=0;
        for (int k=0;k<m;++k){
            suma+=a[i][k]*b[k][j];
        }
        l[i][j]=suma; 
  }
  }
  
  return l;
}

int main(){
  int f;
  cin>>f;
  Matriu a(f,vector<int>(f));
  Matriu b(f,vector<int>(f));
  for (int i=0;i<f;++i){
    for (int j=0;j<f;++j)cin>>a[i][j];
  }
  cout<<endl;
  for (int i=0;i<f;++i){
    for (int j=0;j<f;++j)cin>>b[i][j];
  }
  Matriu c(f, vector<int>(f));
  c=producte(a,b);
  cout<<endl;
  for (int i=0;i<f;++i){
    for (int j=0;j<f;++j)cout<<c[i][j]<<' ';
    cout<<endl;
  }
}



