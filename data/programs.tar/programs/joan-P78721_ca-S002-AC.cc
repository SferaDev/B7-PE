#include <iostream>
#include <string>
using namespace std;

int main (){
    string x1, x2, temp;
    bool trobat = false;
    bool impres = false;
    cin >> x1;
    while (cin >> x2 and x2 != "END" ){
        if (not trobat){
            if (x1 < x2) {
                cout << x1 << endl;
                x1 = x2;
            }
            else {
                trobat = true;
                temp = x1;
                x1 = x2;
            }
        }
        else{
            if (not impres){
                if (x2 > temp){
                    cout << x1 << endl;
                    cout << temp << endl;
                    x1 = x2;
                    impres = true;
                }
                else {
                    cout << x1 << endl;
                    x1 = x2;
                }
            }
            else {
                cout << x1 << endl;
                x1 = x2;
            }
        }
    }
    cout << x1 << endl;
    if (not impres) cout << temp << endl;
    
    
    
}