#include <iostream>

using namespace std;

int main() {

  int a,b;
  cin>>a>>b;
  int an=a;
  int bn=b;
  
  while (a!=b){
    if (a<b) swap (a,b);
    a-=b;
  }
  cout<<"El mcd de "<<an<<" i "<<bn<<" es "<<a<<"."<<endl;
}