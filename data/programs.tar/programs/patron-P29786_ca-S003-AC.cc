#include <iostream>

using namespace std;

bool es_potencia_de_3 (int n)
{
  if (n==1) return true;
  
  while (n>1){
    if (n%3!=0) return false;
    else n/=3;
  }
  return (n==1);
}

int main ()
{
  int n;
  cin>>n;
  cout << es_potencia_de_3(n) << endl;
}