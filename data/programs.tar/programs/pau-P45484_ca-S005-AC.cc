#include <iostream>
#include <vector>
using namespace std;

int totf (const vector< vector<int> >& t) {
  int tot = 0;
  int n = t.size();
  for (int i = 0; i < n; ++i) tot += t[0][i];
  return tot;
}

bool diag1 (const vector< vector<int> >& t, int tok) {
  int n = t.size();
  int tot = 0;
  for (int i = 0; i < n; ++i) {
    if (t[i][i] > n*n or t[i][i] < 1) return false;
    tot += t[i][i];
  }
  return tot == tok;
}

bool diag2 (const vector< vector<int> >& t, int tok) {
  int n = t.size();
  int i = 0;
  int j = n - 1;
  int tot = 0;
  while (i < n and j >= 0) {
    if (t[i][j] > n*n or t[i][j] < 1) return false;
    tot += t[i][j];
    ++i; --j;
  }
  return tot == tok;
}

bool columnas (const vector< vector<int> >& t, int tok) {
  int n = t.size();
  for (int i = 0; i < n; ++i) {
    int tot = 0;
    for (int j = 0; j < n; ++j) {
      if (t[j][i] > n*n or t[j][i] < 1) return false;
      tot += t[j][i];
    }
    if (tot != tok) return false;
  }
  return true;
}

bool files (const vector< vector<int> >& t, int tok) {
  int n = t.size();
  for (int i = 1; i < n; ++i) {
    int tot = 0;
    for (int j = 0; j < n; ++j) {
      if (t[i][j] > n*n or t[i][j] < 1) return false;
      tot += t[i][j];
    }
    if (tot != tok) return false;
  }
  return true;
}

bool quadrat_magic(const vector< vector<int> >& t) {
  int tok = totf (t);
  int n = t.size();
  if (tok < 1 or tok > n*n*n) return false;
  if (files(t,tok) and columnas(t,tok) and diag1(t,tok) and diag2(t,tok))
  return true;
  return false; 
}

void llegeixMat (vector< vector<int> >& t) {
  int n = t.size();
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) cin >> t[i][j];
  }
}

int main () {
  int n;
  while (cin >> n) {
    vector< vector<int> > t(n, vector<int> (n));
    llegeixMat (t);
    if (quadrat_magic(t)) cout << "SI" << endl;
    else cout << "NO" << endl;   
  }
}
