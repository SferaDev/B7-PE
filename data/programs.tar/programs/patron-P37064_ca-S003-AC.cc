#include <set>
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main(){
	set<string> words;
	set<string>::iterator it;
	string n;
	cin >> n;
	if (n != "END"){
		words.insert(n);
		it = words.begin();
		cout << n << endl;
		while (cin >> n and n != "END"){
			words.insert(n);
			if (n < *it and words.size()%2 == 0) --it;
			else if (n > *it and words.size()%2 != 0) ++it;
			cout << *it << endl;
		}
	}
}