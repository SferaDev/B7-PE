#include <iostream>
#include <cmath>
using namespace std;

/* SPEC
 * 
 * in: Input consists of a real number x followed by the description of the polynomial p(z): the real coefficients
 * c0, c1, …, cn in this order.
 * 
 * out: Print p(x) with 4 digits after the decimal point.
 * 
 */

int main() {
    // Set cout precision
    cout.setf(ios::fixed);
    cout.precision(4);
    
    // Init the variables
    int count = 0;    
    double x, c, result = 0;
    cin >> x;
    
    // Loop through cin
    while (cin >> c) {
        result += (c * pow(x, count));
        ++count;
    }
    
    cout << result << endl;
}