#include <set>
#include <iostream>
#include <string>
using namespace std;

void llegir_set(set<string> &totes, set<string> &cap)
{
  string s;
  while(cin >> s and s != ".")
  {
   totes.insert(s);
   cap.insert(s);
  }
}

void compara(set<string> &totes, set<string> &cap, set<string> &aux)
{
  
  set<string>::iterator it1 = totes.begin();
  while(it1 != totes.end()){
    if(aux.find(*it1) == aux.end()) it1 = totes.erase(it1);
    else ++it1;
  }
  
  set<string>::iterator it2 = cap.begin();
  while(it2 != cap.end()){
    if(aux.find(*it2) != aux.end()) it2 = cap.erase(it2);
    else ++it2;
  }
}

void escriure(set<string> &totes, set<string> &cap)
{
  set<string>::iterator it_totes = totes.begin();
  cout << "Totes les activitats:";
  while(it_totes != totes.end()){
    cout << " " << *it_totes;
    ++it_totes;
  }
  cout << endl;
  set<string>::iterator it_cap = cap.begin();
  cout << "Cap activitat:";
  while(it_cap != cap.end()){
    cout << " " << *it_cap;
    ++it_cap;
  }
  cout << endl;
}

int main()
{
  set<string> totes;
  set<string> cap;
  llegir_set(totes,cap);
  int n_act;
  cin >> n_act;
  
  for(int i=0; i<n_act;++i){
    set<string> aux;
    string s;
    while(cin >> s and s != ".") 
      aux.insert(s);
    compara(totes,cap,aux);
  }
  escriure(totes,cap);
}