#include <iostream>
#include <queue>
#include <sstream>
#include <string>

using namespace std;

int main() {
  char s;
  int n;
  priority_queue<int> p;
  while (cin >> s) {
    if ( s == 'S') {
      cin >> n;
      p.push(n);
  } else if ( not p.empty()) {
      if( s== 'A') cout << p.top() << endl;
      else if (s=='R') p.pop();
      else if (s== 'I') {
	int aux = p.top();
	int aux2;
	cin >> aux2;
	aux= aux + aux2;
	p.pop();
	p.push(aux);
    } else if (s== 'D') {
	int aux = p.top();
	int aux2;
	cin >> aux2;
	aux= aux - aux2;
	p.pop();
	p.push(aux);
   
    }
  } else {
      if (s =='I' or s == 'D') cin >> n;
      cout << "error!" << endl;
  }
  }
}

