#include <iostream>
using namespace std;

void giraparaules (int cont, int n) {
  string act;
  cin >> act;
  if (cont < n) giraparaules(++cont,n);
  cout << act << endl;
}

int main () {
  int n;
  cin >> n;
  if (n > 0) giraparaules(1,n);
}
