#include <iostream>
#include <vector>

using namespace std;
int vida (vector<vector<char> >& car, int i, int j){
  int count;
  count = 0;
    for (int a=i-1;a<i+2;++a){
      for (int b=j-1;b<j+2;++b){
	if (car[a][b]=='B')++count;
	
      }
    }
    return count;
}
    
int main (){
  int n, m;
  bool acabat, primer;
  primer=true;
  while (cin>>n>>m and n!=0 and m!=0){
    if (not primer) cout<<endl;
    vector<vector<char> > car(n+2,vector<char>(m+2,'$'));
    for (int i=1;i<n+1;++i){
      for (int j=1;j<m+1;++j) cin>>car[i][j];
    }
    
     for (int i=1;i<n+1;++i){
      for (int j=1;j<m+1;++j) {
	int conta=vida(car, i, j);
	if (car[i][j]=='B'){--conta;
	if (conta==3 or conta==2) cout<<'B';
	else cout<<'.';
	}
    
	if (car[i][j]=='.'){
	if (conta==3) cout<<'B';
	else cout<<'.';
	}
	
      }
	cout<<endl;
      
    }
    if (primer) primer=false;
  }
}