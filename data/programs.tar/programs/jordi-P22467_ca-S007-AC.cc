#include <iostream>
 
using namespace std;
 
bool primer(int a) {
    if (a <= 1) return false;
    for (int i = 2; i*i <= a; ++i) {
        if (a%i == 0) return false;
    }
    return true;
}
bool es_primer_perfecte(int n) {
    if (not primer(n)) return false;
    int resultado = 0;
    int digitos = 0;
    while (n > 0) {
        resultado += n%10;
        n /= 10;
        ++digitos;
    }
    bool result_es_primer = primer(resultado);
    if (result_es_primer and digitos == 1) return true;
    else if (result_es_primer) return es_primer_perfecte(resultado); 
    else return false;
}
int main() {
    int n;
    while (cin >> n) {
        cout << es_primer_perfecte(n) << endl;
    }
}