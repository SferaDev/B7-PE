#include <iostream>

using namespace std;

int mcd(int a, int b) {
  int mcd;
  while (b!=0){
    int r= a%b;
    a=b;
    b=r;
  }
  mcd=a;
  return mcd;
}
int main(){
  int x, y, max;
  cin >> x >> y;
  max= mcd(x,y);
  cout << max << endl;
}
