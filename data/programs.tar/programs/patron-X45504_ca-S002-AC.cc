#include "ListaPalabras.hh"

void ListaPalabras::anadir_palabra(const Palabra &p)
{
  bool trobat;
  int i;
  buscar_palabra_posicion(p,trobat,i);
  
  if(trobat)
    ++paraules[i].freq;
  else{
    
    paraules[nparaules].par = p;
    paraules[nparaules].freq = 1;
    ++npar_long[p.long_pal()-1];
    ++nparaules;
  }
  ++suma_frec_long[p.long_pal()-1];
}

void ListaPalabras::borrar_palabra(const Palabra &p)
{
  int i;
  bool trobat;
  buscar_palabra_posicion(p,trobat,i);
  
  if(trobat)
  {
    --suma_frec_long[p.long_pal()-1];
    
    if(paraules[i].freq > 1)
      --paraules[i].freq;
    
    else{
      --npar_long[p.long_pal()-1];
      
      for(int j=i;j<nparaules-1;++j)
	paraules[j] = paraules[j+1];
      
      --nparaules;
    }
  }
}

void ListaPalabras::buscar_palabra_posicion(const Palabra &p, bool &b, int &i) const
{
  b=false;
  i=0;
  while(i<nparaules and not b)
  {
    if(paraules[i].par.iguales(p)) b = true;
    else ++i;
  }
}
