#include <iostream>
#include <vector>
using namespace std;



pair <int, int> maxmin (const vector <int>& v){
    int max = v[0];
    int min = v[0];
    for (int i = 1; i < v.size(); ++i){
        if (v[i] > max) max = v[i];
        else if (v[i] < min) min = v[i];
    }
    pair <int, int> a (max, min);
    return a;
}



int main (){
    
    int n;
    cin >> n;
    vector <int> v (n);
    for (int i = 0; i < n; ++i){
        cin >> v[i];
    }
    pair <int, int> b = maxmin(v);
    cout << b.first << " " << b.second << endl;
}