#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b)
{
  b = false;
  int right = nest - 1;
  int left = 0;
  int j;
  while (left <= right and not b){
    j = (right + left)/2;
    if (est.consultar_DNI() < vest[j].consultar_DNI()) right = j - 1;
    else if (est.consultar_DNI() > vest[j].consultar_DNI()) left = j + 1;
    else b = true;
    
}
  if (not b) {
    if (est.te_nota()) {
      incrementar_interval(est.consultar_nota());
    }
     //afegir estudiant
    for (int i = nest - 1; i >= left; --i){
      vest[i + 1]=vest[i];
    }
    vest[left]=est;
    ++nest;
  }
}

void Cjt_estudiants::esborrar_estudiant(int dni, bool& b)
{
  b=false;
  int right = nest - 1;
  int left = 0;
  int j;
  while (left <= right and not b){
    j = (right + left)/2;
    if (dni < vest[j].consultar_DNI()) right = j - 1;
    else if (dni > vest[j].consultar_DNI()) left = j + 1;
    else b = true;
    
}
  if (b){
    if (vest[j].te_nota()){
    decrementar_interval(vest[j].consultar_nota());
    }
    for (int i = j; i < nest - 1; ++i){
      vest[i]=vest[i+1];
    }
    --nest;
  }
}