#include <iostream>
using namespace std;

bool primer(int n) {
	if (n <= 1) return false;
	int k = 2;
	while (k*k <= n and n%k != 0) ++k;
	return k*k > n;
}

int seguent_primer(int n) {
	++n;
	while (not primer(n)) ++n;
	return n;
}

int main() {
	int n;
	while(cin >> n and primer(n)){
		n = seguent_primer(n);
		cout << n << endl;
	}
}
