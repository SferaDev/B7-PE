#include <iostream>
using namespace std;

int sum_of_numbers(int n) {
    if (n >= 10) return n%10 + sum_of_numbers(n/10);
    else return n;
}

bool is_prime(int n) {
    if (n <= 1) return false;
    for (int i = 2; i*i <= n; ++i) {
        if (n%i == 0) return false;
    }
    return true;
}

bool is_perfect_prime(int n){
    if (is_prime(n) && n > 10) {
        return is_perfect_prime(sum_of_numbers(n));
    }
    return is_prime(n);
}

int main() {
    int n;
    while (cin >> n) cout << is_perfect_prime(n) << endl;
}