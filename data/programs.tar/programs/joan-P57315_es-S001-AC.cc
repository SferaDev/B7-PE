#include<iostream>
using namespace std;
 
int main() {
  int x, y, z;
  char a, b, c;
  cin >> x >> y >> z;
  cin >> a >> b >> c;
 
  int n1, n2, n3;
 
  if (x < y and x < z) {
    n1 = x;
    if (y < z) {
      n2 = y;
      n3 = z;
    }
    else {
      n2 = z;
      n3 = y;
    }
  }
  else if (y < z) {
    n1 = y;
    if (x < z) {
      n2 = x;
      n3 = z;
    }
    else {
      n2 = z;
      n3 = x;
    }
  }
  else {
    n1 = z;
    if (x < y) {
      n2 = x;
      n3 = y;
    }
    else {
      n2 = y;
      n3 = x;
    }
  }
 
 if (a < b and a < c) {
    cout << n1 << " ";
    if (b < c) {
      cout << n2 << " " << n3 << endl;
    }
    else cout << n3 << " " << n2 << endl;
  }
  else if (b < a and b < c) {
    if (a < c) {
      cout << n2 << " " << n1 << " " << n3 << endl;
    }
    else cout << n3 << " " << n1 << " " << n2 << endl;
  }
  else if (c < a and c < b) {
    if (a < b) {
      cout << n2 << " " << n3 << " " << n1 << endl;
    }
    else cout << n3 << " " << n2 << " " << n1 << endl;
  }
}