#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b) {
  int dni = est.consultar_DNI();
  int x = cerca_dicot(vest,0,nest-1,dni);
  if (x >= 0 and x < nest) b = (dni == vest[x].consultar_DNI());
  else b = false;
  if (not b) {
    int i = nest - 1;
    bool trobat = false;
    bool toquen = false;
    if (est.te_nota()) {
      if (imax == -1) toquen = true;  
      else if (est.consultar_nota() == vest[imax].consultar_nota()) {
        if (est.consultar_DNI() < vest[imax].consultar_DNI()) toquen = true;
      }
      else if (est.consultar_nota() > vest[imax].consultar_nota()) toquen = true;
    }
    if (imax != -1 and not toquen and est.consultar_DNI() < vest[imax].consultar_DNI()) ++imax;
    while (i >= 0 and not trobat) {
      if (dni > vest[i].consultar_DNI()) trobat = true;
      else {
        vest[i+1] = vest[i];
        --i;
      }
    }
    ++nest;
    vest[i+1]=est;
    if (toquen) imax = i + 1;   
  } 
}

void Cjt_estudiants::eliminar_estudiants_sense_nota() {
  int j = 0;
  int iaux = imax;
  for (int i = 0; i < nest; ++i) {
    if (vest[i].te_nota()) {
      vest[j] = vest[i];
      ++j;
    }
    else if (i < imax) --iaux;
  }
  nest=j;
  imax = iaux;  
}
