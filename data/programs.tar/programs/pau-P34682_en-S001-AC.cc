#include <iostream>
#include <vector>

using namespace std;

int fixd (const vector <int> &v, int e, int d, int x)
{
  if (e > d) return -1;
  if (e == d) 
  {
    if (v[e] + x == e + 1) return e+1;
    return -1;
  }
  int m = (e+d)/2;
  if (v[m] + x < m + 1) return fixd (v,m+1,d,x);
  return fixd (v,e,m,x);
}

void read (vector <int> &v)
{
  for (int i = 0; i < v.size(); ++i) cin >> v[i];
}

int main ()
{
  int cont = 1;
  int n,m;
  while (cin >> n)
  {
    vector <int> S(n);
    read(S);
    cin >> m;
    vector <int> f(m);
    read(f);
    cout << "Sequence #" << cont << endl;
    for (int i = 0; i < f.size(); ++i)
    {
      int oc = fixd(S,0,S.size()-1,f[i]);
      if (oc < 0) cout << "no fixed point for " << f[i] << endl;
      else cout << "fixed point for " << f[i] << ": " << oc << endl;
    }
    cout << endl;
    ++cont;
  }
}