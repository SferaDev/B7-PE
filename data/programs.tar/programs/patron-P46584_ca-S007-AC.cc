#include <vector>
#include <iostream>

using namespace std;

vector<double> diferencia(const vector<double> &v1,const vector<double> &v2)
{
  int n = v1.size();
  int m = v2.size();
  int i,j,k;
  i = j = k = 0;
  
  vector<double> v3(n);
  while(i<n and j<m){
    if(v1[i] == v2[j]) ++i;
    else if(v1[i] > v2[j]) ++j;
    else{
      if(i == 0 or v1[i] != v1[i-1]){
	v3[k] = v1[i];
	++i;
	++k;
      }
      else if(v1[i] == v1[i-1]) ++i;
    }
  }
  while(i<n){
    if(i==0 or v1[i] != v1[i-1]){
      v3[k] = v1[i];
      ++i;
      ++k;
    }
    else ++i;
  }
  vector<double> re(k);
  for(i=0;i<k;++i){
    re[i] = v3[i];
  }
  return re;
}