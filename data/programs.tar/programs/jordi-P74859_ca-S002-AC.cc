#include <iostream>

using namespace std;

int main (){
  int n;
  while (cin >> n){
    int x, cont;
    bool encontrado = false;
    cont =0;
    cin >> x;
    while ( x!=-1){
      ++cont;
      if ( cont == n ){
	cout << "A la posicio " << n << " hi ha un " << x << "." <<  endl;
	encontrado= true;
      }
      cin>> x;
    }
    if (not encontrado) cout << "Posicio incorrecta." << endl;
  }
}