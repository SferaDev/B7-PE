#include <iostream>
using namespace std;

//Pre: Undefined ints
//Post: Count positive, negative and total
int main() {
  // Init the counters
  int cTotal, cPositive, cNegative;
  cTotal = cPositive = cNegative = 0;
  
  // Init and read the ints
  int x;
  while (cin >> x) {
    ++cTotal;
    if (x > 0) {
      ++cPositive;
    } else if (x < 0) {
      ++cNegative;
    }
  }
  
  // Print positive count
  cout << "Pos: " << cPositive << endl;
  // Print negative count
  cout << "Neg: " << cNegative << endl;
  // Print total count
  cout << "Tot: " << cTotal << endl;
}