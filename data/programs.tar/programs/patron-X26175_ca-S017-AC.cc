#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b)
{
  int dni = est.consultar_DNI();
  int index = cerca_dicot(vest,0,nest-1,dni);
  
  b = (dni == vest[index].consultar_DNI());

  if(not b){
    ++nest;
    for(int i = nest-1; i > index; --i)
      vest[i] = vest[i-1];
    vest[index] = est;
    
    if(vest[index].te_nota())
      incrementar_interval(vest[index].consultar_nota());
  }
}

void Cjt_estudiants::esborrar_estudiant(int dni, bool& b)
{
  b = false;
  int i=0;
  while(i<nest and not b){
    if(vest[i].consultar_DNI() == dni)
      b = true;
    else ++i;
  }
  if(b){
    if(vest[i].te_nota())
      decrementar_interval(vest[i].consultar_nota());
    for(int j = i; j< nest-1;++j){
      vest[j]=vest[j+1];
    }
    --nest;
  }
}