#include <iostream>

using namespace std;

struct Racional{
  int num, den;
};

int mcd(int a, int b)
{
  while(b!=0){
    int r=a%b;
    a = b;
    b = r;
  }
  return a;
}


Racional racional(int n, int d)
{
  Racional rnor;
  
  if (n==0){ //Numerador = 0
    rnor.den = 1;
    rnor.num = 0;
    return rnor;
  }
  else {
    
    int maxmcd=mcd(n,d);
    
    rnor.num = n/maxmcd;
    rnor.den = d/maxmcd;
    
    if (rnor.den<0){
      rnor.den*=-1;
      if (rnor.num>0)
	rnor.num*=-1;
    }
  }
  return rnor;
}

Racional suma(const Racional& a, const Racional& b)
{
  int mcm = (a.den * b.den) / mcd(a.den, b.den);
  int n1 = a.num * (mcm/a.den);
  int n2 = b.num * (mcm/b.den);
  return racional(n1+n2,mcm);
}

Racional resta(const Racional& a, const Racional& b)
{
  int mcm = (a.den * b.den) / mcd(a.den, b.den);
  int n1 = a.num * (mcm/a.den);
  int n2 = b.num * (mcm/b.den);
  return racional(n1-n2,mcm);
}

Racional producte(const Racional& a, const Racional& b)
{
  int n1 = a.num * b.num;
  int n2 = a.den * b.den;
  return racional (n1,n2);
}

Racional divisio(const Racional& a, const Racional& b)
{
  int n1 = a.num * b.den;
  int n2 = a.den * b.num;
  return racional(n1,n2);
}

void suma_un(Racional& r)
{
  r.num+=r.den;
}


int main() {
  Racional a, b;
  cin >> a.num >> a.den;
  a = racional(a.num, a.den);
  if (a.den != 1) cout << a.num << "/" << a.den;
  else cout << a.num;
  cout << endl;
  string s;
  while (cin >> s) {
    cin >> b.num >> b.den;
    Racional resultado;
    resultado = racional(b.num, b.den);
    if (s == "suma") resultado = suma(a,b);
    else if (s == "resta") resultado = resta(a,b);
    else if (s == "multiplica") resultado = producte(a,b);
    else resultado = divisio(a,b);
    if (resultado.den != 1) cout << resultado.num << "/" << resultado.den;
    else cout << resultado.num;
    cout << endl;
    a = resultado;
  }
}