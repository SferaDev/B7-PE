#include <iostream>
#include <string>

using namespace std;

int main()
{
  cout.setf(ios::fixed); 
  cout.precision(2);
  double n, p=0, v, x, y, z, g, gt;
  cin>>n;
  y=0;
  z=0;
  while (n>=1)
  {
    cin>>x;
    y=(x*x)+y;
    z=z+x;
    n=n-1;
    p++;
  }
  v=(1/(p-1))*(y);
  g=(1/(p*(p-1)))*(z*z);;
  gt= v-g;
  cout<< gt << endl;
}