#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int main (){
    cout.setf(ios::fixed); 
    cout.precision(4);
    double c, i, t, f;
    string a;
    cin>>c>>i>>t>>a;
    
    if(a=="simple"){
        i=i/100;
        f=c+i*t*c;
    }else if (a=="compost"){
        i=i/100;
        double l=pow((1+i),t);
  	f=c*l;
    }
    cout<<f<<endl;
}
