#include <iostream>
using namespace std;

int main() {
    char x;
    cin >> x;

    // Check uppercase/lowercase
    if (isupper(x)) {
        cout << "uppercase" << endl;
    } else {
        cout << "lowercase" << endl;
    }

    // Check vowel/consonant
    x = tolower(x);
    if (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u') {
        cout << "vowel" << endl;
    } else {
        cout << "consonant" << endl;
    }
}
