#include <iostream>
using namespace std;

int main() {
  char a;      
  cin >> a;      
  if ((a >= 97) && (a <= 122)) { //Min
    cout << "minuscula" << endl;
    if ((a == 97) || (a == 101) || (a == 105) || (a == 111) || (a == 117)) {
      cout << "vocal" << endl;  
    }
    else {cout << "consonant" << endl;}    
  }
  if ((a >= 65) && (a <= 90)){
    cout << "majuscula" << endl;
    if ((a == 65) || (a == 69) || (a == 73) || (a == 79) || (a == 85)) {
      cout << "vocal" << endl;  
    }
    else {cout << "consonant" << endl;}   
  }                                
} 
