#include <iostream>
#include <vector>

using namespace std;

int n;
vector<bool> sol(n);


void escriu(){
  
  for(int i = 0; i < n; ++i){
    if(i == 0) cout << sol[i];
    else cout << ' ' << sol[i];
  }
  cout << endl;
  
}

void zeros_i_uns(int i){
  if(i == n) escriu();
  else{
    sol[i] = 0; zeros_i_uns(i+1);
    sol[i] = 1; zeros_i_uns(i+1);
  }
}

int main(){
  //n = atoi(argv[1]);
  cin >> n;
  zeros_i_uns(0);
}