#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool comp(int a, int b){
	if(b < a) return true;
	else return false;
}

void llegir(vector <int> &v){
	for(int i=0; i<v.size(); ++i){
		cin >> v[i];
	}
}

void escriure(const vector <int> &v)
{
	for(int i=0; i<v.size(); ++i){
		cout << v[i];
		if(i<v.size()-1) cout << ' ';
	}
	cout << endl;
}

int main()
{
	int n;
	while(cin >> n){
		vector <int> v(n);
		llegir(v);
		sort(v.begin(),v.end(),comp);
		escriure(v);
	}
}
