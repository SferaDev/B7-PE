#include <iostream>
using namespace std;

bool es_primer (int n) {
  int divisor = 2;
  bool primer = (n != 1);
  if (n == 0) return false;
  while (primer and divisor*divisor <= n) {
    primer = n%divisor != 0;
    ++divisor;
  }
  return primer;
}

int sumxif(int n) {
  if (n == 0) return 0;
  return n%10 + sumxif(n/10);
}

bool es_primer_perfecte(int n){
  if (n < 10 and es_primer(n)) return true;
  if (!es_primer(n)) return false;
  return es_primer_perfecte(sumxif(n));  
}

int main () {
  int n;
  while (cin >> n) {
    cout << es_primer_perfecte(n) << endl;
  }
}
