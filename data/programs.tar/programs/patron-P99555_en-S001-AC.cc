#include <iostream>
#include <vector>

using namespace std;

bool magico (const vector< vector<int> >& p, int suma_fila_comparar) {
    if (p.size() == 1) return true;
    else {
        int suma_diagonal_izq_a_der = 0;
        int suma_diagonal_der_a_izq = 0;
        int variable_para_calcular_indice_diagonal_der_a_izq = p.size();
        for (int i = 0; i < p.size(); ++i) {
            int suma_filas = 0;
            int suma_columnas = 0;
            for (int j = 0; j < p.size(); ++j) {
                suma_filas += p[i][j];
                suma_columnas += p[j][i];
                if (i == j) suma_diagonal_izq_a_der += p[i][j];
                if (j == variable_para_calcular_indice_diagonal_der_a_izq - 1) {
                    suma_diagonal_der_a_izq += p[i][j];
                    --variable_para_calcular_indice_diagonal_der_a_izq;
                }
            }
            if (suma_filas != suma_fila_comparar) return false;
            if (suma_columnas != suma_fila_comparar) return false;
        }
        if (suma_diagonal_izq_a_der != suma_fila_comparar) return false;
        else if (suma_diagonal_der_a_izq != suma_fila_comparar) return false;
    }
    return true;
}

int main(){
    int n;
    while (cin >> n) {
        vector< vector<int> > Matrix (n, vector<int> (n));
        bool primer = true;
        int suma_fila_comparar = 0;
        bool no_sirve = false;
        int valor = n*n;
        vector<int> apariciones(valor);
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                cin >> Matrix[i][j];
                if (primer) suma_fila_comparar += Matrix[i][j];
                if (Matrix[i][j] > valor) no_sirve = true;
                ++apariciones[Matrix[i][j]];

            }
            for (int j = 0; j < valor; ++j) {
                    if (apariciones[j] > 1) no_sirve = true;
            }
            primer = false;
        }
        bool resultado = magico(Matrix, suma_fila_comparar);
        if (resultado and not no_sirve) cout << "yes" << endl;
        else cout << "no" << endl;
    }
}