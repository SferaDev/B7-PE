#include <iostream>
#include <vector>
#include <string>

using namespace std;



typedef vector<vector<char> > Matriu;

int posicio (string par, const vector <string>& diccionari, int esq, int dre){
  if (esq>dre)return -1;
  int pos =(esq+dre)/2;
  if (par<diccionari[pos])return posicio (par, diccionari,esq,pos-1);
  if (par>diccionari[pos]) return posicio (par, diccionari, pos+1,dre);
  return pos;
}

void comprobar_taulell(const Matriu& paraules, int k){
  bool magic=true;
  int i, cont;
  cont=0;
  while (cont<k and magic){
    i=0;
    while (i<k and magic){
      if (paraules[i][cont]!=paraules[cont][i])magic = false;
      ++i;
    }
    ++cont;
  }
  if (magic) cout << "SI"<<endl;
  else cout<<"NO"<<endl;
}

void llegir_matriu (Matriu& paraules, int k,const vector <string>& diccionari, int n, bool& magic){
  string par;
  for (int i=0;i<k;++i){
      cin>>par;
      bool trobat=false;
      int dre, esq;
      dre= n;
      esq=0;
      int x=posicio (par, diccionari,esq, dre);
      if (x>=0)trobat=true;
      if (not trobat) magic=false;
      if (magic){
	int p=0;
	for (int j=0;j<k;++j){
	  paraules[i][j]=par[p];
	  ++p;
	}
      }
    }
}




int main (){
  int n;
  cin >> n;
  vector <string> diccionari (n);
  for (int i=0;i<n;++i)cin >> diccionari[i];
  int k;
  while (cin >> k and k!=0){
    Matriu paraules (k, vector <char> (k));
    bool magic = true;
    llegir_matriu(paraules,k,diccionari,n,magic);
    if (magic) comprobar_taulell(paraules,k);
    else cout << "NO"<<endl;
  }
}