#include <iostream>
using namespace std;

/* SPEC
 * 
 * in: The input is a non-zero natural number 0 < n < 2^31.
 * 
 * out: The output consists of two lines. The first line shows
 * the sum of digits in odd positions and the sum of digits in
 * even positions. The second line indicates the relationship
 * among the two quantities, including the exact relation when
 * one is a multiple of the other. 
 * 
 */

 int main() {     
    // Init cin value
    char input;
    
    // Init the counters
    int x, y;
    x = y = 0;
    
    // Init the switch
    bool odd = false;
    while (cin >> input) {
        if (odd) {
            x += (input - '0');
        } else {
            y += (input - '0');
        }
        odd = !odd;
    }
    
    // Print the results
    if (odd && (x%y == 0 || y%x == 0)) {
        cout << y << ' ' << x << endl;
        if (x == 0) cout << x << " = " << 0 << " * " << y;
        else if (x > y) cout << x << " = " << x/y << " * " << y;
        else cout << y << " = " << y/x << " * " << x;
    } else if (!odd && (x%y == 0 || y%x == 0)) {
        cout << x << ' ' << y << endl;
        if (x == 0) cout << x << " = " << 0 << " * " << y;
        else if (x > y) cout << x << " = " << x/y << " * " << y;
        else cout << y << " = " << y/x << " * " << x;
    } else {
        if (odd) cout << y << ' ' << x << endl;
        else cout << x << ' ' << y << endl;
        cout << "res";
    }
    cout << endl;
}