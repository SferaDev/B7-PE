#include <iostream>

using namespace std;

int sum_min_max (int x, int y, int z){
  int max, min, suma;
  if (x>=y and x>=z){
    max=x;
    if ( y>z) min = z;
    else min=y;
  } else if ( y >= x and y>=z){
    max=y;
    if (x>z) min =z;
    else min=x;
  } else if ( z>=x and z>=y){
    max=z;
    if (x>y) min = y;
    else min=x;
  }
  suma=max+min;
  return suma;
}
int main(){
  int suma, a, b, c;
  while (cin >> a >> b >> c){
    suma= sum_min_max (a, b, c);
    cout << suma << endl;
  }
}
