#include <iostream>
#include <vector>
#include <string>
using namespace std;

void intercambia(string& a, string& b) {
	string c=a;
	a=b;
	b=c;
}

int pos_maxim(const vector<string>& v, int m) {
	int pos=0;
	for (int i=1; i<=m; ++i) {
		if (v[i]>v[pos]) {
			pos=i;
		}
	}
	return pos;
}

void ordenacio_per_seleccio(vector<string>& v) {
	int n=v.size()-1;
	for (int i=n; i>0; --i) {
		int pos=pos_maxim(v, i);
		intercambia(v[i], v[pos]);
	}
}	

int main() {
	int n;
	while (cin >> n) {
		vector<string> v(n);
		for (int i=0; i<n; ++i) cin >> v[i];
		ordenacio_per_seleccio(v);
		for (int i=0; i<n; ++i) {
			cout << v[i];
			if (i!=n-1) cout << ",";
		}
		cout << endl;
	}
}
