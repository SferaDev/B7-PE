#include <iostream>
#include <cmath>

using namespace std;

int maximo(int x)
{
  if (x<10) 
    return x;
  return max(x%10,maximo(x/10));
}

int minimo (int x)
{
  if (x<10)
    return x;
  return min(x%10,minimo(x/10));
}

void digit_maxim_i_minim (int n, int& maxim, int& minim)
{
  maxim=maximo(n);
  minim=minimo(n);
  
}