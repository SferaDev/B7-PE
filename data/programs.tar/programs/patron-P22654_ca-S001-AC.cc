#include <iostream>
 
using namespace std;
 
void descompon(int n, int& h, int& m, int& s) {
    s = 0;
    m = 0;
    h = 0;
    m = m + n/60;
    s = n%60;
    h = h + m/60;
    m = m%60;
}
 
int main() {
    int n;
    cin >> n;
    int h = 0, m = 0, s;
    descompon(n, h, m, s);
    cout << h << ':' << m << ':' << s << endl;
}
