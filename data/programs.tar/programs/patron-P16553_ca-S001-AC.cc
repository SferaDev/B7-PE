#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <list>
using namespace std;
int n;
int costos[3000][3000];
list<int> sol;
vector<bool> usat;
int accm;
int valid;
 
void pinta(int v,int k){
    if(k == n){
        sol.push_back(0);
        list<int>::iterator it = sol.begin();
        while( it != sol.end() ){
            cout << *it << ' ';
            ++it;
        }
        cout << '(' << accm << ')' << endl;
        sol.pop_back();
    }else if(valid > 0 and k < n-1){
        sol.push_back(v);
        usat[v] = true;
        if(v!=0 and costos[v][0] != 0) --valid;
        for(int i = 1 ; i < n ; ++i){
            if(not usat[i] and costos[v][i] != 0){
                accm += costos[v][i];
                pinta(i,k+1);
                accm -= costos[v][i];
            }
        }
        if(v!=0 and costos[v][0] != 0) ++valid;
        sol.pop_back();
        usat[v] = false;
    }else if(k == n-1 and valid == 1){
        sol.push_back(v);
        accm += costos[v][0];
        pinta(0,n);
        accm -= costos[v][0];
        sol.pop_back();
    }
}
 
int main (){
    while(cin >> n){
        accm = 0;
        valid = 0;
        sol = list<int>();
        usat = vector<bool>(n,false);
        for(int i = 0 ; i < n ; ++i)
            for(int j = 0 ; j < n ; ++j){
                cin >> costos[i][j];
                if(j == 0 and costos[i][j] != 0) ++valid;
            }
        pinta(0,0);
        cout << string(20,'-') << endl;
    }
}