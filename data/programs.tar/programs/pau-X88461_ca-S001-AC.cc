#include <iostream>
#include <vector>
using namespace std;

void max_min (const vector <int> &a, int& max, int& min) {
  max = a[0];
  min = a[0];
  int size = a.size();
  for (int i = 1; i < size; ++i) {
    if (a[i] > max) max = a[i];
    if (a[i] < min) min = a[i];
  }
}

void llegeix_vector (vector<int> &a) {
  int m = a.size();
  for (int i = 0; i < m; ++i) cin >> a[i];
}
  

int main () {
  int n; cin >> n;
  vector<int> a(n);
  llegeix_vector(a);
  int max;
  int min;
  max_min(a,max,min);
  cout << max << ' ' << min << endl;
}