#include <iostream>
using namespace std;

int main() {
  int A, B, C;
  int a, b, c;       // A < B, B < C
  char A1, B1, C1;     
  cin >> A >> B >> C;
  cin >> A1 >> B1 >> C1;
  if (A > B && A > C) {
    c = A;
    if (C > B) {
      b = C;
      a = B;  
    }
    if (B > C) {
      b = B;
      a = C;        
    }    
  }
  if (B > A && B > C) {
    c = B;
    if (A > C) {
      b = A;
      a = C;  
    }
    if (C > A) {
      b = C;
      a = A;        
    }
  }      
  if (C > B && C > A) {
    c = C;
    if (A > B) {
      b = A;
      a = B;  
    }
    if (B > A) {
      b = B;
      a = A;        
    } 
  }             
  if (A1 > B1 && A1 > C1) {
    if (C1 > B1) { cout << c << " " << a << " " << b << endl; } // CAB
    if (B1 > C1) { cout << c << " " << b << " " << a << endl; } // CBA   
  }
  if (B1 > A1 && B1 > C1) {
    if (A1 > C1) { cout << b << " " << c << " " << a << endl; } // BCA
    if (C1 > A1) { cout << a << " " << c << " " << b << endl; } // ACB
  }      
  if (C1 > B1 && C1 > A1) {
    if (A1 > B1) { cout << b << " " << a << " " << c << endl; } // BAC   
    if (B1 > A1) { cout << a << " " << b << " " << c << endl; }                                                        
  }
}
