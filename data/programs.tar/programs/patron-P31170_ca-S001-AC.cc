#include <iostream>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int cont = 1;
	while(cont <= 10){
		cout << n << "*" << cont << " = " << n*cont << endl;
		++cont;
	}
}
