#include <iostream>

using namespace std;

int suma_divisors(int n)
{
   if (n==1) return 0;
   else {
    int i=2, sum=1;
    while (i*i<=n){
        if (n%i==0 and i*i==n) sum+=i;
        else if (n%i==0) sum+=i+n/i;
        i+=1;
    }
    return sum;
   }
}

int main ()
{
    int n,k;
    while (cin>>n){
    cout<<n<<": ";
    if (n>3){
        k=suma_divisors(n-2)+suma_divisors(n)+suma_divisors(n+2);
        if (k%n!=0) cout<<"res";
        else if (k/n==1) cout<<"popiropis";
        else cout<<k/n<<"-popiropis";
    }
    else cout<<"res";
    cout<<endl;
    }
}
