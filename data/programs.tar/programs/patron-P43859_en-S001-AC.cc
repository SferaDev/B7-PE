#include <iostream>
#include <vector>
#include <queue>

#define infinit -1

using namespace std;

typedef pair<double, int> WArc; // weighted arc
typedef vector<vector<WArc>> WGraph; // weighted digraf

int dijkstra(const WGraph& G, int s, int x)
{
	int n = G.size();
	vector<double> d(n, infinit); d[s] = 0;
	vector<bool> S(n, false);
	
	priority_queue<WArc, vector<WArc>, greater<WArc> > Q;
	Q.push(WArc(0, s));

	while (not Q.empty()){
		int u = Q.top().second; Q.pop();
		if (not S[u]){
			S[u] = true;
			for (WArc a : G[u]){
				int v = a.second;
				double c = a.first;
				if ((d[v] > d[u] + c) or d[v] == infinit){
					d[v] = d[u] + c;
					Q.push(WArc(d[v], v));
				}
			}
		}
	}
	return d[x];
}


void read (WGraph& G){
	int m; cin >> m;
	for (int i = 0; i < m; ++i){
		int u,v;
		double c;
		cin >> u >> v >> c;
		G[u].push_back(make_pair(c,v));
	}
}


int main (){
	int n;
	while (cin >> n)
	{
		WGraph G(n);
		read(G);
		int x,y; cin >> x >> y;
		int c = dijkstra(G, x, y);
		if (c != -1) cout << c << endl;
		else cout << "no path from " << x << " to " << y << endl;
	}
}