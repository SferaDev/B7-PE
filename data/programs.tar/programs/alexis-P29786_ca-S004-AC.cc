#include <iostream>
using namespace std;

bool es_potencia_de_3(int n) {
    if (n == 0) return false;
    else if (n == 1) return true;
    while(n%3 == 0 && n != 3) {
        n = n/3;
    }
    return n == 3;
}