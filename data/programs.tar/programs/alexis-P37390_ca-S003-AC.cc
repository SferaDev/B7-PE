#include <iostream>
#include <vector>
using namespace std;

typedef vector< vector<int> > Matriu;

Matriu producte(const Matriu& a, const Matriu& b) {
    int m = a.size();
    Matriu result(m, vector<int>(m));
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < m; ++j) {
            int product = 0;
            for (int k = 0; k < m; ++k) {
                product += (a[i][k] * b[k][j]);
            }
            result[i][j] = product;
        }
    }
    return result;
}