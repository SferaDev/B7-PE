static int freq_inm(node_arbreGen* n, const T& x){
	int contador = 0;
	if (n == NULL) contador += 0;
	else {
		if (n->info == x) contador += 1;
		for (int i = 0; i < int(n->seg.size()); ++i){
			contador += freq_inm (n->seg[i],x);
		}
		
	}
	return contador;
}

int freq(const T& x) const
/* Pre: cert */
/* Post: el resultat indica el nombre d'aparicions de x en el p.i. */
{
	node_arbreGen* n = primer_node;
	return freq_inm(n, x);
}