#include <iostream>
using namespace std;

int mcd(int a , int b ) {
  if (a == b) return a;
  if (a == 0) return b;
  if (b == 0) return a;
  while (b != 0) {
    int r = a%b;
    a = b;
    b = r;
  }
  return a;
}


int main () {
  int x;
  int y;
  cin >> x >> y;
  cout << mcd (x, y) << endl;
}