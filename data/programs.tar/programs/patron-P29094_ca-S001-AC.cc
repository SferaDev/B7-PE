#include <iostream>
#include <vector>
using namespace std;
 
int posicio_maxim(const vector<double>&v,int m){
        double max = v[0];
        int pmax = 0;
        for( int i = 0; i <= m; ++i){
                if( max < v[i]){
                        max = v[i];
                        pmax = i;
                }
        }
        return pmax;
}
 
