#include <iostream>

using namespace std;

bool rodo (int n, int b){
  bool rodo= false;
  int suma,cont;
  suma=cont=0;
  while ( n>0){
    ++cont;
    suma+=n%b;
    n=n/b;
  }
  if ( cont == suma ) rodo = true;
  return rodo;
}

int main (){
  int n, b, cont;
  cont=0;
  bool rodo1= false;
  while ( cont!=2 and cin >> n >> b) {
    rodo1= rodo( n, b);
    if ( rodo1 ) ++cont;
  }
  if (cont==2 ) cout << "SI" << endl;
  else cout << "NO" << endl;
}