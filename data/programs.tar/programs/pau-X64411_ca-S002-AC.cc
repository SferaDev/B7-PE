#include <iostream>
#include "Arbre.hh"

using namespace std;

bool i_quasi_coincidents (Arbre<int> &a, Arbre<int> &b, bool &toquen)
{
  if (a.es_buit() and b.es_buit()) return true;
  if (a.es_buit() and not b.es_buit()) {
    if (toquen) {
      toquen = false;
      Arbre <int> be;
      Arbre <int> bd;
      b.fills(be,bd);
      return be.es_buit() and bd.es_buit();
    }
    else return false;
  }
  if (not a.es_buit() and b.es_buit()) {
    if (toquen) {
      toquen = false;
      Arbre <int> ae;
      Arbre <int> ad;
      a.fills(ae,ad);
      return ae.es_buit() and ad.es_buit();
    }
    else return false;
  }
  else { 
    Arbre <int> ae;
    Arbre <int> ad;
    Arbre <int> be;
    Arbre <int> bd;
    a.fills(ae,ad);
    b.fills(be,bd);
    bool r;
    r = (i_quasi_coincidents(ae,be,toquen) and i_quasi_coincidents(ad,bd,toquen));
    return r;
  }    
}


/* Pre: a=A, b=B */
/* Post: el resultat indica si A i B son quasi coincidents */
bool quasi_coincidents (Arbre<int> &a, Arbre<int> &b)
{
  bool toquen = true;
  return i_quasi_coincidents(a,b,toquen);
}
