#include <iostream>
using namespace std;

int main (){
int pos, n, cont;
bool correct;
while (cin>>pos){
	cont=1;
	correct= false;
	while (cin>>n and n!=-1){
		if (cont==pos){
			correct=true;
			cout<<"A la posicio "<<pos<<" hi ha un "<<n<<"."<<endl;
			}++cont; 
		}if (not correct) cout<<"Posicio incorrecta."<<endl;
	}
}
