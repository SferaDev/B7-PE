#include <iostream>
using namespace std;

int main (){
    int number;
    while(cin >> number){
    int contador;
    contador = 0;
    bool signe;
    int actual;
    cin >> actual;
    if (actual < 0){
        signe = false;
        --number;
    } else {
         signe = true;
        --number;
    }
    while (number != 0){
        cin >> actual;
        if (actual < 0 and not signe){
            --number;
            signe = false;
        }
        else if (actual < 0 and signe){
            ++contador;
            --number;
            signe = false;
        }
        else if (actual > 0 and not signe){
            ++contador;
            --number;
            signe = true;
        }
        else if (actual > 0 and signe){
            --number;
            signe =true;
        }
    }
    cout << contador << endl;
    }
}