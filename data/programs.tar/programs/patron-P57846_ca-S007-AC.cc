#include <iostream>
#include <cmath>

using namespace std;

int max2(int a,int b)
{
  if (a>b) return a;
  return b;
}
