#include<iostream>
using namespace std;

int main () {
    int a,d,h,m,s;
    cin >>a>>d>>h>>m>>s;
    int l=a*365;
    int n=d+l;
    int p=(n*24)+h;
    int t=(p*60)+m;
    int o=(t*60)+s;
    cout<< o <<endl;
}
