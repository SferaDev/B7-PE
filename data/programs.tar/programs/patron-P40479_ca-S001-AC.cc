#include <iostream>
#include <vector>

using namespace std;

typedef vector < vector <char> > graph;
typedef vector < vector <bool> > visit;

void pinta (graph &g, visit &vis, int i, int j, char c){

	if (not vis[i][j]){
		
		vis[i][j] = true;
		
		if(g[i][j] == '#') return;
		
		g[i][j] = c;
		
		int n = g.size();
		int m = g[0].size();
		
		if (i > 0) pinta(g,vis,i-1,j,c);
		if (i < n-1) pinta(g,vis,i+1,j,c);
		if (j > 0) pinta(g,vis,i,j-1,c);
		if (j < m-1) pinta(g,vis,i,j+1,c);
	}
}

void read (graph &g, vector <pair <int,int>> &v){

	int n = g.size();
	int m = g[0].size();
	
	for (int i = 0; i < n; ++i){
		for (int j = 0; j < m; ++j){
			cin >> g[i][j];
			if (g[i][j] != '#' and g[i][j] != '.') v.push_back(make_pair(i,j));
		}
	}
}

void print (const graph &g){
	int n = g.size();
	int m = g[0].size();
	for (int i = 0; i < n; ++i){
		for (int j = 0; j < m; ++j){
			cout << g[i][j];
		}
		cout << endl;
	}
	cout << endl;
}

int main (){
	int n,m;
	while (cin >> n >> m){
	
	graph g(n, vector <char> (m));
	vector <pair <int,int> > v;
	visit vis(n, vector<bool> (m,false));
	
	read(g,v);
	
	for (int i = 0; i < v.size(); ++i) 
		pinta(g,vis,v[i].first,v[i].second,g[v[i].first][v[i].second]);
	print(g);
	}
}