#include<iostream>
#include<vector>
#include<string>
using namespace std;
 
int main(){
        string num;
        while(cin >> num){
                int n = num.length();
                int suma = 0;
                for (int i = 0; i < n; ++i){
                        if (i % 2 != 0) suma = suma + (int(num[i]) - int('0'))*3;
                        else suma = suma + (num[i] - '0');
                }
                int aux = 0;
                int total = suma;
                int total2 = suma;
                if (suma % 10 == 0){
                        suma /= 10;
                        suma = suma % 10;
                }
                else{
                        aux = suma % 10;
                        suma /= 10;
                        suma = suma % 10;
                        ++suma;
                }
                if ((total/10)%10 < suma){
                        total = total - aux + 10;
                }
                suma = suma * 10;
                total = total - total2;
                cout << num << total << endl;
        }
}
