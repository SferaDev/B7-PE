#include <iostream>
#include <vector>

using namespace std;

#define DNAL 4

typedef vector<char>VC;
char dna[4]={'A', 'C', 'G', 'T'};
int n;


void print(const VC& v){
	for(int i = 0; i < n; ++i)
		cout << v[i];
	cout << endl;
}


void permuta(int i,VC& res){
	if(i==n)
		print(res);
	else{
		for(int j = 0;j < DNAL; ++j){
		res[i] = dna[j];
		permuta(i+1,res);
		}
	}
}


int main(){
	cin>>n;
	VC res(n);
	permuta(0,res); 
}