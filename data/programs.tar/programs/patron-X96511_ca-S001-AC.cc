#include "ArbreG.hh"


static int freq_imm(node_arbreGen* n, const T& x) {
    if (n != NULL) {
        int suma = 0;
        if(n->info == x) ++suma;
        int i = 0;
        while (i < int(n->seg.size())) {
            suma += freq_imm(n->seg[i], x);
            ++i;
        }
        return suma;
    }
    return 0;
}


/* Pre: cert */
/* Post: el resultat indica el nombre d'aparicions de x en el p.i. */
int freq(const T& x) const {
    return freq_imm(this->primer_node, x);
}
