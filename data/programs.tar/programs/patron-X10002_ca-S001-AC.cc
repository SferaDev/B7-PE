void esborrar_tots (const T & x)
   /* Pre: par�metre impl�cit = P
    * Post: s'han eliminat del par�metre impl�cit totes les aparicions d'x ( la resta d'elements queda en el
    * mateix ordre que a P); si el punt d'inter�s de P referenciava a una aparici� d'x, passa a referenciar al primer
    * element diferent d'x posterior a aquesta (si no hi ha cap element diferent d'x, passa a la dreta del tot);
    * en cas contrari, el punt d'inter�s no canvia */
{
    node_llista *n = primer_node;
    while(n != NULL){
        if(n->info == x){
            if(n == act) act = n->seg;
            if(n->ant != NULL) (n->ant)->seg = n->seg;
            else primer_node = n->seg;
            if(n->seg != NULL) (n->seg)->ant = n->ant;
            else ultim_node = n->ant;
            node_llista *aux = n->seg;
            delete n;
            --longitud;
            n = aux;
        }
        else n = n->seg;
    }
}
