#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b) {
  int i = nest - 1;
  bool trobat = false;
  int dni = est.consultar_DNI();
  int x = cerca_dicot(vest,0,nest-1,dni);
  b = (dni == vest[x].consultar_DNI());
  if (not b) {
    while (i >= 0 and not trobat) {
      if (dni > vest[i].consultar_DNI()) trobat = true;
      else {
        vest[i+1] = vest[i];
        --i;
      }
    }
    ++nest;
    vest[i+1]=est;
    if (est.te_nota()) incrementar_interval(est.consultar_nota());
  } 
}

void Cjt_estudiants::esborrar_estudiant(int dni, bool& b) {
  int x = cerca_dicot(vest,0,nest-1,dni);
  if (dni != vest[x].consultar_DNI()) b = false;
  else b = true;
  if (b) {
    vector <Estudiant> aux(MAX_NEST);
    int i = 0;
    int k = 0;
    if (vest[x].te_nota()) decrementar_interval(vest[x].consultar_nota());
    while (i < x) {
      aux[k] = vest[i];
      ++i; ++k; 
    }
    while (k < nest -1) {
      aux[k] = vest[i+1];
      ++i; ++k;
    }
    vest = aux;
    --nest;
  }   
}
