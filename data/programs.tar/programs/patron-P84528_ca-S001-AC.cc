
#include <iostream>
#include <vector>
using namespace std;
 
typedef vector<char> Fila;
typedef vector<Fila> Matriu;
 
bool enfonsat(Matriu& m, int f, int c){
    int j = c-1; // iterador esquerra
    int k = c+1; // iterador dreta
    bool punte = false, puntd = false;
    bool fora = false;
    int pe, pd;
    while (j >= 0 and k <= m[0].size()-1 and not fora){
        if (m[f][j] == '.'){ // primer punt a lesquerra
            punte = true;
            pe = j; // el guardo en una auxiliar -->
        }
        if (m[f][k] == '.'){ // primer punt a la dreta
            puntd = true;
            pd = k; // --> per despres, en cas denfonsat, passar i posar '.'
        }
        if (punte and puntd) fora = true; // si he trobat els dos '.' i no cap 'V' si sha enfonsat
        // si trobo una 'V' i no he trobat el punt del costat respectiu, no senfonsa
        if ((m[f][j] == 'V' and not punte) or (m[f][k] == 'V' and not puntd)) return false;
        // si no he trobat els punts segueixo movent els iteradors
        if (not punte) --j;
        if (not puntd) ++k;
    }
    // recorro per posar els punts denfonsat
    for (int i = pe+1; i < pd; ++i) m[f][i] = '.';
    return true;    
}
 
int main(){
    int f, c;
    cin >> f >> c;
    Matriu m(f,vector<char>(c));
    for (int i = 0; i < f; ++i){
        for (int j = 0; j < c; ++j) cin >> m[i][j];
    }
    char fila;
    int columna, fil;
    while (cin >> fila >> columna){
        cout << fila << columna << ": ";
        fil = int(fila) - 97;
        if (m[fil][columna] != '.'){
            if (enfonsat(m,fil,columna)) cout << "enfonsat";
            else{
                cout << "tocat";
                m[fil][columna] = 'T';
            }
        }else if (m[fil][columna] == '.') cout << "aigua";
       
        cout << endl;
    }
    cout << endl;
    for (int i = 0; i < f; ++i){
        for (int j = 0; j < c; ++j) cout << m[i][j];
        cout << endl;
    }    
}
