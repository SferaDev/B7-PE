#include <iostream>
 
using namespace std;
 
int main() {
    int n;
    while (cin >> n) {
      
      int suma1 = 0;
      //suma tots el números desde 1 fins n inclós
      for (int i = 1; i <= n; ++i) suma1 += i;
      
      int suma2 = 0;
      //suma tots els m que es van introduïnt
      for (int j = 1; j < n; ++j) {
	
	int m;
	cin >> m;
	suma2 += m;
	
      }
      //Calcula la resta de les dues sumes i el resultat es el número que falta
      cout << suma1 - suma2 << endl;
    }
}
