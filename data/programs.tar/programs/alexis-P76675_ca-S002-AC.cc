#include <iostream>
#include <vector>
using namespace std;

struct Data { int dia, mes, any; };

Data data_llegida() {
    Data input;
    char c;
    cin >> input.dia >> c >> input.mes >> c >> input.any;
    return input;
}

int data_position(const vector<Data>& v, const Data& d) {
    int pos = v.size() / 2;
    while (v[pos].any < d.any) ++pos;
    while (v[pos].any > d.any) --pos;
    while (v[pos].mes < d.mes) ++pos;
    while (v[pos].mes > d.mes) --pos;
    while (v[pos].dia < d.dia) ++pos;
    while (v[pos].dia > d.dia) --pos;
    return pos;
}

int main() {
    vector<Data> input;
    char action;
    while (cin >> action) {
        if (action == 'A') {
            input.push_back(data_llegida());
        } else if (action == 'C') {
            Data d1 = data_llegida();
            Data d2 = data_llegida();
            cout << (data_position(input, d2) - data_position(input, d1)) << endl;
        } else if (action == 'E') {
            input.pop_back();
        }
    }
}