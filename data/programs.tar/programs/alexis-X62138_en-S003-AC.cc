#include <iostream>
#include <string>
using namespace std;

int char_position(char c) {
    if (c >= 'a' and c <= 'z') return c - 'a';
    else if (c >= 'A' and c <= 'Z') return c - 'A';
    return -1;
}

void make_uppercase_lowercase(const string& T) {
    string s;
    while (cin >> s) {
        for (int i = 0; i < s.size(); ++i) {
            int pos = char_position(s[i]);
            if (pos != -1) {
                if (T[pos] == 'L') cout << char(pos + 'a');
                else if (T[pos] == 'U') cout << char(pos + 'A');
            }
        }
    }
    cout << endl;
}

int main() {
    string T; 
    cin >> T;
    make_uppercase_lowercase(T);
}