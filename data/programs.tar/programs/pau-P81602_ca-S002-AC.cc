#include <iostream>
#include <vector>
using namespace std;

int max (const vector <double> v, int m) {
  int pos = 0;
  for (int i = 0; i <= m; ++i) if (v[i] > v[pos]) pos = i;
  return pos;
}

void intercambia (double& a, double& b) {
  double aux = a;
  a = b;
  b = aux;
}

void ordena_per_seleccio(vector<double>& v, int m) {
  if (m > 0) {
    int k = max(v,m);
    intercambia (v[k],v[m]);
    ordena_per_seleccio(v,m-1);  
  }
}

int main () {

}
