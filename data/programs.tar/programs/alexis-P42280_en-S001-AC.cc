#include <iostream>
using namespace std;

/* SPEC
 * 
 * in: Input begins with the number of rows r and the number of
 * columns c. Follow r lines, each one with c characters between
 * ‘0’ and ‘9’.
 * 
 * out: Print the total number of coins on the board.
 * 
 */

int main() {
    // Read and store rows and columns
    int r, c;
    cin >> r >> c;
    
    // Init the counter
    int count = 0;
    
    // Loop through the rows and columns
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            char input;
            cin >> input;
            count += input - '0';
        }
    }
    
    // Print the results
    cout << count << endl;
}