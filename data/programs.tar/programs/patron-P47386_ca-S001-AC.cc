#include <iostream>
#include <map>

using namespace std;

typedef map <string,string> graph;

graph liats;


void print(){
	cout << "PARELLES:" << endl;
	for (auto p : liats) if (p.second != "" and p.first < p.second) cout << p.first << ' ' << p.
	second << endl;
	cout << "SOLS:" << endl;
	for (auto p : liats) if (p.second == "") cout << p.first << endl;
	cout << "----------" << endl;
}


void update (){
	string x,y;
	cin >> x >> y;
	if (liats[x] != "") liats[liats[x]] = "";
	if (liats[y] != "") liats[liats[y]] = "";
	liats[x] = y;
	liats[y] = x;
}


int main (){
	string op;
	while (cin >> op){
		if (op == "info") print();
		else update();
	}
}
