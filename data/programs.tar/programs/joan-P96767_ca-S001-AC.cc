#include <iostream>
#include <cmath>
using namespace std;
//INP:  real number x followed by the description of the polynomial p(z): the real coefficients c0, c1, …, cn 
//in this order. (The first sample input/output corresponds to the evaluation of p(z) = 3 + 4z + 5z2 at x = 2.)
//OUT: p(x) with 4 digits after the decimal point.
int main() {
    cout.setf(ios::fixed); 
    cout.precision(4);
    
    double n,o,suma,p;//number N, number O, sum and power
    cin>>n;
    suma=0;
    p=0;
    while (cin>>o){
        suma=suma + o*pow(n,p);
        ++p;
       
       }
      cout<<suma<<endl;
      
}