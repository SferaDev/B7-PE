#include <iostream>
using namespace std;

int fatten(int x) {
    if (x < 10) return x;
    int next = fatten(x/10);
    if (next%10 > x%10) return next*10 + next%10;
    else return next*10 + x%10;
}