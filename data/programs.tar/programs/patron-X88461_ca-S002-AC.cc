#include <iostream>
#include <vector>

using namespace std;

void llegir_vector(vector<int>& v)
{
  int n=v.size();
  for(int i=0; i<n;++i){
    cin >> v[i];
  }
}

void max_i_min_de_v(vector<int>& v,int &max, int &min)
{
  int n=v.size();
  for(int i=1;i<n;++i){
    if (v[i]>max) max=v[i];
    if (v[i]<min) min=v[i];
  }
}


int main()
{
  int n;
  cin >> n;
  vector<int> v(n);
  llegir_vector(v);
  int max=v[0];
  int min=v[0];
  max_i_min_de_v(v,max,min);
  cout << max << ' ' << min << endl;
}
