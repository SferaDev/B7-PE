static T max_suma_cami_recu(node_arbreGen* n, T &suma){
T sumaparc = 0;
	if (n == NULL) suma = 0;
	else {
		sumaparc = n->info;
		int k = (n->seg).size();
		vector<T> sumaaux (k, 0);
		for (int i = 0; i < k; ++i){
			sumaaux[i] = max_suma_cami_recu(n->seg[i], sumaaux[i]);
		}
		int max;
		if (k != 0){
			max = sumaaux[0];
			for (int i = 1; i < k; ++i){
				if (max < sumaaux[i]) max = sumaaux[i];
			}
		}
		else max = 0;
		sumaparc += max;
	}
	return sumaparc;
}

T max_suma_cami() const 
/* Pre: el parametre implicit no es buit */ 
/* Post: el resultat es la suma del cami de suma maxima del parametre implicit */
{
	T suma = 0;
	return max_suma_cami_recu(primer_node, suma); 
}