#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#define infinit -1

using namespace std;

typedef pair<double, int> WArc; // weighted arc
typedef vector<vector<WArc>> WGraph; // weighted digraf

int dijkstra(const WGraph& G, int s, int x, vector <int> &p){
  int n = G.size();
  vector<double> d(n, infinit); d[s] = 0;
  vector<bool> S(n, false);
  p = vector<int>(n, -1);
  priority_queue<WArc, vector<WArc>, greater<WArc> > Q;
  Q.push(WArc(0, s));
  while (not Q.empty()){
    int u = Q.top().second; Q.pop();
    if (not S[u]){
      S[u] = true;
      for (WArc a : G[u]){
        int v = a.second;
        double c = a.first;
        if ((d[v] > d[u] + c) or d[v] == infinit){
          d[v] = d[u] + c;
          p[v] = u;
          Q.push(WArc(d[v], v));
        }
      }
    }
  }
  return d[x];
}

void read (WGraph& G){
  int m; cin >> m;
  for (int i = 0; i < m; ++i){
    int u,v;
    double c;
    cin >> u >> v >> c;
    G[u].push_back(make_pair(c,v));
  }
}

void print (const vector <int> &p , int y){
  stack <int> s;
  bool found = false;
  int i = y;
  while (not found){
    s.push(i);
    i = p[i];
    found = i == -1;
  }
  bool first = true;
  while (not s.empty()){
    if (first) first = false;
    else cout << ' ';
    cout << s.top();
    s.pop();
  }
  cout << endl;
}

int main (){
  int n;
  while (cin >> n){
    WGraph G(n);
    read(G);
    int x,y; cin >> x >> y;
    vector <int> p;
    int c = dijkstra(G, x, y, p);
    if (c != -1) print(p, y);
    else cout << "no path from " << x << " to " << y << endl;
  }
}
