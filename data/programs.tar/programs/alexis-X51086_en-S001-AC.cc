#include <iostream>
using namespace std;

// Function for the difference of two integers 
int dif(int x, int y) {
    return x - y;
}