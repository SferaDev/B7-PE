#include <iostream>
#include <vector>
#include <string>

using namespace std;

const int LONG_ALFABET ='z'-'a' + 1;

void escriu_fals(const vector<bool>& v){
  for (int i=0; i<LONG_ALFABET; ++i){
    if (not v[i]) cout << char('a'+i)<< endl;
  }
}
  

int main (){
  int n;
  cin >> n;
  vector<bool> v(LONG_ALFABET,false);
  string m,x,y;
  cin >> m;
  x=m;
  for (int i=0; i<n; ++i){
    for (int j=0; j<m.size(); ++j){
      v[m[j]-'a']=true;
    }
    if (x.length ()<m.length()) x=m;
    cin >> m;
  }
  cout << x<< endl;
  escriu_fals(v); 
}