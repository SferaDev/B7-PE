#include <iostream>
#include <vector>
using namespace std;

typedef vector <char> VC;
typedef vector <VC> VVC;
int n;
int r;

void next (int i, int j, int &ni, int &nj){
  if (j < n - 1){
    ni = i;
    nj = ++j;
  }
  else{
    ni = ++i;
    nj = 0;
  }
}

bool safe (int i, int j, const VVC &t)
  {
  if (i > 0 and t[i-1][j] == 'K') return false;
  if (i > 0 and j < n - 1 and t[i-1][j+1] == 'K') return false;
  if (j < n - 1 and t[i][j+1] == 'K') return false;
  if (i < n - 1 and j < n - 1 and t[i+1][j+1] == 'K') return false;
  if (i < n - 1 and t[i+1][j] == 'K') return false;
  if (i < n - 1 and j > 0 and t[i+1][j-1] == 'K') return false;
  if (j > 0 and t[i][j-1] == 'K') return false;
  if (i > 0 and j > 0 and t[i-1][j-1] == 'K') return false;
  return true;
}

void print (const VVC &t){
  for (int i = 0; i < n; ++i){
    for (int j = 0; j < n; ++j) cout << t[i][j];
    cout << endl;
  }
  cout << "----------" << endl;
}

void permuta (int i, int j, int act, VVC &t){
  if (act == r) print(t);
  else if (i != n){
    int ni, nj;
    next(i,j,ni,nj);
    if (safe(i,j,t)){
      t[i][j] = 'K';
      permuta(ni,nj,act+1,t);
    }
    t[i][j] = '.';
    permuta(ni,nj,act,t);
  }
}

int main (){
  cin >> n >> r;
  VVC t(n, VC(n, '.'));
  permuta(0,0,0,t);
}
