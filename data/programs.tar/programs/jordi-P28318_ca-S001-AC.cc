#include <iostream>
#include <vector>
   
using namespace std;

typedef vector < vector <int> > Mivector;

void llegeix( Mivector& v) {
  for ( int i = 0; i < v.size(); ++i) {
    for ( int j = 0; j < v[i].size(); ++j) {
      cin >> v[i][j];
    }
  }
}

void imprimeix(const Mivector& v, string s) {
  int n;
  cin >> n;
  if ( s == "fila" ) {
    int a = v[0].size();
    cout << "fila " << n << ":" ;
    for ( int i = 0; i < a; ++i) {
      cout << " "<< v[n - 1][i];
    }
    cout << endl;
  }else if ( s == "columna" ) {
    int a = v.size();
    cout << "columna " << n << ":" ;
    for ( int i = 0; i < a; ++i) {
      cout << " "<< v[i][n - 1];
    }
    cout << endl;
  }else {
    int a;
    cin >> a;
    cout << "element " << n << " " << a << ": " << v[n - 1][a - 1] << endl;
  }
}
    
int main () {
  int a, b;
  cin >> a >> b;
  Mivector v(a,vector<int>(b));
  llegeix (v);
  string s;
  while (cin >> s) {
    imprimeix (v, s);
  }
}
	 