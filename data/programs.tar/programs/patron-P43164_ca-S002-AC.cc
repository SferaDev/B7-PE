#include <iostream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

typedef vector<vector<char>> Map;

struct Pos {
	int x, y;
	inline Pos () : x(0), y(0) { }
	inline Pos (int x, int y) : x(x), y(y) { }
};

bool posOK(const Map& map, Pos pos) {
	if (pos.x < 0 or pos.x >= map.size()) return false;
	if (pos.y < 0 or pos.y >= map[pos.x].size()) return false;
	if (map[pos.x][pos.y] == 'X') return false;
	return true;
}


// Pre x and y between 0 and size() - 1
stack<int> BFSMaxDistances(const Map& map, int x, int y) {
	stack<int> maxDistances;
	bool found = false;
	queue<pair<Pos, int>> Q;
	
	// We have two options, another map or a set
	// Map provides constant while set has to do searches
	vector<vector<bool>> visited(map.size(), vector<bool>(map[0].size(), false));
	Q.push(make_pair(Pos(x, y), 0));
	
	while (not Q.empty()) {
		pair<Pos, int> current = Q.front();
		Pos currentPos = current.first;
		int currentDistance = current.second;
		Q.pop();
		if (not visited[currentPos.x][currentPos.y]) {
			visited[currentPos.x][currentPos.y] = true;
			// If currentPos is a 't' update maxDistance
			if (map[currentPos.x][currentPos.y] == 't') {
				maxDistances.push(currentDistance);
			}
			// Else visit nearby
			if (posOK(map, Pos(currentPos.x + 1, currentPos.y)))
				Q.push(make_pair(Pos(currentPos.x + 1, currentPos.y), currentDistance + 1));
			if (posOK(map, Pos(currentPos.x - 1, currentPos.y)))
				Q.push(make_pair(Pos(currentPos.x - 1, currentPos.y), currentDistance + 1));
			if (posOK(map, Pos(currentPos.x, currentPos.y + 1)))
				Q.push(make_pair(Pos(currentPos.x, currentPos.y + 1), currentDistance + 1));
			if (posOK(map, Pos(currentPos.x, currentPos.y - 1)))
				Q.push(make_pair(Pos(currentPos.x, currentPos.y - 1), currentDistance + 1));
		}
	}
	return maxDistances;
}


int main() {
	int n, m;
	cin >> n >> m;
	
	Map map(n, vector<char>(m));
	
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cin >> map[i][j];
		}
	}

	int x, y;
	cin >> x >> y;
	
	stack<int> distances = BFSMaxDistances(map, x - 1, y - 1);
	
	if (distances.empty()) cout << "no es pot arribar a dos o mes tresors";
	else {
		distances.pop();
		if (distances.empty()) cout << "no es pot arribar a dos o mes tresors";
		else cout << "segona distancia maxima: " << distances.top();
	}
	cout << endl;
}