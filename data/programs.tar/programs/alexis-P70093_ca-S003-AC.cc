#include <iostream>
#include <vector>
using namespace std;

vector<double> fusio(const vector<double>& v1, const vector<double>& v2) {
    vector<double> result(v1.size() + v2.size());
    int i, j, k;
    i = j = k = 0;
    while (i < v1.size() or j < v2.size()) {
        if (i == v1.size()) {
            result[k] = v2[j];
            j += 1;
            k += 1;
        } else if (j == v2.size()) {
            result[k] = v1[i];
            i += 1;
            k += 1;
        } else if (v1[i] < v2[j]) {
            result[k] = v1[i];
            i += 1;
            k += 1;
        } else {
            result[k] = v2[j];
            j += 1;
            k += 1;
        }
    }
    return result;
}

int main() {
    //
}