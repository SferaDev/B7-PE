#include <iostream>
#include <vector>
#include <string>

using namespace std;

int n;
int nn;
vector<char> sol;
vector<char> consonantes;
vector<char> vocales;
vector<bool> marca_c;
vector<bool> marca_v;


void escriu(){
  for(int j = 0; j < nn; ++j){
    cout << sol[j];
  }
  cout << endl;
}

void backtrack(int i){
  if(i == n){
    escriu();
  }
  else{
    for(int k = 0; k < n; ++k){
      if(not marca_c[k]){
	sol[2*i] = consonantes[k];
	marca_c[k] = true;
	for(int j = 0; j < n; ++j){
	  if(not marca_v[j]){
	    sol[2*i + 1] = vocales[j];
	    marca_v[j] = true;
	    backtrack(i+1);
	    marca_v[j] = false;
	  }
	}
	marca_c[k] = false;
      }
    }
  }
}


int main()
{
  cin >> n;
  nn = 2*n;
  sol = vector<char>(2*n);
  consonantes = vector<char>(n);
  vocales = vector<char>(n);
  marca_c = vector<bool>(n,false);
  marca_v = vector<bool>(n,false);
  
  for(int i = 0; i < n; ++i){
    cin >> consonantes[i];
  }
  for(int j = 0; j < n; ++j){
    cin >> vocales[j];
  }
  backtrack(0);
}