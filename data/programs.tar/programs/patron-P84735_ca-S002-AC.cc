#include <iostream>

using namespace std;

int main()
{
  int a,b,cont=1;
  while (cin >> a >> b){
    int m=a/b*b;
    if (m!=a){
      m+=b;
    }
    cout << "#" << cont << " : " << m << endl;
    ++cont;
  }
}