#include <iostream>
#include <set>
#include <sstream>

using namespace std;

int main ()
{
  string linia;
  while (getline(cin, linia))
  {
    istringstream ss(linia);
    int x;
    int cont = 0;
    set <int> num;
    while (ss >> x) num.insert(x);
    bool parell = false;
    bool senar = false;
    for (auto it = num.begin(); it != num.end(); ++it)
    {
      if ((*it)%2 == 0 and not parell) ++cont;
      else if ((*it)%2 != 0 and not senar)  ++cont;
      parell = (*it)%2 == 0;
      senar = not parell;
    }
    cout << cont << endl;
  }
}