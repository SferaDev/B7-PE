#include <vector>
#include <iostream>
using namespace std;
 
int comptatge_frontisses(const vector<int> &v) {
/* Pre: cert */
/* Post: el resultat es el nombre d'elements frontissa de v */
        int n = v.size();
        if (n == 0) return 0;
        int suma_seg = 0;
        for (int i = 1; i < n; ++i) {
                suma_seg += v[i];
        }
        int suma_prec, compt;
        suma_prec = compt = 0;
        for (int i = 0; i < n; ++i) {
                if (i != 0) {
                        suma_seg -= v[i];
                        suma_prec += v[i-1];
                }
                if (suma_seg - suma_prec == v[i]) ++compt;
        }
        return compt;
 }