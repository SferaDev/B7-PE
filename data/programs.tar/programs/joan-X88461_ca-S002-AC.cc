#include <iostream>
#include <vector>
using namespace std;

vector <int> maxmin(const vector<int> &v){
    int max = v[0];
    int min = v[0];
    int llarg = v.size();
    vector <int> t (2);
    for (int p = 0; p < llarg; ++p){
        if (v[p]<min){min=v[p];}
        else if (v[p]>max){max=v[p];}
    }
    t[0]=max;
    t[1]=min;
    return t;
}

int main(){
    int n;
    cin>>n;
    vector <int> v (n);
    vector <int> t (2);
    for (int i=0; i<n; ++i){
        cin>>v[i];
    }
    t=maxmin (v);
    cout<<t[0]<<" "<<t[1]<<endl;
    
}