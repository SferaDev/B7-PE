#include <iostream>
#include <vector>
#include <string>

using namespace std;

int n;
vector<int> sol;
vector<bool> marca;
vector<string> llista;

void escriu(){
  
  for(int i = 0; i < n; ++i){
    if(i == 0) cout << '(' << llista[sol[i]];
    else cout << ',' << llista[sol[i]];
  }
  cout << ')' << endl;
  
}

void permutacions(int i){
  if(i == n) escriu();
  else{
    for(int k = 0; k < n; ++k){
      sol[i] = k;
      if (not marca[k]){
	marca[k] = true;
	permutacions(i+1);
	marca[k] = false;
      }
    }
  }
}

void llegir(){
  for(int i = 0; i < n; ++i){
    cin >> llista[i];
  }
}

int main(){
  //n = atoi(argv[1]);
  cin >> n;
  sol = vector<int>(n);
  marca = vector<bool>(n,false);
  llista = vector<string>(n);
  llegir();
  permutacions(0);
}