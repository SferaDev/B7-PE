#include <iostream>
using namespace std;
//INP: 2 numbers between -1000 and 1000
//OUT: The promedium of both numbers
int main() {
    double x,y; //first number, second number and de promedium
    cin >>x>>y;
    cout<<(x+y)/2<<endl;
}