#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

//Pre:
//Post: Indique si hay algún valor que sea igual a la suma de los demás

bool hi_ha (const vector<int> &v,int suma,int n)
{
  for (int i=0;i<n;++i)
    if(suma-v[i]==v[i]) return true;
    return false;
}

int main()
{
  
  int n;
  while(cin>>n){
    vector <int> v (n);
    int suma=0;
    for (int i=0; i<n;++i){
      cin>>v[i];
      suma+=v[i];
    }
    
    if (hi_ha(v,suma,n)) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
  }
}

