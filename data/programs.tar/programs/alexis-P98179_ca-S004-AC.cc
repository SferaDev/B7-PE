#include <iostream>
#include <vector>
using namespace std;

void swap(double& a, double& b) {
    double c = a;
    a = b;
    b = c;
}

void insereix(vector<double>& v) {
    int i = v.size() - 1;
    while (i > 0 and v[i] <= v[i - 1]) {
        swap(v[i], v[i - 1]);
        i -= 1;
    }
}        

int main() {
    //
}