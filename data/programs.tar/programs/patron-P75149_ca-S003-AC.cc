#include <iostream>

using namespace std;

int main ()
{
	char c;
	
	while (cin >> c and c!='a' and c!='.');
	if (c=='a') cout << "si" << endl;
	else cout << "no" << endl;
}
