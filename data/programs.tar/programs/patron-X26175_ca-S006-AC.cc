#include "Cjt_estudiants.hh"

void Cjt_estudiants::afegir_estudiant(const Estudiant &est, bool& b)
{

  b = false;
  int dni = est.consultar_DNI();
  //mirem si esta el dni al cjt_d'estudiants

  for (int i = 0; i < nest and not b; ++i) {
    b = (vest[i].consultar_DNI() == dni);
  }

  if (not b) {
    ++nest; //augmentem el nombre d'estudiants
    vest[nest-1] = est; //l'afegim a l'ultima posicio de vest
    
    //si te nota, entre 0 <= nota <= 9, incrementem l'interval
    if (est.te_nota()) incrementar_interval(est.consultar_nota());
    
    //ordenem el conjunt d'estudiants
    Cjt_estudiants::ordenar();
  }
}

void Cjt_estudiants::esborrar_estudiant(int dni, bool& b)
{

  b = false;
  for (int i = 0; i < nest and not b; ++i) {
    //mirem si hi es el dni que volem esborrar
    b = (vest[i].consultar_DNI() == dni);

    //si hi es, l'esborrem
    if (b) {
      //si te nota valida, decrementem l'interval
      if (vest[i].te_nota()) decrementar_interval(vest[i].consultar_nota());

      //modifiquem el conjunt d'estudiants esborrant l'estudiant
      for (int j = i; j < nest-1; ++j) {
	vest[j] = vest[j+1];
      }
      --nest;
    }
  }
}