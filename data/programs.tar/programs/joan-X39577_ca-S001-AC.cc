#include <iostream>
#include <vector>
#include "Estudiant.hh"
using namespace std;

int main (){
    int m, n, s; //m=nombre d'estudiants; n=nombre d'assignatures; s=nombre d'assignatures seleccionades;
    cin>>m>>n>>s;
    vector <bool> subj (n, false); //referencia d'assignatures a seleccionar
    vector <Estudiant> notes (m);//introdui DNI i notes dels estudiants.
    int num;
    for (int i=0; i<s; ++i){
        cin>>num;
        subj[num-1]=true;
    }
    for (int i=0; i<m; ++i){
        int DNI;
        cin>>DNI;
        Estudiant a (DNI);
        double notaf = 0;
        for (int j=0;j<n;++j){
            double k;
            cin>>k;
            if (subj[j]){
            notaf+=k;
        }
        }
        notaf=notaf/s;
        a.afegir_nota(notaf);
        notes[i]=a;
    }
      for (int i=0; i<m;++i){ //escriptura del vector
        notes[i].escriure();
    }
    
}