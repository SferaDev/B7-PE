#include <iostream>
using namespace std;

int main() {
    int x, y, z;
    int sum = 0;
    int sumOut = 0;
    cin >> x >> y;
    while (cin >> z) {
        if (z >= x && z <= y) {
            sum += z;
        } else {
            sumOut += 1;
        }
    }
    cout << "Sum Inside: " << sum << endl;
    cout << "Num Outside: " << sumOut << endl;
}