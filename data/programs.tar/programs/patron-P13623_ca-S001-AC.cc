#include <iostream>

using namespace std;

int main ()
{
  int f,c;
  cin >> f >> c;
  int suma=0;
  for (int i=0; i<f; ++i){
    for (int j=0; j<c; j++){
      char c;
      cin >> c;
      int d=c-'0';
      if ((i+j)%2==0)
	suma+=d;
    }
  }
  cout << suma << endl;
}