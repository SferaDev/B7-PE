#include <iostream>
#include <stack>
using namespace std;

bool validar() {
  int countPar, countKey;
  countPar = countKey = 0;
  bool isPar, isKey;
  isPar = isKey = false;
  char c;
  while (cin >> c and c != '.') {
    if (countPar < 0 or countKey < 0) return false;
    if (c == '(') {
      countPar++;
      isPar = true;
      isKey = false;
    } else if (c == '[') {
      countKey++;
      isPar = false;
      isKey = true;
    } else if (c == ')') {
      if (isKey) return false;
      countPar--;
      isPar = false;
    } else if (c == ']') {
      if (isPar) return false;
      countKey--;
      isKey = false;
    }
  }
  return true;
}

int main() {
  bool valid = validar();
  if (valid) cout << "Correcte";
  else cout << "Incorrecte";
  cout << endl;
}

