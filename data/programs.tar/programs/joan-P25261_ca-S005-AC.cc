#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
typedef vector <int> vect;

bool comp(const int& a,const int& b){
  return a > b;
}


int main (){
  int n;
  while (cin>>n){
    bool primer_nombre=true;
    vect a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    
    sort(a.begin(), a.end(), comp);
    for (int i = 0; i < n; ++i){
      if (primer_nombre){
	 cout << a[i];
         primer_nombre = false;
      } else cout << " " << a[i];
    } 
    cout << endl; 
  }
}