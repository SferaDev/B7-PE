#include <iostream>
using namespace std;

int main() {
  int n;
  cin >> n;
  char resposta[n];
  for (int i = 0; i < n; ++i) {
      cin >> resposta[i];  
  }
  int a, b, c;
  a = b = c = 0;      
  for (int i = 0; i < n; ++i) {
      if (resposta[i] == 'a') ++a;
      if (resposta[i] == 'b') ++b;
      if (resposta[i] == 'c') ++c;             
  }            
  char m;
  int t;    
  if (a == b and a == c) {
     m = 'a';
     t = a;              
  }
  if (a > b and a > c) {
     m = 'a';
     t = a;              
  }
  if (b > a and b > c) {
     m = 'b';
     t = b;              
  }
  if (c > b and c > a) {
     m = 'c';
     t = c;              
  }
  if (a == b and a > c) {
     m = 'a';
     t = a;              
  }
  if (b == c and b > a) {
     m = 'b';
     t = b;              
  }
  if (a == c and a > b) {
     m = 'a';
     t = a;              
  }
  cout << "majoria de " << m << endl 
       << t << " repeticio(ns)" << endl;                       
} 
