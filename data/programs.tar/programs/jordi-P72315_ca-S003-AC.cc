#include <iostream>

using namespace std;

int intercalacio(int x, int y){
  int z=1;
  int j=x;
  int i=y;
  int cont=0;
  while (x>0){
    z=z*10;
    x=x/10;
    y=y/10;
    ++cont;
  }
  x=j;
  y=i;
  if ( x==0 and y==0) cout << x;
  else if (x==0 and y!=0) cout << y;
  while (cont>=1){
    z=z/10;
    cout << x/(z) << y/(z);
    x=x%z;
    y=y%z;
    --cont;
  }
  cout << endl; 
}
  
int main (){
  int x,y;
  while (cin >> x >> y){
    intercalacio (x, y);
  }
  
}
